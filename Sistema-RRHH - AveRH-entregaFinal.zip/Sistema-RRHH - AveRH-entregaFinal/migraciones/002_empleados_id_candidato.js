// Relaciona cada empleado con el candidato del que procede.
// Se rellena comparando la cédula (que es única en ambas tablas).
// Reversión: ALTER TABLE empleados DROP FOREIGN KEY fk_empleado_candidato,
//            DROP INDEX uk_empleado_candidato, DROP COLUMN id_candidato;

const { existeColumna, existeRestriccion } = require("./utilidades");

module.exports = {

    descripcion: "Añade empleados.id_candidato y lo enlaza por cédula",

    async aplicar(consultar) {

        if (!(await existeColumna(consultar, "empleados", "id_candidato"))) {

            await consultar(`
                ALTER TABLE empleados
                ADD COLUMN id_candidato INT NULL DEFAULT NULL AFTER id_empleado
            `);
        }

        await consultar(`
            UPDATE empleados e
            INNER JOIN candidatos c ON c.cedula = e.cedula
            SET e.id_candidato = c.id_candidato
            WHERE e.id_candidato IS NULL
        `);

        if (!(await existeRestriccion(consultar, "empleados", "uk_empleado_candidato"))) {
            await consultar(`
                ALTER TABLE empleados
                ADD CONSTRAINT uk_empleado_candidato UNIQUE (id_candidato)
            `);
        }

        if (!(await existeRestriccion(consultar, "empleados", "fk_empleado_candidato"))) {
            await consultar(`
                ALTER TABLE empleados
                ADD CONSTRAINT fk_empleado_candidato
                    FOREIGN KEY (id_candidato) REFERENCES candidatos (id_candidato)
            `);
        }
    }
};
