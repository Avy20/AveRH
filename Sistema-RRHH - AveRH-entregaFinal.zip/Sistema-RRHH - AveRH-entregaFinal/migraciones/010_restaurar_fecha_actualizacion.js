// Restaura candidatos.fecha_actualizacion alterada por la migración 008.
//
// La columna tiene ON UPDATE CURRENT_TIMESTAMP: al corregir el
// departamento y el correo, MySQL marcó esos candidatos como
// "modificados" en el instante de la migración, lo que distorsionaba
// la lista de candidatos recientes del panel.
//
// Evidencia (comparación con el respaldo verificado previo a 008):
// las 18 filas afectadas tenían fecha_actualizacion = NULL y ahora
// tienen exactamente la hora en que se aplicó 008. Solo esas filas
// vuelven a NULL; cualquier modificación posterior real se conserva.

module.exports = {

    descripcion: "Restaura fecha_actualizacion alterada por la corrección técnica 008",

    async aplicar(consultar) {

        const [migracion] = await consultar(
            "SELECT aplicada_en FROM schema_migraciones WHERE id = '008_correcciones_auditoria'"
        );

        if (!migracion) {
            return;
        }

        // La marca de 008 coincide (al segundo) con su registro en schema_migraciones.
        await consultar(
            `UPDATE candidatos
             SET fecha_actualizacion = NULL
             WHERE fecha_actualizacion BETWEEN DATE_SUB(?, INTERVAL 5 SECOND) AND ?`,
            [migracion.aplicada_en, migracion.aplicada_en]
        );
    }
};
