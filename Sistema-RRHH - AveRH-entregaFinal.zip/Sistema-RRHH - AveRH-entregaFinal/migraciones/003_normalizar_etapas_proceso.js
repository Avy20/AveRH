// Unifica las etapas del proceso de selección.
// Algunos registros antiguos usan otros nombres
// ("En evaluacion", "Seleccionado"...). El valor original
// se conserva en resultado_original, por lo que no se pierde nada.
// Reversión: UPDATE proceso_seleccion SET resultado = resultado_original
//            WHERE resultado_original IS NOT NULL;

const { existeColumna, agregarCheck } = require("./utilidades");

const EQUIVALENCIAS = {
    "En evaluacion": "Evaluación",
    "En evaluación": "Evaluación",
    "Evaluacion": "Evaluación",
    "En espera": "Entrevista",
    "Seleccionado": "Contratado",
    "No seleccionado": "Descartado"
};

module.exports = {

    descripcion: "Normaliza proceso_seleccion.resultado conservando el valor original",

    async aplicar(consultar) {

        if (!(await existeColumna(consultar, "proceso_seleccion", "resultado_original"))) {

            await consultar(`
                ALTER TABLE proceso_seleccion
                ADD COLUMN resultado_original VARCHAR(30) NULL DEFAULT NULL AFTER resultado
            `);
        }

        for (const [anterior, nuevo] of Object.entries(EQUIVALENCIAS)) {

            await consultar(
                `UPDATE proceso_seleccion
                 SET resultado_original = resultado, resultado = ?
                 WHERE BINARY resultado = ? AND resultado_original IS NULL`,
                [nuevo, anterior]
            );
        }

        await agregarCheck(
            consultar,
            "proceso_seleccion",
            "chk_proceso_resultado",
            "resultado IN ('Postulado','Entrevista','Evaluación','Oferta','Contratado','Descartado')"
        );
    }
};
