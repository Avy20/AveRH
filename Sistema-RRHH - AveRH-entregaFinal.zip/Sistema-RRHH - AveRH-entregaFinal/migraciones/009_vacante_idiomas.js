// Requisitos de idiomas independientes por vacante.
// Cada fila indica el nivel MÍNIMO exigido de un idioma del catálogo.
// Los idiomas sin fila se consideran "No requerido".
//
// - Conserva el requisito de inglés de cada vacante (vacantes.nivel_ingles).
// - Añade al catálogo los idiomas solicitados que falten (Árabe, Coreano).
// Reversión: DROP TABLE vacante_idiomas;

const { existeTabla } = require("./utilidades");

const IDIOMAS_SOLICITADOS = ["Español", "Inglés", "Francés", "Portugués", "Mandarín", "Alemán", "Italiano", "Japonés", "Coreano", "Árabe"];

module.exports = {

    descripcion: "Crea vacante_idiomas y migra el requisito de inglés de cada vacante",

    async aplicar(consultar) {

        // Idiomas del catálogo que falten (la comparación ignora acentos y mayúsculas).
        for (const nombre of IDIOMAS_SOLICITADOS) {

            const existe = await consultar("SELECT 1 FROM idiomas WHERE nombre = ? LIMIT 1", [nombre]);

            if (existe.length === 0) {
                await consultar("INSERT INTO idiomas (nombre, estado) VALUES (?, 'Activo')", [nombre]);
            }
        }

        if (!(await existeTabla(consultar, "vacante_idiomas"))) {

            await consultar(`
                CREATE TABLE vacante_idiomas (
                    id_vacante INT NOT NULL,
                    id_idioma INT NOT NULL,
                    nivel_minimo VARCHAR(20) NOT NULL,
                    PRIMARY KEY (id_vacante, id_idioma),
                    KEY idx_vacante_idiomas_idioma (id_idioma),
                    CONSTRAINT fk_vacante_idiomas_vacante
                        FOREIGN KEY (id_vacante) REFERENCES vacantes (id_vacante) ON DELETE CASCADE,
                    CONSTRAINT fk_vacante_idiomas_idioma
                        FOREIGN KEY (id_idioma) REFERENCES idiomas (id_idioma),
                    CONSTRAINT chk_vacante_idiomas_nivel
                        CHECK (nivel_minimo IN ('Básico', 'Intermedio', 'Avanzado', 'Nativo'))
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
            `);
        }

        const [ingles] = await consultar("SELECT id_idioma FROM idiomas WHERE nombre = 'Inglés' LIMIT 1");

        if (ingles) {
            await consultar(`
                INSERT IGNORE INTO vacante_idiomas (id_vacante, id_idioma, nivel_minimo)
                SELECT id_vacante, ?, nivel_ingles
                FROM vacantes
                WHERE nivel_ingles IN ('Básico', 'Intermedio', 'Avanzado', 'Nativo')
            `, [ingles.id_idioma]);
        }
    }
};
