// Fecha de la última modificación de cada candidato.
// Las filas existentes quedan en NULL (no se inventan fechas).
// Reversión: ALTER TABLE candidatos DROP COLUMN fecha_actualizacion;

const { existeColumna } = require("./utilidades");

module.exports = {

    descripcion: "Añade candidatos.fecha_actualizacion",

    async aplicar(consultar) {

        if (await existeColumna(consultar, "candidatos", "fecha_actualizacion")) {
            return;
        }

        await consultar(`
            ALTER TABLE candidatos
            ADD COLUMN fecha_actualizacion DATETIME NULL DEFAULT NULL
                ON UPDATE CURRENT_TIMESTAMP
        `);
    }
};
