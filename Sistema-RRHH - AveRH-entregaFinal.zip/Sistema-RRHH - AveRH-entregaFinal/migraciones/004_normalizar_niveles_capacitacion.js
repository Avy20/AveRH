// Unifica la escritura de los niveles de capacitación
// (por ejemplo "Maestria" → "Maestría"). Es una corrección
// 1 a 1: cada valor antiguo tiene un único equivalente.

const { agregarCheck } = require("./utilidades");

const EQUIVALENCIAS = {
    "Tecnico": "Técnico",
    "Maestria": "Maestría",
    "Gestion": "Gestión",
    "Postgrado": "Post-grado",
    "Post grado": "Post-grado"
};

module.exports = {

    descripcion: "Normaliza capacitaciones.nivel (acentos) y restringe sus valores",

    async aplicar(consultar) {

        for (const [anterior, nuevo] of Object.entries(EQUIVALENCIAS)) {

            await consultar(
                // BINARY: la intercalación ignora acentos, así que
                // sin ella "Técnico" coincidiría con "Tecnico".
                "UPDATE capacitaciones SET nivel = ? WHERE BINARY nivel = ?",
                [nuevo, anterior]
            );
        }

        await agregarCheck(
            consultar,
            "capacitaciones",
            "chk_capacitacion_nivel",
            "nivel IN ('Técnico','Grado','Post-grado','Maestría','Doctorado','Gestión')"
        );
    }
};
