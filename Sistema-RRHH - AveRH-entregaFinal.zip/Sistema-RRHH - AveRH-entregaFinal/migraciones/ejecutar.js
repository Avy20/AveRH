// ==========================================
// AveRH - Ejecutor de migraciones
// Uso: npm run migrar
//
// 1. Crea un respaldo verificable (scripts/respaldo.js).
// 2. Aplica en orden las migraciones pendientes de esta carpeta.
// 3. Registra cada migración aplicada en schema_migraciones.
//
// Las migraciones son aditivas o conservan los valores
// originales: ninguna elimina datos.
// ==========================================

require("dotenv").config({ quiet: true });

const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");
const { crearRespaldo } = require("../scripts/respaldo");


function listarMigraciones() {

    return fs.readdirSync(__dirname)
        .filter(archivo => /^\d{3}_.+\.js$/.test(archivo))
        .sort()
        .map(archivo => ({
            id: archivo.replace(/\.js$/, ""),
            ...require(path.join(__dirname, archivo))
        }));
}


async function ejecutarMigraciones({ respaldo = true, silencioso = false } = {}) {

    const registrar = (...texto) => {
        if (!silencioso) {
            console.log(...texto);
        }
    };

    const conexion = await mysql.createConnection({
        host: process.env.DB_HOST,
        port: Number(process.env.DB_PORT) || 3306,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        charset: "utf8mb4"
    });

    const consultar = async (sql, parametros = []) => {
        const [resultado] = await conexion.query(sql, parametros);
        return resultado;
    };

    try {

        await consultar(`
            CREATE TABLE IF NOT EXISTS schema_migraciones (
                id VARCHAR(100) NOT NULL PRIMARY KEY,
                descripcion VARCHAR(255) NOT NULL,
                aplicada_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
        `);

        const aplicadas = new Set(
            (await consultar("SELECT id FROM schema_migraciones")).map(fila => fila.id)
        );

        const pendientes = listarMigraciones().filter(m => !aplicadas.has(m.id));

        if (pendientes.length === 0) {
            registrar(`Base de datos ${process.env.DB_NAME} al día: no hay migraciones pendientes.`);
            return [];
        }

        let archivoRespaldo = null;

        if (respaldo) {
            registrar("Creando respaldo verificable antes de migrar...");
            archivoRespaldo = (await crearRespaldo({ silencioso: true })).archivo;
            registrar(`Respaldo verificado: ${path.relative(process.cwd(), archivoRespaldo)}`);
        }

        for (const migracion of pendientes) {

            registrar(`Aplicando ${migracion.id}: ${migracion.descripcion}`);

            try {

                await migracion.aplicar(consultar);

            } catch (error) {

                console.error(`La migración ${migracion.id} falló: ${error.message}`);

                if (archivoRespaldo) {
                    console.error(`Puedes restaurar el estado anterior con: ${archivoRespaldo}`);
                }

                throw error;
            }

            await consultar(
                "INSERT INTO schema_migraciones (id, descripcion) VALUES (?, ?)",
                [migracion.id, migracion.descripcion]
            );
        }

        registrar(`${pendientes.length} migración(es) aplicada(s) correctamente.`);

        return pendientes.map(m => m.id);

    } finally {
        await conexion.end();
    }
}


module.exports = { ejecutarMigraciones };


if (require.main === module) {

    ejecutarMigraciones().catch(() => {
        process.exitCode = 1;
    });
}
