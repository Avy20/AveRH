// Historial de cambios de etapa del proceso de selección
// (quién movió a qué candidato, cuándo y con qué observación).
// Se crea un registro inicial con la etapa actual de cada proceso.
// Reversión: DROP TABLE proceso_historial;

const { existeTabla } = require("./utilidades");

module.exports = {

    descripcion: "Crea proceso_historial con la etapa actual de cada proceso",

    async aplicar(consultar) {

        if (await existeTabla(consultar, "proceso_historial")) {
            return;
        }

        await consultar(`
            CREATE TABLE proceso_historial (
                id_historial INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                id_proceso INT NOT NULL,
                etapa_anterior VARCHAR(30) NULL,
                etapa_nueva VARCHAR(30) NOT NULL,
                observacion VARCHAR(255) NULL,
                id_usuario INT NULL,
                fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_historial_proceso (id_proceso, fecha),
                CONSTRAINT fk_historial_proceso
                    FOREIGN KEY (id_proceso) REFERENCES proceso_seleccion (id_proceso)
                    ON DELETE CASCADE,
                CONSTRAINT fk_historial_usuario
                    FOREIGN KEY (id_usuario) REFERENCES usuarios (id_usuario)
                    ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
        `);

        await consultar(`
            INSERT INTO proceso_historial (id_proceso, etapa_anterior, etapa_nueva, observacion, fecha)
            SELECT id_proceso, NULL, resultado, 'Etapa registrada antes del historial', fecha_proceso
            FROM proceso_seleccion
        `);
    }
};
