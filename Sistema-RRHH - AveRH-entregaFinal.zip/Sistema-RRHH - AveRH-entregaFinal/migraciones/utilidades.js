// Comprobaciones para que cada migración sea idempotente.

async function existeColumna(consultar, tabla, columna) {

    const filas = await consultar(
        `SELECT 1 FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
        [tabla, columna]
    );

    return filas.length > 0;
}

async function existeTabla(consultar, tabla) {

    const filas = await consultar(
        `SELECT 1 FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?`,
        [tabla]
    );

    return filas.length > 0;
}

async function existeRestriccion(consultar, tabla, nombre) {

    const filas = await consultar(
        `SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = ?`,
        [tabla, nombre]
    );

    return filas.length > 0;
}

// Añade un CHECK solo si todos los datos existentes lo cumplen.
async function agregarCheck(consultar, tabla, nombre, condicion) {

    if (await existeRestriccion(consultar, tabla, nombre)) {
        return;
    }

    const [{ invalidas }] = await consultar(
        `SELECT COUNT(*) AS invalidas FROM \`${tabla}\` WHERE NOT (${condicion})`
    );

    if (Number(invalidas) > 0) {
        throw new Error(
            `No se puede añadir ${nombre}: hay ${invalidas} fila(s) en ${tabla} que no cumplen la condición.`
        );
    }

    await consultar(
        `ALTER TABLE \`${tabla}\` ADD CONSTRAINT \`${nombre}\` CHECK (${condicion})`
    );
}

module.exports = {
    existeColumna,
    existeTabla,
    existeRestriccion,
    agregarCheck
};
