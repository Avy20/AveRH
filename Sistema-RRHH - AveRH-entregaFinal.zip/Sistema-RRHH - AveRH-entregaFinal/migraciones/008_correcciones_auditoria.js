// Correcciones de datos con evidencia suficiente (auditoría del 08/10/2026).
// No se inventan fechas, cédulas ni datos personales.
//
// 1. candidatos.departamento y empleados.departamento: texto libre
//    antiguo ("Analisis de Datos", "Tecnologia"...). El valor correcto
//    es el departamento del puesto (clave foránea id_puesto).
// 2. Correos con mayúsculas → minúsculas (los correos no distinguen
//    mayúsculas; evita duplicados aparentes).
// 3. Candidatos sin proceso de selección cuyo puesto tiene una única
//    vacante y cuya fecha de postulación es conocida: se crea su
//    proceso en etapa Postulado con esa fecha.

module.exports = {

    descripcion: "Corrige departamentos, correos y procesos faltantes con evidencia",

    async aplicar(consultar) {

        await consultar(`
            UPDATE candidatos c
            INNER JOIN puestos p ON p.id_puesto = c.id_puesto
            INNER JOIN departamentos d ON d.id_departamento = p.id_departamento
            -- Se reasigna fecha_actualizacion para que ON UPDATE no la cambie:
            -- es una corrección técnica, no una modificación del candidato.
            SET c.departamento = d.nombre, c.fecha_actualizacion = c.fecha_actualizacion
            WHERE c.departamento IS NULL OR BINARY c.departamento <> BINARY d.nombre
        `);

        await consultar(`
            UPDATE empleados e
            INNER JOIN puestos p ON p.id_puesto = e.id_puesto
            INNER JOIN departamentos d ON d.id_departamento = p.id_departamento
            SET e.departamento = d.nombre
            WHERE e.departamento IS NULL OR BINARY e.departamento <> BINARY d.nombre
        `);

        await consultar(`
            UPDATE candidatos SET correo = LOWER(TRIM(correo)), fecha_actualizacion = fecha_actualizacion
            WHERE correo IS NOT NULL AND BINARY correo <> BINARY LOWER(TRIM(correo))
        `);

        const sinProceso = await consultar(`
            SELECT c.id_candidato, c.fecha_postulacion, MIN(v.id_vacante) AS id_vacante
            FROM candidatos c
            INNER JOIN vacantes v ON v.id_puesto = c.id_puesto
            LEFT JOIN proceso_seleccion ps ON ps.id_candidato = c.id_candidato
            WHERE ps.id_proceso IS NULL AND c.fecha_postulacion IS NOT NULL
            GROUP BY c.id_candidato, c.fecha_postulacion
            HAVING COUNT(v.id_vacante) = 1
        `);

        for (const candidato of sinProceso) {

            const proceso = await consultar(
                `INSERT INTO proceso_seleccion (id_candidato, id_vacante, fecha_proceso, resultado, observaciones)
                 VALUES (?, ?, ?, 'Postulado', 'Proceso creado en la auditoría de datos: el candidato no tenía proceso.')`,
                [candidato.id_candidato, candidato.id_vacante, candidato.fecha_postulacion]
            );

            await consultar(
                `INSERT INTO proceso_historial (id_proceso, etapa_anterior, etapa_nueva, observacion, fecha)
                 VALUES (?, NULL, 'Postulado', 'Proceso creado en la auditoría de datos', ?)`,
                [proceso.insertId, candidato.fecha_postulacion]
            );
        }
    }
};
