// Restricciones CHECK para que MySQL rechace valores no válidos
// aunque se inserten fuera de AveRH. Solo se añaden si todos
// los datos existentes ya las cumplen (si no, la migración se detiene).

const { agregarCheck } = require("./utilidades");

const ESTADO = "estado IN ('Activo','Inactivo')";

module.exports = {

    descripcion: "Añade restricciones CHECK de estados, roles, niveles y salarios",

    async aplicar(consultar) {

        for (const tabla of ["competencias", "idiomas", "capacitaciones", "departamentos", "puestos", "empleados", "candidatos"]) {
            await agregarCheck(consultar, tabla, `chk_${tabla}_estado`, ESTADO);
        }

        await agregarCheck(consultar, "usuarios", "chk_usuarios_estado", ESTADO);
        await agregarCheck(consultar, "usuarios", "chk_usuarios_rol", "rol IN ('Administrador','Recursos Humanos')");
        await agregarCheck(consultar, "vacantes", "chk_vacantes_estado", "estado IN ('Abierta','Cerrada')");
        await agregarCheck(consultar, "candidato_idiomas", "chk_candidato_idiomas_nivel", "nivel IN ('Básico','Intermedio','Avanzado','Nativo')");
        await agregarCheck(consultar, "puestos", "chk_puestos_salarios", "salario_minimo IS NULL OR salario_maximo IS NULL OR salario_minimo <= salario_maximo");
        await agregarCheck(consultar, "puestos", "chk_puestos_riesgo", "nivel_riesgo IS NULL OR nivel_riesgo IN ('Bajo','Medio','Alto')");
        await agregarCheck(consultar, "capacitaciones", "chk_capacitaciones_fechas", "fecha_desde IS NULL OR fecha_hasta IS NULL OR fecha_desde <= fecha_hasta");
        await agregarCheck(consultar, "experiencia_laboral", "chk_experiencia_fechas", "fecha_desde IS NULL OR fecha_hasta IS NULL OR fecha_desde <= fecha_hasta");
    }
};
