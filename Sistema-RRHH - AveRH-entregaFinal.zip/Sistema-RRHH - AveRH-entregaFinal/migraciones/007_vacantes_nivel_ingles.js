// Unifica vacantes.nivel_ingles con los niveles de idioma
// de AveRH ("Basico" → "Básico"; vacío → "No requerido").

const { agregarCheck } = require("./utilidades");

const EQUIVALENCIAS = {
    "Basico": "Básico",
    "Basica": "Básico",
    "Intermedia": "Intermedio",
    "Avanzada": "Avanzado"
};

module.exports = {

    descripcion: "Normaliza vacantes.nivel_ingles y restringe sus valores",

    async aplicar(consultar) {

        for (const [anterior, nuevo] of Object.entries(EQUIVALENCIAS)) {
            await consultar(
                "UPDATE vacantes SET nivel_ingles = ? WHERE BINARY nivel_ingles = ?",
                [nuevo, anterior]
            );
        }

        await consultar(
            "UPDATE vacantes SET nivel_ingles = 'No requerido' WHERE nivel_ingles IS NULL OR nivel_ingles = ''"
        );

        await agregarCheck(
            consultar,
            "vacantes",
            "chk_vacantes_nivel_ingles",
            "nivel_ingles IN ('No requerido','Básico','Intermedio','Avanzado','Nativo')"
        );
    }
};
