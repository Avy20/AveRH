// ==========================================
// AveRH - Servidor
// Uso: npm start  (o node server.js)
// ==========================================

require("dotenv").config({ quiet: true });

const { crearApp } = require("./src/app");
const { consultar, comprobarConexion } = require("./src/db");

// Puerto 3000 por defecto. AVERH_PUERTO permite levantar
// una copia de prueba sin detener la principal.
const PUERTO = Number(process.env.AVERH_PUERTO) || 3000;


async function comprobarBaseDeDatos() {

    try {

        const baseDatos = await comprobarConexion();
        console.log(`MySQL conectado. Base de datos: ${baseDatos}`);

        const [{ migraciones }] = await consultar(
            `SELECT COUNT(*) AS migraciones FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'schema_migraciones'`
        );

        if (Number(migraciones) === 0) {
            console.warn("ATENCIÓN: faltan migraciones. Ejecuta: npm run migrar");
            return;
        }

        const [{ usuarios }] = await consultar(
            "SELECT COUNT(*) AS usuarios FROM usuarios WHERE estado = 'Activo'"
        );

        if (Number(usuarios) === 0) {
            console.warn("ATENCIÓN: no hay usuarios. Crea el primer administrador con: npm run crear-admin");
        }

    } catch (error) {

        console.error("");
        console.error("ERROR AL CONECTAR CON MYSQL:", error.message);
        console.error("Comprueba que MySQL esté iniciado y los datos del archivo .env.");
        console.error("");
    }
}


crearApp().listen(PUERTO, async () => {

    console.log("");
    console.log("======================================");
    console.log("   AveRH - Reclutamiento y Selección");
    console.log("======================================");
    console.log(`Abre AveRH en: http://localhost:${PUERTO}`);
    console.log("");

    await comprobarBaseDeDatos();
});
