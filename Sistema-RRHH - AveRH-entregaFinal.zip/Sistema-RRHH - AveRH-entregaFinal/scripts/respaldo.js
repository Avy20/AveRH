// ==========================================
// AveRH - Respaldo verificable de MySQL
// Uso: npm run respaldo
//
// Genera respaldos/<base>_<fecha>.sql con mysqldump y
// verifica que el archivo esté completo: que el volcado
// terminó y que contiene todas las tablas con sus filas.
// ==========================================

require("dotenv").config({ quiet: true });

const fs = require("fs");
const path = require("path");
const { spawn, spawnSync } = require("child_process");
const mysql = require("mysql2/promise");

const CARPETA_RESPALDOS = path.join(__dirname, "..", "respaldos");

const RUTAS_MYSQLDUMP = [
    process.env.MYSQLDUMP_RUTA,
    "C:\\Program Files\\MySQL\\MySQL Server 8.4\\bin\\mysqldump.exe",
    "C:\\Program Files\\MySQL\\MySQL Server 8.0\\bin\\mysqldump.exe",
    "C:\\xampp\\mysql\\bin\\mysqldump.exe",
    "/usr/bin/mysqldump",
    "/usr/local/bin/mysqldump",
    "/opt/homebrew/bin/mysqldump"
];


function buscarMysqldump() {

    for (const ruta of RUTAS_MYSQLDUMP) {
        if (ruta && fs.existsSync(ruta)) {
            return ruta;
        }
    }

    // ¿Está en el PATH?
    const prueba = spawnSync("mysqldump", ["--version"], { encoding: "utf8" });

    if (prueba.status === 0) {
        return "mysqldump";
    }

    throw new Error(
        "No se encontró mysqldump. Indica su ruta en la variable MYSQLDUMP_RUTA."
    );
}


function marcaDeTiempo() {

    const f = new Date();
    const dos = n => String(n).padStart(2, "0");

    return `${f.getFullYear()}${dos(f.getMonth() + 1)}${dos(f.getDate())}_` +
        `${dos(f.getHours())}${dos(f.getMinutes())}${dos(f.getSeconds())}`;
}


function ejecutarMysqldump(ejecutable, archivo) {

    return new Promise((resolve, reject) => {

        const salida = fs.createWriteStream(archivo);
        let errores = "";

        const proceso = spawn(ejecutable, [
            "-h", process.env.DB_HOST,
            "-P", String(process.env.DB_PORT || 3306),
            "-u", process.env.DB_USER,
            "--single-transaction",
            "--routines",
            "--triggers",
            // Un INSERT por fila: permite verificar el conteo exacto.
            "--skip-extended-insert",
            "--default-character-set=utf8mb4",
            process.env.DB_NAME
        ], {
            // La contraseña viaja por variable de entorno,
            // nunca por la línea de comandos.
            env: { ...process.env, MYSQL_PWD: process.env.DB_PASSWORD }
        });

        proceso.stdout.pipe(salida);
        proceso.stderr.on("data", dato => { errores += dato; });

        proceso.on("error", reject);

        proceso.on("close", codigo => {
            salida.close(() => {
                if (codigo === 0) {
                    resolve();
                } else {
                    reject(new Error(`mysqldump terminó con código ${codigo}: ${errores.trim()}`));
                }
            });
        });
    });
}


// Comprueba que el respaldo contiene todas las tablas
// y tantas filas como la base de datos real.
async function verificarRespaldo(archivo) {

    const contenido = fs.readFileSync(archivo, "utf8");

    if (!/-- Dump completed/.test(contenido)) {
        throw new Error("El respaldo está incompleto (falta la marca de fin de mysqldump).");
    }

    const lineas = contenido.split(/\r?\n/);

    const conexion = await mysql.createConnection({
        host: process.env.DB_HOST,
        port: Number(process.env.DB_PORT) || 3306,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
    });

    try {

        const [tablas] = await conexion.query(
            "SELECT TABLE_NAME AS nombre FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE'"
        );

        const resumen = [];

        for (const { nombre } of tablas) {

            if (!contenido.includes(`CREATE TABLE \`${nombre}\``)) {
                throw new Error(`El respaldo no contiene la tabla ${nombre}.`);
            }

            const [[{ filas }]] = await conexion.query(
                `SELECT COUNT(*) AS filas FROM \`${nombre}\``
            );

            // Con --skip-extended-insert hay una línea INSERT por fila.
            const prefijo = `INSERT INTO \`${nombre}\` VALUES`;

            const filasEnRespaldo = lineas
                .filter(linea => linea.startsWith(prefijo))
                .length;

            if (filasEnRespaldo !== Number(filas)) {
                throw new Error(
                    `La tabla ${nombre} tiene ${filas} filas pero el respaldo contiene ${filasEnRespaldo}.`
                );
            }

            resumen.push({ tabla: nombre, filas: Number(filas) });
        }

        return resumen;

    } finally {
        await conexion.end();
    }
}


async function crearRespaldo({ silencioso = false } = {}) {

    fs.mkdirSync(CARPETA_RESPALDOS, { recursive: true });

    const archivo = path.join(
        CARPETA_RESPALDOS,
        `${process.env.DB_NAME}_${marcaDeTiempo()}.sql`
    );

    let resumen;

    try {

        await ejecutarMysqldump(buscarMysqldump(), archivo);

        resumen = await verificarRespaldo(archivo);

    } catch (error) {

        // Un respaldo que no supera la verificación no debe
        // confundirse con uno válido.
        if (fs.existsSync(archivo)) {
            fs.renameSync(archivo, `${archivo}.INVALIDO`);
        }

        throw error;
    }

    if (!silencioso) {
        console.log("");
        console.log(`Respaldo creado y verificado: ${path.relative(process.cwd(), archivo)}`);
        console.table(resumen);
    }

    return { archivo, resumen };
}


module.exports = { crearRespaldo, verificarRespaldo };


if (require.main === module) {

    crearRespaldo().catch(error => {
        console.error("");
        console.error("No se pudo crear el respaldo:", error.message);
        process.exitCode = 1;
    });
}
