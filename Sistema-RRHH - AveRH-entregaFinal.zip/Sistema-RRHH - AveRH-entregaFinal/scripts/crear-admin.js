// ==========================================
// AveRH - CREAR ADMINISTRADOR
// Uso: npm run crear-admin
//
// Crea un usuario Administrador en la tabla usuarios con la
// contraseña cifrada (bcrypt). Pide los datos por la terminal;
// la contraseña se muestra como asteriscos y nunca se imprime
// ni se guarda en texto plano.
// No modifica ni elimina ningún otro dato.
// ==========================================

require("dotenv").config({ quiet: true });

const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");

const CORREO_VALIDO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const LONGITUD_MINIMA_CONTRASENA = 8;
const COSTE_BCRYPT = 12;


// ------------------------------------------
// LECTURA DESDE LA TERMINAL
//
// En una terminal (PowerShell, CMD, VS Code...) se lee el teclado
// carácter a carácter en "modo crudo". Así se controla qué se
// muestra (asteriscos en la contraseña) sin depender de funciones
// internas de Node. Si la entrada viene de un archivo o tubería,
// se leen líneas completas.
// ------------------------------------------

function crearLector() {

    const entrada = process.stdin;
    const esTerminal = Boolean(entrada.isTTY && typeof entrada.setRawMode === "function");

    entrada.setEncoding("utf8");

    let pendiente = "";          // texto recibido y aún no consumido
    let ignorarSaltoLinea = false; // tras "\r" puede llegar "\n" (Enter de Windows)
    let alRecibir = null;
    let finalizada = false;

    entrada.on("data", fragmento => {
        pendiente += fragmento;
        alRecibir?.();
    });

    entrada.on("end", () => {
        finalizada = true;
        alRecibir?.();
    });

    if (esTerminal) {
        entrada.setRawMode(true);
    }

    entrada.resume();


    // Espera hasta que haya más texto (o fin de la entrada).
    const esperarDatos = () => new Promise(resolve => {
        alRecibir = () => {
            alRecibir = null;
            resolve();
        };
    });


    async function leerEnTerminal(oculta) {

        let valor = "";
        let escape = null; // estado de una secuencia de escape en curso

        for (;;) {

            if (!pendiente) {
                await esperarDatos();
                continue;
            }

            const caracter = pendiente[0];
            pendiente = pendiente.slice(1);

            if (ignorarSaltoLinea) {
                ignorarSaltoLinea = false;
                if (caracter === "\n") continue;
            }

            // Enter: "\r" (Windows y la mayoría de terminales) o "\n".
            if (caracter === "\r" || caracter === "\n") {
                ignorarSaltoLinea = caracter === "\r";
                process.stdout.write("\n");
                return valor;
            }

            // Ctrl+C: se cancela sin crear nada.
            if (caracter === "\u0003") {
                process.stdout.write("\n");
                throw new Error("Operación cancelada.");
            }

            // Retroceso (Backspace llega como DEL o BS según la terminal).
            if (caracter === "\u007f" || caracter === "\b") {
                if (valor.length > 0) {
                    valor = valor.slice(0, -1);
                    process.stdout.write("\b \b");
                }
                continue;
            }

            // Flechas y teclas especiales (ESC [ ... letra): se ignoran
            // completas, aunque lleguen carácter a carácter.
            if (escape === "inicio") {
                escape = caracter === "[" || caracter === "O" ? "cuerpo" : null;
                continue;
            }

            if (escape === "cuerpo") {
                if (/[A-Za-z~]/.test(caracter)) escape = null;
                continue;
            }

            if (caracter === "\u001b") {
                escape = "inicio";
                continue;
            }

            // Otros caracteres de control.
            if (caracter < " ") {
                continue;
            }

            valor += caracter;
            process.stdout.write(oculta ? "*" : caracter);
        }
    }


    async function leerLinea() {

        for (;;) {

            const fin = pendiente.search(/\r?\n/);

            if (fin >= 0) {
                const linea = pendiente.slice(0, fin);
                pendiente = pendiente.slice(fin).replace(/^\r?\n/, "");
                return linea;
            }

            if (finalizada) {
                const linea = pendiente;
                pendiente = "";
                return linea;
            }

            await esperarDatos();
        }
    }


    return {

        async preguntar(texto, { oculta = false } = {}) {

            process.stdout.write(texto);

            const respuesta = esTerminal
                ? await leerEnTerminal(oculta)
                : await leerLinea();

            if (!esTerminal) {
                process.stdout.write(oculta ? "********\n" : `${respuesta}\n`);
            }

            return respuesta.trim();
        },

        cerrar() {
            if (esTerminal) {
                entrada.setRawMode(false);
            }
            entrada.pause();
            entrada.removeAllListeners("data");
            entrada.removeAllListeners("end");
        }
    };
}


async function crearAdministrador() {

    console.log("");
    console.log("======================================");
    console.log("   AveRH - Crear administrador");
    console.log("======================================");
    console.log("Base de datos: " + process.env.DB_NAME);
    console.log("La contraseña se mostrará con asteriscos (*). Ctrl+C cancela.");
    console.log("");

    const lector = crearLector();

    let nombre, correo, contrasena, confirmar;

    try {
        nombre = await lector.preguntar("Nombre completo: ");
        correo = (await lector.preguntar("Correo electrónico: ")).toLowerCase();
        contrasena = await lector.preguntar(`Contraseña (mínimo ${LONGITUD_MINIMA_CONTRASENA} caracteres): `, { oculta: true });
        confirmar = await lector.preguntar("Confirmar contraseña: ", { oculta: true });
    } finally {
        lector.cerrar();
    }

    if (nombre.length < 3 || nombre.length > 150) {
        throw new Error("El nombre debe tener entre 3 y 150 caracteres.");
    }

    if (!CORREO_VALIDO.test(correo) || correo.length > 150) {
        throw new Error("El correo electrónico no es válido.");
    }

    if (contrasena.length < LONGITUD_MINIMA_CONTRASENA) {
        throw new Error(`La contraseña debe tener al menos ${LONGITUD_MINIMA_CONTRASENA} caracteres.`);
    }

    if (contrasena !== confirmar) {
        throw new Error("Las contraseñas no coinciden.");
    }

    console.log("");
    console.log("Conectando con MySQL...");

    let conexion;

    try {
        conexion = await mysql.createConnection({
            host: process.env.DB_HOST,
            port: Number(process.env.DB_PORT) || 3306,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME,
            connectTimeout: 10000
        });
    } catch (error) {
        throw new Error(`No se pudo conectar con MySQL (${error.code || error.message}). Comprueba que el servicio esté iniciado.`);
    }

    try {

        const [existentes] = await conexion.query(
            "SELECT id_usuario FROM usuarios WHERE correo = ? LIMIT 1",
            [correo]
        );

        if (existentes.length > 0) {
            throw new Error("Ya existe un usuario con ese correo.");
        }

        console.log("Cifrando la contraseña...");

        const hash = await bcrypt.hash(contrasena, COSTE_BCRYPT);

        const [resultado] = await conexion.query(
            `INSERT INTO usuarios (nombre, correo, contrasena, rol, estado)
             VALUES (?, ?, ?, 'Administrador', 'Activo')`,
            [nombre, correo, hash]
        );

        console.log("");
        console.log(`Administrador creado correctamente (ID ${resultado.insertId}): ${correo}`);
        console.log("Inicia AveRH con «npm start» y entra en http://localhost:3000");
        console.log("");

    } finally {
        await conexion.end();
    }
}


crearAdministrador().catch(error => {

    console.error("");
    console.error("No se creó el administrador:", error.message);
    console.error("");

    process.exitCode = 1;
});
