// ==========================================
// AveRH - Entorno de pruebas automáticas
//
// 1. Restaura el respaldo más reciente en <DB_NAME>_pruebas.
// 2. Aplica las migraciones a esa copia.
// 3. Crea usuarios de prueba y levanta la API en un puerto libre.
// Los datos reales nunca se modifican.
// ==========================================

require("dotenv").config({ quiet: true });

const { prepararBaseDePruebas, BASE_PRUEBAS } = require("./preparar-bd");


// Cédula dominicana válida a partir de 10 dígitos.
function generarCedula(base10) {

    const digitos = String(base10).padStart(10, "0").slice(0, 10);
    let suma = 0;

    for (let i = 0; i < 10; i++) {
        let producto = Number(digitos[i]) * (i % 2 === 0 ? 1 : 2);
        if (producto >= 10) producto -= 9;
        suma += producto;
    }

    const verificador = (10 - (suma % 10)) % 10;
    const n = digitos + verificador;

    return `${n.slice(0, 3)}-${n.slice(3, 10)}-${n.slice(10)}`;
}


// Cliente HTTP con su propia cookie de sesión.
function crearCliente(base) {

    let cookie = "";

    async function peticion(metodo, ruta, cuerpo, { json = true } = {}) {

        const cabeceras = {};

        if (cookie) cabeceras.Cookie = cookie;
        if (json && metodo !== "GET") cabeceras["Content-Type"] = "application/json";

        const respuesta = await fetch(base + ruta, {
            method: metodo,
            headers: cabeceras,
            body: cuerpo === undefined ? (json && metodo !== "GET" ? "{}" : undefined) : JSON.stringify(cuerpo)
        });

        const nuevaCookie = respuesta.headers.get("set-cookie");

        if (nuevaCookie) {
            cookie = nuevaCookie.split(";")[0];
        }

        const texto = await respuesta.text();
        let datos = null;

        try { datos = JSON.parse(texto); } catch { datos = texto; }

        return { estado: respuesta.status, datos, cabeceras: respuesta.headers };
    }

    return {
        get: ruta => peticion("GET", ruta),
        post: (ruta, cuerpo) => peticion("POST", ruta, cuerpo),
        put: (ruta, cuerpo) => peticion("PUT", ruta, cuerpo),
        patch: (ruta, cuerpo) => peticion("PATCH", ruta, cuerpo),
        delete: ruta => peticion("DELETE", ruta),
        crudo: peticion,
        cookie: () => cookie,
        async login(correo, contrasena) {
            return peticion("POST", "/api/auth/login", { correo, contrasena });
        }
    };
}


const USUARIOS_PRUEBA = {
    admin: { nombre: "Admin Pruebas", correo: "admin@pruebas.averh", contrasena: "ClaveAdmin123", rol: "Administrador" },
    rh: { nombre: "Analista Pruebas", correo: "rh@pruebas.averh", contrasena: "ClaveRH12345", rol: "Recursos Humanos" }
};


async function iniciarEntorno() {

    await prepararBaseDePruebas({ silencioso: true });

    // A partir de aquí todo el código usa la base de pruebas.
    process.env.DB_NAME = BASE_PRUEBAS;

    const { ejecutarMigraciones } = require("../migraciones/ejecutar");
    await ejecutarMigraciones({ respaldo: false, silencioso: true });

    const bcrypt = require("bcryptjs");
    const { consultar, pool } = require("../src/db");

    for (const usuario of Object.values(USUARIOS_PRUEBA)) {
        await consultar(
            "INSERT INTO usuarios (nombre, correo, contrasena, rol, estado) VALUES (?, ?, ?, ?, 'Activo')",
            [usuario.nombre, usuario.correo, await bcrypt.hash(usuario.contrasena, 4), usuario.rol]
        );
    }

    const { crearApp } = require("../src/app");

    const servidor = await new Promise(resolve => {
        const s = crearApp().listen(0, () => resolve(s));
    });

    const base = `http://localhost:${servidor.address().port}`;

    return {
        base,
        consultar,
        nuevoCliente: () => crearCliente(base),
        async cerrar() {
            await new Promise(resolve => servidor.close(resolve));
            await pool.end();
        }
    };
}


module.exports = { iniciarEntorno, generarCedula, USUARIOS_PRUEBA };
