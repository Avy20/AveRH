// ==========================================
// AveRH - Base de datos de pruebas
//
// Crea (o recrea) <DB_NAME>_pruebas restaurando el respaldo
// más reciente de la carpeta respaldos/. Así las pruebas
// automáticas nunca modifican los datos reales.
//
// También sirve para comprobar que un respaldo se puede restaurar.
// ==========================================

require("dotenv").config({ quiet: true });

const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");

const BASE_REAL = process.env.DB_NAME_REAL || process.env.DB_NAME;
const BASE_PRUEBAS = `${BASE_REAL}_pruebas`;


function respaldoMasReciente() {

    const carpeta = path.join(__dirname, "..", "respaldos");

    const archivos = fs.existsSync(carpeta)
        ? fs.readdirSync(carpeta).filter(a => a.startsWith(`${BASE_REAL}_`) && a.endsWith(".sql")).sort()
        : [];

    if (archivos.length === 0) {
        throw new Error("No hay respaldos. Ejecuta primero: npm run respaldo");
    }

    return path.join(carpeta, archivos[archivos.length - 1]);
}


async function prepararBaseDePruebas({ archivo = respaldoMasReciente(), silencioso = false } = {}) {

    // Protección: nunca se recrea la base real.
    if (!BASE_PRUEBAS.endsWith("_pruebas") || BASE_PRUEBAS === BASE_REAL) {
        throw new Error("Nombre de base de pruebas no seguro.");
    }

    const conexion = await mysql.createConnection({
        host: process.env.DB_HOST,
        port: Number(process.env.DB_PORT) || 3306,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        multipleStatements: true,
        charset: "utf8mb4"
    });

    try {

        await conexion.query(`DROP DATABASE IF EXISTS \`${BASE_PRUEBAS}\``);
        await conexion.query(
            `CREATE DATABASE \`${BASE_PRUEBAS}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci`
        );
        await conexion.query(`USE \`${BASE_PRUEBAS}\``);
        await conexion.query(fs.readFileSync(archivo, "utf8"));

        if (!silencioso) {
            console.log(`Base ${BASE_PRUEBAS} restaurada desde ${path.basename(archivo)}`);
        }

        return BASE_PRUEBAS;

    } finally {
        await conexion.end();
    }
}


module.exports = { prepararBaseDePruebas, BASE_PRUEBAS, BASE_REAL };


if (require.main === module) {

    prepararBaseDePruebas().catch(error => {
        console.error("No se pudo preparar la base de pruebas:", error.message);
        process.exitCode = 1;
    });
}
