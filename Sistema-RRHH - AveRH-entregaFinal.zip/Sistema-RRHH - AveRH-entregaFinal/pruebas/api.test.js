// ==========================================
// AveRH - Pruebas de la API
// Uso: npm test
// Se ejecutan contra una copia (<DB_NAME>_pruebas).
// ==========================================

const { describe, it, before, after } = require("node:test");
const assert = require("node:assert/strict");

const { iniciarEntorno, generarCedula, USUARIOS_PRUEBA } = require("./entorno");

let entorno;
let admin;
let rh;

const hoy = () => new Date().toISOString().slice(0, 10);


before(async () => {

    entorno = await iniciarEntorno();

    admin = entorno.nuevoCliente();
    rh = entorno.nuevoCliente();

    assert.equal((await admin.login(USUARIOS_PRUEBA.admin.correo, USUARIOS_PRUEBA.admin.contrasena)).estado, 200);
    assert.equal((await rh.login(USUARIOS_PRUEBA.rh.correo, USUARIOS_PRUEBA.rh.contrasena)).estado, 200);
});

after(async () => {
    await entorno?.cerrar();
});


// ------------------------------------------------------------
describe("Seguridad y archivos públicos", () => {

    it("sirve la aplicación y la pantalla de login", async () => {
        const anonimo = entorno.nuevoCliente();
        assert.equal((await anonimo.get("/")).estado, 200);
        assert.equal((await anonimo.get("/login.html")).estado, 200);
    });

    it("no expone archivos del servidor", async () => {
        const anonimo = entorno.nuevoCliente();
        for (const ruta of ["/.env", "/server.js", "/src/app.js", "/package.json", "/respaldos/", "/%2e%2e/.env"]) {
            const respuesta = await anonimo.get(ruta);
            assert.equal(respuesta.estado, 404, ruta);
        }
    });

    it("envía cabeceras de seguridad", async () => {
        const respuesta = await entorno.nuevoCliente().get("/");
        assert.match(respuesta.cabeceras.get("content-security-policy"), /default-src 'self'/);
        assert.equal(respuesta.cabeceras.get("x-frame-options"), "DENY");
        assert.equal(respuesta.cabeceras.get("x-powered-by"), null);
    });

    it("exige sesión en la API", async () => {
        const anonimo = entorno.nuevoCliente();
        for (const ruta of ["/api/candidatos", "/api/panel", "/api/usuarios", "/api/auth/me"]) {
            assert.equal((await anonimo.get(ruta)).estado, 401, ruta);
        }
    });

    it("rechaza modificaciones que no son JSON (protección CSRF)", async () => {
        const respuesta = await admin.crudo("POST", "/api/competencias", undefined, { json: false });
        assert.equal(respuesta.estado, 415);
    });

    it("responde 404 en JSON para rutas de API inexistentes", async () => {
        const respuesta = await admin.get("/api/no-existe");
        assert.equal(respuesta.estado, 404);
        assert.equal(respuesta.datos.correcto, false);
    });
});


// ------------------------------------------------------------
describe("Autenticación", () => {

    it("rechaza credenciales incorrectas con un mensaje genérico", async () => {
        const cliente = entorno.nuevoCliente();
        const malaClave = await cliente.login(USUARIOS_PRUEBA.admin.correo, "incorrecta");
        const sinUsuario = await cliente.login("nadie@pruebas.averh", "incorrecta");
        assert.equal(malaClave.estado, 401);
        assert.equal(sinUsuario.estado, 401);
        assert.equal(malaClave.datos.mensaje, sinUsuario.datos.mensaje);
    });

    it("acepta el correo sin distinguir mayúsculas y devuelve el usuario", async () => {
        const cliente = entorno.nuevoCliente();
        const respuesta = await cliente.login(USUARIOS_PRUEBA.admin.correo.toUpperCase(), USUARIOS_PRUEBA.admin.contrasena);
        assert.equal(respuesta.estado, 200);
        assert.equal(respuesta.datos.datos.rol, "Administrador");
        assert.equal(respuesta.datos.datos.contrasena, undefined);
        const yo = await cliente.get("/api/auth/me");
        assert.equal(yo.datos.datos.correo, USUARIOS_PRUEBA.admin.correo);
    });

    it("la cookie de sesión es HttpOnly y SameSite", async () => {
        const respuesta = await entorno.nuevoCliente().login(USUARIOS_PRUEBA.rh.correo, USUARIOS_PRUEBA.rh.contrasena);
        const cookie = respuesta.cabeceras.get("set-cookie");
        assert.match(cookie, /HttpOnly/i);
        assert.match(cookie, /SameSite=Lax/i);
    });

    it("bloquea tras 5 intentos fallidos", async () => {
        const cliente = entorno.nuevoCliente();
        const correo = "bloqueo@pruebas.averh";
        for (let i = 0; i < 5; i++) {
            assert.equal((await cliente.login(correo, "x")).estado, 401);
        }
        assert.equal((await cliente.login(correo, "x")).estado, 429);
    });

    it("cierra la sesión", async () => {
        const cliente = entorno.nuevoCliente();
        await cliente.login(USUARIOS_PRUEBA.rh.correo, USUARIOS_PRUEBA.rh.contrasena);
        assert.equal((await cliente.post("/api/auth/logout")).estado, 200);
        assert.equal((await cliente.get("/api/auth/me")).estado, 401);
    });
});


// ------------------------------------------------------------
describe("Usuarios y roles", () => {

    let idNuevo;

    it("Recursos Humanos no puede administrar usuarios", async () => {
        assert.equal((await rh.get("/api/usuarios")).estado, 403);
        assert.equal((await rh.post("/api/usuarios", {})).estado, 403);
    });

    it("el administrador crea un usuario con la contraseña cifrada", async () => {
        const respuesta = await admin.post("/api/usuarios", {
            nombre: "Usuario Temporal", correo: "temporal@pruebas.averh",
            rol: "Recursos Humanos", contrasena: "Temporal123"
        });
        assert.equal(respuesta.estado, 201);
        idNuevo = respuesta.datos.datos.id;
        const [fila] = await entorno.consultar("SELECT contrasena FROM usuarios WHERE id_usuario = ?", [idNuevo]);
        assert.match(fila.contrasena, /^\$2[aby]\$12\$/);
    });

    it("valida los datos del usuario", async () => {
        const base = { nombre: "Otro", correo: "otro@pruebas.averh", rol: "Recursos Humanos", contrasena: "Temporal123" };
        assert.equal((await admin.post("/api/usuarios", { ...base, correo: "temporal@pruebas.averh" })).estado, 409);
        assert.equal((await admin.post("/api/usuarios", { ...base, contrasena: "corta" })).datos.campo, "contrasena");
        assert.equal((await admin.post("/api/usuarios", { ...base, rol: "Jefe" })).datos.campo, "rol");
        assert.equal((await admin.post("/api/usuarios", { ...base, correo: "no-es-correo" })).datos.campo, "correo");
    });

    it("permite cambiar la contraseña y desactivar con efecto inmediato", async () => {

        const usuario = entorno.nuevoCliente();

        await admin.put(`/api/usuarios/${idNuevo}`, {
            nombre: "Usuario Temporal", correo: "temporal@pruebas.averh",
            rol: "Recursos Humanos", contrasena: "NuevaClave456"
        });

        assert.equal((await usuario.login("temporal@pruebas.averh", "Temporal123")).estado, 401);
        assert.equal((await usuario.login("temporal@pruebas.averh", "NuevaClave456")).estado, 200);
        assert.equal((await usuario.get("/api/candidatos")).estado, 200);

        assert.equal((await admin.patch(`/api/usuarios/${idNuevo}/estado`, { estado: "Inactivo" })).estado, 200);
        assert.equal((await usuario.get("/api/candidatos")).estado, 401);
        assert.equal((await usuario.login("temporal@pruebas.averh", "NuevaClave456")).estado, 403);
    });

    it("un administrador no puede desactivarse ni quitarse el rol", async () => {
        const yo = (await admin.get("/api/auth/me")).datos.datos;
        assert.equal((await admin.patch(`/api/usuarios/${yo.id}/estado`, { estado: "Inactivo" })).estado, 400);
        const cambio = await admin.put(`/api/usuarios/${yo.id}`, { nombre: yo.nombre, correo: yo.correo, rol: "Recursos Humanos" });
        assert.equal(cambio.estado, 400);
    });
});


// ------------------------------------------------------------
describe("Catálogos", () => {

    let idCompetencia;

    it("crea, impide duplicados (sin distinguir mayúsculas ni acentos) y edita", async () => {

        const creada = await rh.post("/api/competencias", { descripcion: "Pensamiento Sistémico" });
        assert.equal(creada.estado, 201);
        idCompetencia = creada.datos.datos.id_competencia;

        const duplicada = await rh.post("/api/competencias", { descripcion: "pensamiento sistemico" });
        assert.equal(duplicada.estado, 409);
        assert.equal(duplicada.datos.campo, "descripcion");

        const editada = await rh.put(`/api/competencias/${idCompetencia}`, { descripcion: "Pensamiento sistémico" });
        assert.equal(editada.estado, 200);
        assert.equal(editada.datos.datos.descripcion, "Pensamiento sistémico");
    });

    it("activa y desactiva, y filtra por estado", async () => {
        assert.equal((await rh.patch(`/api/competencias/${idCompetencia}/estado`, { estado: "Inactivo" })).estado, 200);
        const activas = (await rh.get("/api/competencias?estado=Activo")).datos.datos;
        assert.ok(!activas.some(c => c.id_competencia === idCompetencia));
        assert.equal((await rh.patch(`/api/competencias/${idCompetencia}/estado`, { estado: "Otro" })).estado, 400);
    });

    it("solo el administrador elimina, y nunca algo en uso", async () => {
        assert.equal((await rh.delete(`/api/competencias/${idCompetencia}`)).estado, 403);
        const enUso = await admin.delete("/api/competencias/1");
        assert.equal(enUso.estado, 409);
        assert.match(enUso.datos.mensaje, /desactivar/i);
        assert.equal((await admin.delete(`/api/competencias/${idCompetencia}`)).estado, 200);
        assert.equal((await admin.get(`/api/competencias/${idCompetencia}`)).estado, 404);
    });

    it("valida fechas de capacitaciones y rangos de puestos", async () => {
        const capacitacion = await rh.post("/api/capacitaciones", {
            descripcion: "Curso de prueba", nivel: "Técnico", fecha_desde: "2025-05-01",
            fecha_hasta: "2025-01-01", institucion: "INFOTEP"
        });
        assert.equal(capacitacion.estado, 400);
        assert.equal(capacitacion.datos.campo, "fecha_hasta");

        const puesto = await rh.post("/api/puestos", {
            nombre: "Puesto inválido", id_departamento: 1, nivel_riesgo: "Bajo",
            salario_minimo: 90000, salario_maximo: 50000
        });
        assert.equal(puesto.estado, 400);
        assert.equal(puesto.datos.campo, "salario_minimo");
    });

    it("la oferta de una vacante debe respetar el rango del puesto", async () => {
        const vacante = await rh.post("/api/vacantes", {
            id_puesto: 11, titulo: "Asistente", cantidad_vacantes: 1,
            fecha_publicacion: hoy(), salario_minimo: 10000, salario_maximo: 30000
        });
        assert.equal(vacante.estado, 400);
        assert.equal(vacante.datos.campo, "salario_minimo");
    });
});


// ------------------------------------------------------------
describe("Candidatos, proceso y contratación", () => {

    const cedula = generarCedula("4029900011");
    let idCandidato;
    let idVacanteCerrada;

    const nuevo = (cambios = {}) => ({
        cedula, nombre: "María José Peña", correo: "mjpena@correo.com", telefono: "809-555-1234",
        id_vacante: 2, salario_aspira: 60000, fuente_reclutamiento: "LinkedIn",
        fecha_postulacion: hoy(), ...cambios
    });

    it("valida cédula, nombre, salario y vacante", async () => {

        const cedulaMala = await rh.post("/api/candidatos", nuevo({ cedula: "402-9900011-0" === cedula ? "402-9900011-1" : "402-9900011-0" }));
        assert.equal(cedulaMala.estado, 400);
        assert.equal(cedulaMala.datos.campo, "cedula");

        const nombreMalo = await rh.post("/api/candidatos", nuevo({ nombre: "María <script>" }));
        assert.equal(nombreMalo.datos.campo, "nombre");

        const salario = await rh.post("/api/candidatos", nuevo({ salario_aspira: 200000 }));
        assert.equal(salario.estado, 400);
        assert.equal(salario.datos.campo, "salario_aspira");

        const futura = await rh.post("/api/candidatos", nuevo({ fecha_postulacion: "2999-01-01" }));
        assert.equal(futura.datos.campo, "fecha_postulacion");

        [{ id_vacante: idVacanteCerrada }] = await entorno.consultar("SELECT id_vacante FROM vacantes WHERE estado = 'Cerrada' LIMIT 1");
        const cerrada = await rh.post("/api/candidatos", nuevo({ id_vacante: idVacanteCerrada, salario_aspira: 60000 }));
        assert.equal(cerrada.estado, 400);
        assert.equal(cerrada.datos.campo, "id_vacante");
    });

    it("registra el candidato con su proceso e historial", async () => {

        const respuesta = await rh.post("/api/candidatos", nuevo());
        assert.equal(respuesta.estado, 201);

        const candidato = respuesta.datos.datos;
        idCandidato = candidato.id;

        assert.equal(candidato.etapa, "Postulado");
        assert.equal(candidato.puesto, "Analista de Datos");
        assert.equal(candidato.departamento, "Tecnología");
        assert.ok(candidato.fecha_actualizacion);

        const ficha = (await rh.get(`/api/candidatos/${idCandidato}`)).datos.datos;
        assert.equal(ficha.historial.length, 1);
        assert.equal(ficha.historial[0].usuario, USUARIOS_PRUEBA.rh.nombre);
    });

    it("impide cédulas duplicadas", async () => {
        const respuesta = await rh.post("/api/candidatos", nuevo({ correo: "otro@correo.com" }));
        assert.equal(respuesta.estado, 409);
        assert.equal(respuesta.datos.campo, "cedula");
    });

    it("edita candidatos antiguos sin exigir su cédula de prueba", async () => {
        const [antiguo] = await entorno.consultar("SELECT * FROM candidatos WHERE cedula = '000-0000000-0'");
        const respuesta = await rh.put(`/api/candidatos/${antiguo.id_candidato}`, {
            cedula: antiguo.cedula, nombre: antiguo.nombre, telefono: "809-555-0000",
            salario_aspira: Number(antiguo.salario_aspira), fuente_reclutamiento: antiguo.fuente_reclutamiento
        });
        assert.equal(respuesta.estado, 200, JSON.stringify(respuesta.datos));
        assert.equal(respuesta.datos.datos.telefono, "809-555-0000");
    });

    it("guarda el perfil profesional en una transacción", async () => {

        const invalido = await rh.put(`/api/candidatos/${idCandidato}/perfil`, {
            competencias: [1, 99999], capacitaciones: [], idiomas: []
        });
        assert.equal(invalido.estado, 400);

        const sinCambios = (await rh.get(`/api/candidatos/${idCandidato}`)).datos.datos;
        assert.equal(sinCambios.competencias.length, 0, "la transacción debe revertirse");

        const respuesta = await rh.put(`/api/candidatos/${idCandidato}/perfil`, {
            competencias: [1, 5], capacitaciones: [13], idiomas: [{ id: 1, nivel: "Nativo" }, { id: 2, nivel: "Avanzado" }]
        });
        assert.equal(respuesta.estado, 200);

        const ficha = (await rh.get(`/api/candidatos/${idCandidato}`)).datos.datos;
        assert.equal(ficha.competencias.length, 2);
        assert.equal(ficha.idiomas[0].nivel, "Nativo");
        assert.equal(ficha.capacitaciones.length, 1);
    });

    it("registra experiencia laboral y valida sus fechas", async () => {

        const mala = await rh.post("/api/experiencias", {
            id_candidato: idCandidato, empresa: "Empresa X", puesto_ocupado: "Analista",
            fecha_desde: "2024-01-01", fecha_hasta: "2023-01-01"
        });
        assert.equal(mala.datos.campo, "fecha_hasta");

        const buena = await rh.post("/api/experiencias", {
            id_candidato: idCandidato, empresa: "Empresa X", puesto_ocupado: "Analista",
            fecha_desde: "2020-01-01", fecha_hasta: "2024-01-01", salario: 45000
        });
        assert.equal(buena.estado, 201);

        const ficha = (await rh.get(`/api/candidatos/${idCandidato}`)).datos.datos;
        assert.equal(ficha.anios_experiencia, 4);
    });

    it("la consulta por criterios usa los datos reales de MySQL", async () => {

        const porCompetencias = (await rh.get("/api/consultas/candidatos?competencias=1,5")).datos.datos;
        assert.ok(porCompetencias.some(c => c.id === idCandidato));

        const [{ esperados }] = await entorno.consultar(`
            SELECT COUNT(*) AS esperados FROM candidatos c
            WHERE (SELECT COUNT(DISTINCT id_competencia) FROM candidato_competencias
                   WHERE id_candidato = c.id_candidato AND id_competencia IN (1, 5)) = 2`);
        assert.equal(porCompetencias.length, Number(esperados));

        const idioma = (await rh.get("/api/consultas/candidatos?id_idioma=2&nivel_idioma=Avanzado")).datos.datos;
        assert.ok(idioma.some(c => c.id === idCandidato));
        const idiomaNativo = (await rh.get("/api/consultas/candidatos?id_idioma=2&nivel_idioma=Nativo")).datos.datos;
        assert.ok(!idiomaNativo.some(c => c.id === idCandidato));

        const experiencia = (await rh.get("/api/consultas/candidatos?experiencia_min=3&texto=Peña")).datos.datos;
        assert.equal(experiencia.length, 1);

        assert.equal((await rh.get("/api/consultas/candidatos?salario_min=9&salario_max=1")).estado, 400);
    });

    it("mueve de etapa y registra el historial", async () => {

        const respuesta = await rh.put(`/api/proceso/${idCandidato}/etapa`, { etapa: "Entrevista", observacion: "Primera entrevista" });
        assert.equal(respuesta.estado, 200);
        assert.equal(respuesta.datos.datos.etapa, "Entrevista");

        const ficha = (await rh.get(`/api/candidatos/${idCandidato}`)).datos.datos;
        assert.equal(ficha.historial[0].etapa_anterior, "Postulado");
        assert.equal(ficha.historial[0].etapa_nueva, "Entrevista");

        assert.equal((await rh.put(`/api/proceso/${idCandidato}/etapa`, { etapa: "Inventada" })).estado, 400);
    });

    it("la contratación exige fecha y salario dentro del rango", async () => {

        const sinDatos = await rh.put(`/api/proceso/${idCandidato}/etapa`, { etapa: "Contratado" });
        assert.equal(sinDatos.estado, 400);
        assert.equal(sinDatos.datos.campo, "fecha_ingreso");

        const fueraDeRango = await rh.put(`/api/proceso/${idCandidato}/etapa`, {
            etapa: "Contratado", contratacion: { fecha_ingreso: hoy(), salario_mensual: 5000 }
        });
        assert.equal(fueraDeRango.datos.campo, "salario_mensual");

        const [{ empleados }] = await entorno.consultar("SELECT COUNT(*) AS empleados FROM empleados WHERE id_candidato = ?", [idCandidato]);
        assert.equal(Number(empleados), 0);
    });

    it("contrata: crea el empleado en la misma operación", async () => {

        const respuesta = await rh.put(`/api/proceso/${idCandidato}/etapa`, {
            etapa: "Contratado", contratacion: { fecha_ingreso: hoy(), salario_mensual: 62000 }
        });
        assert.equal(respuesta.estado, 200, JSON.stringify(respuesta.datos));
        assert.ok(respuesta.datos.datos.id_empleado);

        const empleado = (await rh.get(`/api/empleados/${respuesta.datos.datos.id_empleado}`)).datos.datos;
        assert.equal(empleado.cedula, cedula);
        assert.equal(empleado.salario_mensual, 62000);
        assert.equal(empleado.puesto, "Analista de Datos");
    });

    it("no permite mover ni eliminar a un candidato ya contratado", async () => {
        assert.equal((await rh.put(`/api/proceso/${idCandidato}/etapa`, { etapa: "Entrevista" })).estado, 409);
        assert.equal((await admin.delete(`/api/candidatos/${idCandidato}`)).estado, 409);
    });

    it("el panel refleja los datos actuales de MySQL", async () => {

        const panel = (await rh.get("/api/panel")).datos.datos;
        const [cifras] = await entorno.consultar(`
            SELECT (SELECT COUNT(*) FROM candidatos) AS candidatos,
                   (SELECT COUNT(*) FROM empleados WHERE estado = 'Activo') AS empleados,
                   (SELECT COUNT(*) FROM vacantes WHERE estado = 'Abierta') AS vacantes`);

        assert.equal(panel.indicadores.candidatos, Number(cifras.candidatos));
        assert.equal(panel.indicadores.empleados_activos, Number(cifras.empleados));
        assert.equal(panel.indicadores.vacantes_abiertas, Number(cifras.vacantes));
        assert.equal(panel.embudo.reduce((t, e) => t + e.cantidad, 0), Number(cifras.candidatos));
        assert.equal(panel.recientes[0].id, idCandidato, "el último modificado aparece primero");
        assert.equal(panel.contrataciones.length, 6);
    });

    it("el administrador elimina un candidato no contratado con todos sus datos", async () => {

        const otro = await rh.post("/api/candidatos", nuevo({ cedula: generarCedula("0010000002"), correo: "borrar@correo.com" }));
        assert.equal(otro.estado, 201);
        const id = otro.datos.datos.id;

        await rh.post("/api/experiencias", {
            id_candidato: id, empresa: "Temporal", puesto_ocupado: "Temporal", fecha_desde: "2022-01-01"
        });

        assert.equal((await rh.delete(`/api/candidatos/${id}`)).estado, 403);
        assert.equal((await admin.delete(`/api/candidatos/${id}`)).estado, 200);

        const [{ restos }] = await entorno.consultar(`
            SELECT (SELECT COUNT(*) FROM proceso_seleccion WHERE id_candidato = ?) +
                   (SELECT COUNT(*) FROM experiencia_laboral WHERE id_candidato = ?) AS restos`, [id, id]);
        assert.equal(Number(restos), 0);
    });
});


// ------------------------------------------------------------
describe("Empleados y reportes", () => {

    it("registra un empleado manual y valida el rango salarial", async () => {

        const base = {
            cedula: generarCedula("2230000005"), nombre: "Pedro Almonte",
            fecha_ingreso: "2026-09-01", id_puesto: 5, salario_mensual: 50000
        };

        assert.equal((await rh.post("/api/empleados", { ...base, salario_mensual: 1000 })).datos.campo, "salario_mensual");

        const creado = await rh.post("/api/empleados", base);
        assert.equal(creado.estado, 201);
        assert.equal(creado.datos.datos.departamento, "Finanzas");

        assert.equal((await rh.post("/api/empleados", base)).estado, 409);

        const id = creado.datos.datos.id;
        assert.equal((await rh.patch(`/api/empleados/${id}/estado`, { estado: "Inactivo" })).datos.datos.estado, "Inactivo");
    });

    it("reporte de ingresos por período y departamento", async () => {

        const reporte = (await rh.get("/api/reportes/ingresos?desde=2026-09-01&hasta=2026-09-30")).datos.datos;
        assert.ok(reporte.empleados.every(e => e.fecha_ingreso >= "2026-09-01" && e.fecha_ingreso <= "2026-09-30"));
        assert.equal(reporte.resumen.total, reporte.empleados.length);
        assert.equal(reporte.por_departamento.reduce((t, d) => t + d.cantidad, 0), reporte.resumen.total);

        const tecnologia = (await rh.get("/api/reportes/ingresos?id_departamento=1")).datos.datos;
        assert.ok(tecnologia.empleados.every(e => e.departamento === "Tecnología"));

        const invertido = await rh.get("/api/reportes/ingresos?desde=2026-10-01&hasta=2026-01-01");
        assert.equal(invertido.estado, 400);
    });

    it("reporte del proceso de selección", async () => {
        const reporte = (await rh.get("/api/reportes/seleccion")).datos.datos;
        assert.equal(reporte.por_etapa.reduce((t, e) => t + e.cantidad, 0), reporte.resumen.total);
        assert.ok(reporte.resumen.contratados > 0);
    });
});
