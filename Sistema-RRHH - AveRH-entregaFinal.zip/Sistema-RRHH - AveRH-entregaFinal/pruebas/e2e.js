// ==========================================
// AveRH - Pruebas de extremo a extremo (navegador real)
// Uso: npm run test:e2e
//
// Abre Edge o Chrome sin interfaz, recorre todas las pantallas
// y ejecuta los flujos principales como lo haría una persona.
// Se usa la base de pruebas (<DB_NAME>_pruebas), nunca la real.
// Las capturas se guardan en pruebas/capturas/.
// ==========================================

const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");
const assert = require("node:assert/strict");

const { iniciarEntorno, generarCedula, USUARIOS_PRUEBA } = require("./entorno");

const CARPETA_CAPTURAS = path.join(__dirname, "capturas");
const dormir = ms => new Promise(r => setTimeout(r, ms));

const NAVEGADORES = [
    process.env.NAVEGADOR_RUTA,
    "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
].filter(Boolean);


// ------------------------------------------
// Control del navegador (Chrome DevTools Protocol)
// ------------------------------------------

async function abrirNavegador() {

    const ejecutable = NAVEGADORES.find(ruta => fs.existsSync(ruta));

    if (!ejecutable) {
        throw new Error("No se encontró Edge ni Chrome. Indica la ruta en NAVEGADOR_RUTA.");
    }

    const puerto = 9300 + Math.floor(Math.random() * 500);
    const perfil = fs.mkdtempSync(path.join(os.tmpdir(), "averh-e2e-"));

    const proceso = spawn(ejecutable, [
        "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
        `--remote-debugging-port=${puerto}`, `--user-data-dir=${perfil}`, "about:blank"
    ], { stdio: "ignore" });

    let pagina;

    for (let i = 0; i < 60 && !pagina; i++) {
        try {
            const objetivos = await (await fetch(`http://127.0.0.1:${puerto}/json/list`)).json();
            pagina = objetivos.find(o => o.type === "page");
        } catch {
            // El navegador todavía está arrancando.
        }
        await dormir(250);
    }

    if (!pagina) {
        proceso.kill();
        throw new Error("El navegador no respondió.");
    }

    const ws = new WebSocket(pagina.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject; });

    let id = 0;
    const pendientes = new Map();
    const erroresConsola = [];

    ws.onmessage = evento => {

        const mensaje = JSON.parse(evento.data);

        if (mensaje.id && pendientes.has(mensaje.id)) {
            pendientes.get(mensaje.id)(mensaje);
            pendientes.delete(mensaje.id);
        }

        if (mensaje.method === "Runtime.exceptionThrown") {
            erroresConsola.push(`Excepción: ${mensaje.params.exceptionDetails.exception?.description || mensaje.params.exceptionDetails.text}`);
        }

        if (mensaje.method === "Runtime.consoleAPICalled" && mensaje.params.type === "error") {
            erroresConsola.push(`console.error: ${mensaje.params.args.map(a => a.value ?? a.description).join(" ")}`);
        }

        // Las respuestas 4xx de la API son esperadas (sin sesión,
        // contraseña incorrecta, duplicados...) y la aplicación las
        // gestiona. Solo cuentan los errores del servidor (5xx) y los
        // archivos que no cargan (404).
        if (mensaje.method === "Log.entryAdded" && mensaje.params.entry.level === "error") {

            const entrada = mensaje.params.entry;
            const esperado = entrada.source === "network" &&
                /status of 4\d\d/.test(entrada.text) &&
                !/status of 404/.test(entrada.text) &&
                /\/api\//.test(entrada.url || "");

            if (!esperado) {
                erroresConsola.push(`${entrada.source}: ${entrada.text} ${entrada.url || ""}`);
            }
        }
    };

    const cmd = (method, params = {}) => new Promise(resolve => {
        const n = ++id;
        pendientes.set(n, resolve);
        ws.send(JSON.stringify({ id: n, method, params }));
    });

    await cmd("Page.enable");
    await cmd("Runtime.enable");
    await cmd("Log.enable");

    const navegador = {

        erroresConsola,

        async tamano(ancho, alto) {
            await cmd("Emulation.setDeviceMetricsOverride", { width: ancho, height: alto, deviceScaleFactor: 1, mobile: ancho < 700 });
        },

        async ir(url) {
            await cmd("Page.navigate", { url });
            await dormir(400);
        },

        async evaluar(expresion) {

            const r = await cmd("Runtime.evaluate", { expression: expresion, awaitPromise: true, returnByValue: true });

            if (r.result?.exceptionDetails) {
                throw new Error(`Error al evaluar: ${r.result.exceptionDetails.exception?.description || r.result.exceptionDetails.text}`);
            }

            return r.result?.result?.value;
        },

        async esperar(condicion, descripcion, tiempo = 8000) {

            const limite = Date.now() + tiempo;

            while (Date.now() < limite) {
                try {
                    if (await navegador.evaluar(`Boolean(${condicion})`)) return;
                } catch {
                    // La página puede estar cambiando.
                }
                await dormir(100);
            }

            throw new Error(`Tiempo agotado esperando: ${descripcion}`);
        },

        // Espera a que la vista actual termine de cargar.
        async esperarVista() {
            await navegador.esperar(
                "document.querySelector('.vista') && !document.querySelector('.vista > .cargando-bloque')",
                "que la vista termine de cargar"
            );
            await dormir(250);
        },

        // Las descargas se guardan en la carpeta indicada.
        async permitirDescargas(carpeta) {
            await cmd("Page.setDownloadBehavior", { behavior: "allow", downloadPath: carpeta });
        },

        // Imprime la página a PDF (como «Guardar como PDF»).
        async pdf(ruta) {
            const r = await cmd("Page.printToPDF", { printBackground: true, preferCSSPageSize: true });
            fs.writeFileSync(ruta, Buffer.from(r.result.data, "base64"));
            return fs.statSync(ruta).size;
        },

        async captura(nombre, completa = false) {

            let parametros = { format: "png" };

            if (completa) {
                const alto = await navegador.evaluar("Math.min(document.documentElement.scrollHeight, 5000)");
                const ancho = await navegador.evaluar("document.documentElement.clientWidth");
                parametros = { format: "png", captureBeyondViewport: true, clip: { x: 0, y: 0, width: ancho, height: alto, scale: 1 } };
            }

            const r = await cmd("Page.captureScreenshot", parametros);
            fs.writeFileSync(path.join(CARPETA_CAPTURAS, `${nombre}.png`), Buffer.from(r.result.data, "base64"));
        },

        async cerrar() {
            ws.close();
            proceso.kill();
            await dormir(300);
            // En Windows el navegador puede tardar en liberar archivos.
            try {
                fs.rmSync(perfil, { recursive: true, force: true, maxRetries: 5, retryDelay: 300 });
            } catch {
                // Es una carpeta temporal: no impide terminar las pruebas.
            }
        }
    };

    return navegador;
}


// ------------------------------------------
// Pruebas
// ------------------------------------------

const resultados = [];

async function prueba(nombre, funcion) {

    const inicio = Date.now();

    try {
        await funcion();
        resultados.push({ nombre, ok: true, ms: Date.now() - inicio });
        console.log(`  ✓ ${nombre}`);
    } catch (error) {
        resultados.push({ nombre, ok: false, error: error.message });
        console.log(`  ✗ ${nombre}\n      ${error.message}`);
    }
}


async function principal() {

    fs.mkdirSync(CARPETA_CAPTURAS, { recursive: true });

    console.log("Preparando la base de pruebas...");
    const entorno = await iniciarEntorno();
    const base = entorno.base;

    console.log(`Servidor de pruebas en ${base}. Abriendo navegador...`);
    const nav = await abrirNavegador();
    await nav.tamano(1440, 900);

    const cedulaNueva = generarCedula("4021234560");
    let idNuevo = null;

    try {

        console.log("\nInicio de sesión");

        await prueba("sin sesión, la aplicación redirige al login", async () => {
            await nav.ir(`${base}/#/candidatos`);
            await nav.esperar("location.pathname === '/login.html'", "redirección al login");
            await nav.captura("01-login");
        });

        await prueba("una contraseña incorrecta muestra un error claro", async () => {
            await nav.evaluar(`(() => {
                document.getElementById("correo").value = ${JSON.stringify(USUARIOS_PRUEBA.admin.correo)};
                document.getElementById("contrasena").value = "incorrecta";
                document.querySelector("#formLogin [type=submit]").click();
            })()`);
            await nav.esperar("document.querySelector('[data-error-general] .alerta-error')", "mensaje de error");
            const texto = await nav.evaluar("document.querySelector('[data-error-general]').textContent");
            assert.match(texto, /incorrectos/);
            await nav.captura("02-login-error");
        });

        await prueba("el administrador inicia sesión y vuelve a la pantalla pedida", async () => {
            await nav.evaluar(`(() => {
                document.getElementById("contrasena").value = ${JSON.stringify(USUARIOS_PRUEBA.admin.contrasena)};
                document.querySelector("#formLogin [type=submit]").click();
            })()`);
            await nav.esperar("location.hash === '#/candidatos'", "volver a #/candidatos");
            await nav.esperarVista();
            const nombre = await nav.evaluar("document.querySelector('#usuarioActual strong').textContent");
            assert.equal(nombre, USUARIOS_PRUEBA.admin.nombre);
        });


        console.log("\nRecorrido por todas las pantallas");

        const pantallas = [
            ["panel", "03-panel"], ["vacantes", "04-vacantes"], ["candidatos", "05-candidatos"],
            ["proceso", "06-proceso"], ["experiencia", "07-experiencia"], ["empleados", "08-empleados"],
            ["consulta", "09-consulta"], ["reportes/ingresos", "10-reporte-ingresos"],
            ["reportes/seleccion", "11-reporte-seleccion"], ["puestos", "12-puestos"],
            ["departamentos", "13-departamentos"], ["competencias", "14-competencias"],
            ["idiomas", "15-idiomas"], ["capacitaciones", "16-capacitaciones"], ["usuarios", "17-usuarios"],
            ["candidatos/1", "18-perfil-candidato"], ["candidatos/1/perfil", "19-editor-perfil"],
            ["candidatos/1/editar", "20-editar-candidato"]
        ];

        for (const [ruta, captura] of pantallas) {
            await prueba(`#/${ruta} se muestra sin errores`, async () => {
                const antes = nav.erroresConsola.length;
                await nav.evaluar(`location.hash = "#/${ruta}"`);
                await nav.esperarVista();
                const error = await nav.evaluar("document.querySelector('.vista .vacio svg + strong')?.textContent || ''");
                assert.ok(!/No se pudo cargar/.test(error), `la vista mostró un error: ${error}`);
                assert.deepEqual(nav.erroresConsola.slice(antes), [], "errores en la consola");
                await nav.captura(captura, ["panel", "candidatos/1", "reportes/ingresos", "proceso"].includes(ruta));
            });
        }

        await prueba("el panel muestra las cifras reales de MySQL", async () => {
            await nav.evaluar('location.hash = "#/panel"');
            await nav.esperarVista();
            const [{ candidatos }] = await entorno.consultar("SELECT COUNT(*) AS candidatos FROM candidatos");
            const valor = await nav.evaluar("document.querySelector('.indicador-valor').textContent.trim()");
            assert.equal(valor, String(candidatos));
        });


        console.log("\nFlujo completo: registrar, perfil, proceso y contratación");

        await prueba("valida la cédula y el salario en el formulario", async () => {
            await nav.evaluar('location.hash = "#/candidatos/nuevo"');
            await nav.esperarVista();
            await nav.evaluar(`(() => {
                const f = document.querySelector(".vista form");
                const cedula = f.elements.cedula;
                cedula.value = "40212345601";
                cedula.dispatchEvent(new Event("input"));
                f.elements.id_vacante.value = "2";
                f.elements.id_vacante.dispatchEvent(new Event("change"));
                f.elements.salario_aspira.value = "500000";
                f.elements.salario_aspira.dispatchEvent(new Event("input"));
            })()`);
            const mensajeCedula = await nav.evaluar("document.querySelector('[data-campo=cedula] [data-ayuda]').textContent");
            const mensajeSalario = await nav.evaluar("document.querySelector('[data-campo=salario_aspira] [data-ayuda]').textContent");
            assert.match(mensajeCedula, /verificador/);
            assert.match(mensajeSalario, /Fuera del rango/);
            await nav.captura("21-formulario-validacion");
        });

        await prueba("registra un candidato y abre su perfil profesional", async () => {
            await nav.evaluar(`(() => {
                const f = document.querySelector(".vista form");
                f.elements.cedula.value = ${JSON.stringify(cedulaNueva)};
                f.elements.cedula.dispatchEvent(new Event("input"));
                f.elements.nombre.value = "Andrea Valdez Polanco";
                f.elements.correo.value = "andrea.valdez@correo.com";
                f.elements.telefono.value = "829-555-7788";
                f.elements.salario_aspira.value = "62000";
                f.elements.fuente_reclutamiento.value = "LinkedIn";
                f.querySelector("[type=submit]").click();
            })()`);
            await nav.esperar("/^#\\/candidatos\\/\\d+\\/perfil$/.test(location.hash)", "redirección al editor de perfil");
            idNuevo = Number(await nav.evaluar("location.hash.match(/\\d+/)[0]"));
            await nav.esperarVista();
        });

        await prueba("guarda competencias, idiomas y capacitaciones", async () => {
            await nav.evaluar(`(() => {
                document.querySelectorAll('[name="competencia"]')[0].click();
                document.querySelectorAll('[name="competencia"]')[2].click();
                const idioma = document.querySelector('[name="idioma"][value="2"]');
                idioma.click();
                document.querySelector('[data-nivel="2"]').value = "Avanzado";
                document.querySelectorAll('[name="capacitacion"]')[0].click();
                document.querySelector(".barra-guardar [type=submit]").click();
            })()`);
            await nav.esperar(`location.hash === "#/candidatos/${idNuevo}"`, "volver al perfil");
            await nav.esperarVista();
            const chips = await nav.evaluar("document.querySelectorAll('.perfil-secciones .chip').length");
            assert.equal(chips, 2);
            const ficha = (await entorno.consultar("SELECT COUNT(*) AS n FROM candidato_idiomas WHERE id_candidato = ? AND nivel = 'Avanzado'", [idNuevo]))[0];
            assert.equal(Number(ficha.n), 1);
            await nav.captura("22-perfil-nuevo-candidato", true);
        });

        await prueba("añade experiencia laboral desde el perfil", async () => {
            await nav.evaluar("document.querySelector('[data-nueva-experiencia]').click()");
            await nav.esperar("document.querySelector('dialog[open] form')", "modal de experiencia");
            await nav.evaluar(`(() => {
                const f = document.querySelector("dialog[open] form");
                f.elements.empresa.value = "Banco Popular";
                f.elements.puesto_ocupado.value = "Analista de datos";
                f.elements.fecha_desde.value = "2021-03-01";
                f.elements.fecha_hasta.value = "2024-02-28";
                document.querySelector("dialog[open] [type=submit]").click();
            })()`);
            await nav.esperar("!document.querySelector('dialog[open]')", "cierre del modal");
            await nav.esperar("document.querySelectorAll('.linea-tiempo li').length === 1", "experiencia en la línea de tiempo");
        });

        await prueba("mueve al candidato de etapa desde el tablero", async () => {
            await nav.evaluar('location.hash = "#/proceso"');
            await nav.esperarVista();
            await nav.evaluar(`(() => {
                const s = document.querySelector('[data-mover="${idNuevo}"]');
                s.value = "Entrevista";
                s.dispatchEvent(new Event("change", { bubbles: true }));
            })()`);
            await nav.esperar(`document.querySelector('.columna-proceso[data-etapa="Entrevista"] .tarjeta-proceso[data-id="${idNuevo}"]')`, "tarjeta en Entrevista");
        });

        await prueba("contratar abre el modal y crea el empleado", async () => {
            await nav.evaluar(`(() => {
                const s = document.querySelector('[data-mover="${idNuevo}"]');
                s.value = "Contratado";
                s.dispatchEvent(new Event("change", { bubbles: true }));
            })()`);
            await nav.esperar("document.querySelector('dialog[open] #formContratacion')", "modal de contratación");
            await nav.captura("23-modal-contratacion");
            await nav.evaluar('document.querySelector("dialog[open] [type=submit]").click()');
            await nav.esperar(`document.querySelector('.columna-proceso[data-etapa="Contratado"] .tarjeta-proceso[data-id="${idNuevo}"]')`, "tarjeta en Contratado");
            const [empleado] = await entorno.consultar("SELECT salario_mensual FROM empleados WHERE id_candidato = ?", [idNuevo]);
            assert.equal(Number(empleado.salario_mensual), 62000);
            await nav.captura("24-proceso-tras-contratar", true);
        });

        await prueba("el candidato contratado aparece primero en el panel", async () => {
            await nav.evaluar('location.hash = "#/panel"');
            await nav.esperarVista();
            const primero = await nav.evaluar("document.querySelector('.lista-recientes .persona-datos a').textContent");
            assert.equal(primero, "Andrea Valdez Polanco");
        });

        await prueba("la consulta por criterios encuentra al candidato por idioma y nivel", async () => {
            await nav.evaluar('location.hash = "#/consulta"');
            await nav.esperarVista();
            await nav.evaluar(`(() => {
                const f = document.querySelector(".vista form");
                f.elements.id_idioma.value = "2";
                f.elements.nivel_idioma.value = "Avanzado";
                f.elements.texto.value = "Andrea";
                f.querySelector("[type=submit]").click();
            })()`);
            await nav.esperar("document.querySelector('[data-resultados] .tabla')", "resultados");
            const filas = await nav.evaluar("document.querySelectorAll('[data-resultados] tbody tr').length");
            assert.equal(filas, 1);
            await nav.captura("25-consulta-resultados");
        });

        await prueba("la búsqueda en tablas ignora acentos", async () => {
            await nav.evaluar('location.hash = "#/candidatos"');
            await nav.esperarVista();
            await nav.evaluar(`(() => {
                const b = document.querySelector("[data-busqueda]");
                b.value = "polanco";
                b.dispatchEvent(new Event("input"));
            })()`);
            const filas = await nav.evaluar("document.querySelectorAll('.vista tbody tr').length");
            assert.equal(filas, 1);
        });


        console.log("\nCatálogos y usuarios");

        await prueba("crea una competencia y muestra el error de duplicado", async () => {
            await nav.evaluar('location.hash = "#/competencias"');
            await nav.esperarVista();
            await nav.evaluar("document.querySelector('[data-nuevo]').click()");
            await nav.esperar("document.querySelector('dialog[open] form')", "modal");
            await nav.evaluar(`(() => {
                const f = document.querySelector("dialog[open] form");
                f.elements.descripcion.value = "liderazgo";
                document.querySelector("dialog[open] [type=submit]").click();
            })()`);
            await nav.esperar("document.querySelector('dialog[open] .campo.con-error')", "error junto al campo");
            await nav.captura("26-error-duplicado");
            await nav.evaluar(`(() => {
                const f = document.querySelector("dialog[open] form");
                f.elements.descripcion.value = "Inteligencia emocional";
                document.querySelector("dialog[open] [type=submit]").click();
            })()`);
            await nav.esperar("!document.querySelector('dialog[open]')", "cierre del modal");
            await nav.esperar("[...document.querySelectorAll('.vista tbody td')].some(td => td.textContent.includes('Inteligencia emocional'))", "nueva competencia en la tabla");
        });

        await prueba("crea un usuario de Recursos Humanos", async () => {
            await nav.evaluar('location.hash = "#/usuarios"');
            await nav.esperarVista();
            await nav.evaluar("document.querySelector('[data-nuevo]').click()");
            await nav.esperar("document.querySelector('dialog[open] form')", "modal");
            await nav.evaluar(`(() => {
                const f = document.querySelector("dialog[open] form");
                f.elements.nombre.value = "Carla Rosario";
                f.elements.correo.value = "carla@pruebas.averh";
                f.elements.rol.value = "Recursos Humanos";
                f.elements.contrasena.value = "Carla12345";
                f.elements.confirmar.value = "Carla12345";
                document.querySelector("dialog[open] [type=submit]").click();
            })()`);
            await nav.esperar("!document.querySelector('dialog[open]')", "cierre del modal");
            await nav.esperar("document.querySelector('.vista').textContent.includes('carla@pruebas.averh')", "usuario en la tabla");
        });

        await prueba("Recursos Humanos no ve ni puede abrir Usuarios", async () => {
            await nav.evaluar("document.getElementById('botonSalir').click()");
            await nav.esperar("location.pathname === '/login.html'", "cerrar sesión");
            await dormir(300);
            await nav.evaluar(`(() => {
                document.getElementById("correo").value = "carla@pruebas.averh";
                document.getElementById("contrasena").value = "Carla12345";
                document.querySelector("#formLogin [type=submit]").click();
            })()`);
            await nav.esperar("location.hash === '#/panel'", "entrar al panel");
            await nav.esperarVista();
            assert.equal(await nav.evaluar("Boolean(document.querySelector('[data-ruta=\"/usuarios\"]'))"), false);
            await nav.evaluar('location.hash = "#/usuarios"');
            await nav.esperar("location.hash === '#/panel'", "redirección al panel");
            assert.equal(await nav.evaluar("Boolean(document.querySelector('[data-eliminar]'))"), false);
        });


        console.log("\nExcel, idiomas por vacante e impresión");

        await prueba("exporta el reporte de ingresos a un .xlsx válido", async () => {

            const ExcelJS = require("exceljs");
            const carpeta = fs.mkdtempSync(path.join(os.tmpdir(), "averh-descargas-"));

            await nav.permitirDescargas(carpeta);
            await nav.evaluar('location.hash = "#/reportes/ingresos"');
            await nav.esperarVista();
            await nav.esperar("!document.querySelector('[data-exportar]').disabled", "botón de Excel activo");

            const filasPantalla = await nav.evaluar("document.querySelectorAll('[data-reporte] tbody tr').length");
            await nav.evaluar("document.querySelector('[data-exportar]').click()");

            let archivo = null;
            for (let i = 0; i < 60 && !archivo; i++) {
                await dormir(250);
                archivo = fs.readdirSync(carpeta).find(f => f.endsWith(".xlsx"));
            }
            assert.ok(archivo, "se descargó un archivo .xlsx");
            assert.match(archivo, /^reporte_ingresos_\d{4}-\d{2}-\d{2}\.xlsx$/);

            const libro = new ExcelJS.Workbook();
            await libro.xlsx.readFile(path.join(carpeta, archivo));

            const detalle = libro.getWorksheet("Detalle");
            assert.equal(detalle.getCell("A5").value, "Cédula");
            assert.equal(detalle.getCell("C5").value, "Fecha de ingreso");
            assert.ok(detalle.getCell("C6").value instanceof Date, "fecha real de Excel");
            assert.equal(typeof detalle.getCell("F6").value, "number", "salario numérico");

            // Filas de datos = filas visibles en AveRH (más la fila de total).
            // Última fila = 5 (encabezado) + filas de datos + 1 (total).
            const filasExcel = detalle.rowCount - 5 - 1;
            assert.equal(filasExcel, filasPantalla);
            assert.ok(libro.getWorksheet("Resumen"), "hoja de resumen");

            fs.copyFileSync(path.join(carpeta, archivo), path.join(CARPETA_CAPTURAS, "reporte-ingresos.xlsx"));
            fs.rmSync(carpeta, { recursive: true, force: true });
        });

        await prueba("imprime el reporte a PDF sin menú ni filtros", async () => {
            await nav.evaluar('location.hash = "#/reportes/seleccion"');
            await nav.esperarVista();
            const tamano = await nav.pdf(path.join(CARPETA_CAPTURAS, "reporte-seleccion.pdf"));
            assert.ok(tamano > 10000, "se generó el PDF");
        });

        await prueba("crea una vacante con varios idiomas desde el formulario", async () => {

            await nav.evaluar('location.hash = "#/vacantes"');
            await nav.esperarVista();
            await nav.evaluar("document.querySelector('[data-nuevo]').click()");
            await nav.esperar("document.querySelector('dialog[open] [data-agregar-idioma]')", "sección de idiomas");

            const anadir = nombre => nav.evaluar(`(() => {
                const s = document.querySelector("dialog[open] [data-agregar-idioma]");
                s.value = [...s.options].find(o => o.textContent.trim() === "${nombre}").value;
                s.dispatchEvent(new Event("change", { bubbles: true }));
            })()`);

            await anadir("Español");
            await anadir("Inglés");
            await anadir("Mandarín");

            await nav.evaluar(`(() => {
                const d = document.querySelector("dialog[open]");
                const nivel = (nombre, valor) => {
                    const fila = [...d.querySelectorAll(".requisito-idioma")].find(f => f.textContent.includes(nombre));
                    const s = fila.querySelector("select");
                    s.value = valor;
                    s.dispatchEvent(new Event("change", { bubbles: true }));
                };
                nivel("Español", "Avanzado");
                nivel("Inglés", "Avanzado");
                nivel("Mandarín", "Intermedio");
                const f = d.querySelector("form");
                f.elements.id_puesto.value = "9";
                f.elements.titulo.value = "Ejecutivo de Relaciones Comerciales con Asia";
                f.elements.cantidad_vacantes.value = "1";
            })()`);

            await nav.captura("29-vacante-idiomas");
            await nav.evaluar('document.querySelector("dialog[open] [type=submit]").click()');
            await nav.esperar("!document.querySelector('dialog[open]')", "cierre del modal");

            const filas = await entorno.consultar(`
                SELECT i.nombre, vi.nivel_minimo FROM vacante_idiomas vi
                INNER JOIN idiomas i ON i.id_idioma = vi.id_idioma
                INNER JOIN vacantes v ON v.id_vacante = vi.id_vacante
                WHERE v.titulo = 'Ejecutivo de Relaciones Comerciales con Asia'
                ORDER BY i.nombre`);

            assert.deepEqual(filas.map(f => `${f.nombre}:${f.nivel_minimo}`), ["Español:Avanzado", "Inglés:Avanzado", "Mandarín:Intermedio"]);
            await nav.esperar("document.querySelector('.vista').textContent.includes('Mandarín · Intermedio')", "requisitos en la tabla");
        });

        await prueba("la ficha compara los idiomas del candidato con su vacante", async () => {
            await nav.evaluar(`location.hash = "#/candidatos/${idNuevo}"`);
            await nav.esperarVista();
            const texto = await nav.evaluar("document.querySelector('.compatibilidad').textContent");
            assert.match(texto, /Cumple los idiomas/);
            const resultado = await nav.evaluar("document.querySelector('.resultado-idioma').textContent.trim()");
            assert.equal(resultado, "Cumple");
            await nav.captura("30-ficha-compatibilidad", true);
        });


        console.log("\nDiseño adaptable");

        await prueba("se ve correctamente en un móvil", async () => {
            await nav.tamano(390, 844);
            await nav.evaluar('location.hash = "#/panel"');
            await nav.esperarVista();
            const desborda = await nav.evaluar("document.documentElement.scrollWidth > window.innerWidth + 1");
            assert.equal(desborda, false, "la página no debe desbordar horizontalmente");
            await nav.captura("27-movil-panel", true);
            await nav.evaluar("document.getElementById('botonMenu').click()");
            await dormir(350);
            await nav.captura("28-movil-menu");
        });

        await prueba("no hubo errores de consola en todo el recorrido", async () => {
            assert.deepEqual(nav.erroresConsola, []);
        });

    } finally {
        await nav.cerrar();
        await entorno.cerrar();
    }

    const fallidas = resultados.filter(r => !r.ok);

    console.log(`\n${resultados.length - fallidas.length}/${resultados.length} pruebas superadas. Capturas en pruebas/capturas/`);

    if (fallidas.length) {
        process.exitCode = 1;
    }
}


principal().catch(error => {
    console.error(error);
    process.exitCode = 1;
});
