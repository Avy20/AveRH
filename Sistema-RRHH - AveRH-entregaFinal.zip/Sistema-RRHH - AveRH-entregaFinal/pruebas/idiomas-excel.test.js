// ==========================================
// AveRH - Pruebas: exportación a Excel y requisitos
// de idiomas por vacante (con compatibilidad).
// Se ejecutan contra la copia <DB_NAME>_pruebas.
// ==========================================

const { describe, it, before, after } = require("node:test");
const assert = require("node:assert/strict");
const ExcelJS = require("exceljs");

const { iniciarEntorno, generarCedula, USUARIOS_PRUEBA } = require("./entorno");

let entorno;
let rh;

const hoy = () => {
    const f = new Date();
    return `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, "0")}-${String(f.getDate()).padStart(2, "0")}`;
};


before(async () => {
    entorno = await iniciarEntorno();
    rh = entorno.nuevoCliente();
    assert.equal((await rh.login(USUARIOS_PRUEBA.rh.correo, USUARIOS_PRUEBA.rh.contrasena)).estado, 200);
});

after(async () => {
    await entorno?.cerrar();
});


describe("Exportación a Excel (.xlsx)", () => {

    async function exportar(cuerpo) {
        return fetch(`${entorno.base}/api/exportaciones/excel`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Cookie: rh.cookie() },
            body: JSON.stringify(cuerpo)
        });
    }

    it("genera un .xlsx real con columnas, formatos, filtros y totales", async () => {

        const respuesta = await exportar({
            titulo: "Reporte de ingresos de personal",
            subtitulo: "Período: todos",
            archivo: "reporte_ingresos",
            hojas: [{
                nombre: "Detalle",
                columnas: [
                    { titulo: "Empleado" },
                    { titulo: "Fecha de ingreso", tipo: "fecha" },
                    { titulo: "Salario mensual", tipo: "dinero", total: "suma" }
                ],
                filas: [["José Peña", "2026-09-01", 78000], ["Ana Díaz", "2026-10-07", 62000]]
            }]
        });

        assert.equal(respuesta.status, 200);
        assert.match(respuesta.headers.get("content-type"), /spreadsheetml/);
        assert.match(respuesta.headers.get("content-disposition"), /reporte_ingresos\.xlsx/);

        const libro = new ExcelJS.Workbook();
        await libro.xlsx.load(Buffer.from(await respuesta.arrayBuffer()));
        const hoja = libro.getWorksheet("Detalle");

        assert.deepEqual(hoja.getRow(5).values.slice(1), ["Empleado", "Fecha de ingreso", "Salario mensual"]);
        assert.equal(hoja.getCell("A6").value, "José Peña");
        assert.ok(hoja.getCell("B6").value instanceof Date, "la fecha debe ser una fecha de Excel");
        assert.equal(hoja.getCell("B6").numFmt, "dd/mm/yyyy");
        assert.equal(hoja.getCell("C6").value, 78000);
        assert.match(hoja.getCell("C6").numFmt, /RD\$/);
        assert.equal(hoja.getCell("C8").value.formula, "SUBTOTAL(109,C6:C7)");
        assert.ok(hoja.autoFilter, "debe tener autofiltro");
        assert.equal(hoja.views[0].ySplit, 5, "encabezado inmovilizado");
    });

    it("rechaza estructuras no válidas y peticiones sin sesión", async () => {

        const mala = await rh.crudo("POST", "/api/exportaciones/excel", { titulo: "X", hojas: [{ nombre: "a/b", columnas: [], filas: [] }] });
        assert.equal(mala.estado, 400);

        const tipo = await rh.crudo("POST", "/api/exportaciones/excel", { titulo: "X", hojas: [{ nombre: "A", columnas: [{ titulo: "c", tipo: "formula" }], filas: [] }] });
        assert.equal(tipo.estado, 400);

        const anonimo = await entorno.nuevoCliente().crudo("POST", "/api/exportaciones/excel", { titulo: "X", hojas: [] });
        assert.equal(anonimo.estado, 401);
    });
});


describe("Requisitos de idiomas por vacante y compatibilidad", () => {

    const idDe = async nombre => (await entorno.consultar("SELECT id_idioma FROM idiomas WHERE nombre = ?", [nombre]))[0].id_idioma;

    let ids;
    let idVacante;
    let idCandidato;

    const base = () => ({
        id_puesto: 3, titulo: "Coordinador de Proyectos Internacionales",
        cantidad_vacantes: 1, fecha_publicacion: hoy()
    });

    before(async () => {
        ids = {
            espanol: await idDe("Español"), ingles: await idDe("Inglés"),
            frances: await idDe("Francés"), mandarin: await idDe("Mandarín"), arabe: await idDe("Árabe")
        };
    });

    it("el catálogo incluye los idiomas solicitados", () => {
        assert.ok(ids.arabe, "Árabe debe existir en el catálogo");
    });

    it("conserva el requisito de inglés de las vacantes existentes", async () => {
        const vacante = (await rh.get("/api/vacantes/1")).datos.datos;
        assert.deepEqual(vacante.requisitos_idiomas.map(r => [r.idioma, r.nivel]), [["Inglés", "Avanzado"]]);
    });

    it("crea una vacante con varios idiomas independientes", async () => {

        const respuesta = await rh.post("/api/vacantes", {
            ...base(),
            idiomas: [
                { id_idioma: ids.espanol, nivel: "Avanzado" },
                { id_idioma: ids.ingles, nivel: "Avanzado" },
                { id_idioma: ids.frances, nivel: "Intermedio" },
                { id_idioma: ids.mandarin, nivel: "No requerido" }
            ]
        });

        assert.equal(respuesta.estado, 201, JSON.stringify(respuesta.datos));
        idVacante = respuesta.datos.datos.id_vacante;
        assert.equal(respuesta.datos.datos.requisitos_idiomas.length, 3, "«No requerido» no se guarda");
        assert.equal(respuesta.datos.datos.nivel_ingles, "Avanzado", "nivel_ingles se mantiene sincronizado");

        // Otra vacante tiene requisitos propios e independientes.
        const otra = (await rh.get("/api/vacantes/2")).datos.datos;
        assert.deepEqual(otra.requisitos_idiomas.map(r => r.idioma), ["Inglés"]);
    });

    it("edita los requisitos y rechaza niveles o idiomas duplicados", async () => {

        const editada = await rh.put(`/api/vacantes/${idVacante}`, {
            ...base(), idiomas: [{ id_idioma: ids.espanol, nivel: "Avanzado" }, { id_idioma: ids.frances, nivel: "Básico" }]
        });
        assert.equal(editada.estado, 200);
        assert.equal(editada.datos.datos.nivel_ingles, "No requerido");
        assert.equal(editada.datos.datos.requisitos_idiomas.length, 2);

        const duplicado = await rh.put(`/api/vacantes/${idVacante}`, {
            ...base(), idiomas: [{ id_idioma: ids.frances, nivel: "Básico" }, { id_idioma: ids.frances, nivel: "Avanzado" }]
        });
        assert.equal(duplicado.estado, 400);

        const nivel = await rh.put(`/api/vacantes/${idVacante}`, { ...base(), idiomas: [{ id_idioma: ids.frances, nivel: "Experto" }] });
        assert.equal(nivel.estado, 400);

        const inexistente = await rh.put(`/api/vacantes/${idVacante}`, { ...base(), idiomas: [{ id_idioma: 99999, nivel: "Básico" }] });
        assert.equal(inexistente.estado, 400);

        // Las ediciones rechazadas no alteran los requisitos guardados.
        const actual = (await rh.get(`/api/vacantes/${idVacante}`)).datos.datos;
        assert.equal(actual.requisitos_idiomas.length, 2);
    });

    it("evalúa el nivel mínimo: cumple, no cumple y sin información", async () => {

        await rh.put(`/api/vacantes/${idVacante}`, {
            ...base(),
            idiomas: [
                { id_idioma: ids.espanol, nivel: "Avanzado" },
                { id_idioma: ids.ingles, nivel: "Intermedio" },
                { id_idioma: ids.frances, nivel: "Básico" },
                { id_idioma: ids.mandarin, nivel: "Avanzado" }
            ]
        });

        const creado = await rh.post("/api/candidatos", {
            cedula: generarCedula("0310000007"), nombre: "Lucía Almánzar", correo: "lucia.almanzar@correo.com",
            id_vacante: idVacante, salario_aspira: 80000, fecha_postulacion: hoy()
        });
        assert.equal(creado.estado, 201, JSON.stringify(creado.datos));
        idCandidato = creado.datos.datos.id;

        // Español nativo (≥ avanzado), inglés avanzado (≥ intermedio),
        // francés avanzado (≥ básico), mandarín básico (< avanzado).
        await rh.put(`/api/candidatos/${idCandidato}/perfil`, {
            competencias: [], capacitaciones: [],
            idiomas: [
                { id: ids.espanol, nivel: "Nativo" }, { id: ids.ingles, nivel: "Avanzado" },
                { id: ids.frances, nivel: "Avanzado" }, { id: ids.mandarin, nivel: "Básico" }
            ]
        });

        let c = (await rh.get(`/api/candidatos/${idCandidato}`)).datos.datos.compatibilidad_idiomas;
        const resultado = nombre => c.detalle.find(d => d.idioma === nombre).resultado;

        assert.equal(resultado("Español"), "cumple");
        assert.equal(resultado("Inglés"), "cumple");
        assert.equal(resultado("Francés"), "cumple");
        assert.equal(resultado("Mandarín"), "no_cumple");
        assert.equal(c.estado, "no_cumple");

        // Sin mandarín en el perfil: «Sin información», no «No cumple».
        await rh.put(`/api/candidatos/${idCandidato}/perfil`, {
            competencias: [], capacitaciones: [],
            idiomas: [{ id: ids.espanol, nivel: "Nativo" }, { id: ids.ingles, nivel: "Avanzado" }, { id: ids.frances, nivel: "Avanzado" }]
        });

        c = (await rh.get(`/api/candidatos/${idCandidato}`)).datos.datos.compatibilidad_idiomas;
        assert.equal(resultado("Mandarín"), "sin_informacion");
        assert.equal(c.estado, "incompleto");
        assert.equal(c.cumple, 3);

        // Al quitar el requisito de mandarín, cumple todo (se recalcula al momento).
        await rh.put(`/api/vacantes/${idVacante}`, {
            ...base(), idiomas: [{ id_idioma: ids.espanol, nivel: "Avanzado" }, { id_idioma: ids.ingles, nivel: "Intermedio" }]
        });

        c = (await rh.get(`/api/candidatos/${idCandidato}`)).datos.datos.compatibilidad_idiomas;
        assert.equal(c.estado, "cumple");
    });

    it("se muestra en el tablero y la consulta sin descartar a nadie", async () => {

        await rh.put(`/api/candidatos/${idCandidato}/perfil`, { competencias: [], capacitaciones: [], idiomas: [] });

        const tablero = (await rh.get("/api/proceso")).datos.datos.candidatos.find(x => x.id === idCandidato);
        assert.equal(tablero.etapa, "Postulado", "la falta de idiomas no cambia la etapa");
        assert.equal(tablero.compatibilidad_idiomas.estado, "incompleto");

        const consulta = (await rh.get("/api/consultas/candidatos?texto=Almánzar")).datos.datos;
        assert.equal(consulta.length, 1);
        assert.equal(consulta[0].compatibilidad_idiomas.total, 2);
    });
});
