// ==========================================
// AveRH - Candidatos
// Listado, alta / edición, ficha y perfil profesional.
// ==========================================

import { api } from "../nucleo/api.js";
import { html, pintar } from "../nucleo/html.js";
import { icono } from "../nucleo/iconos.js";
import { dinero, fecha, fechaHora, relativa, hoyISO, aniosExperiencia, normalizar } from "../nucleo/formato.js";
import { sesion, obtenerReferencias, opcionesDe } from "../nucleo/estado.js";
import {
    encabezado, insigniaEtapa, persona, avatar, notificar, confirmar,
    vistaVacia, conEspera, insigniaCompatibilidad, resultadoIdioma
} from "../nucleo/ui.js";
import { campo, alEnviar, activarMascaraCedula } from "../nucleo/formularios.js";
import { crearTabla } from "../nucleo/tabla.js";
import { abrirFormularioExperiencia, eliminarExperiencia } from "./experiencia.js";
import { moverDeEtapa } from "./proceso.js";
import { recargarVista } from "../nucleo/navegacion.js";


// ==========================================
// LISTADO
// ==========================================

export async function vistaCandidatos(contenedor) {

    const [candidatos, referencias] = await Promise.all([
        api.get("/candidatos"),
        obtenerReferencias()
    ]);

    const esAdmin = sesion.esAdministrador();

    pintar(contenedor, html`
        ${encabezado({
            titulo: "Candidatos",
            descripcion: "Personas que participan en los procesos de selección de AveRH.",
            acciones: html`<a class="boton boton-primario" href="#/candidatos/nuevo">${icono("mas")} Nuevo candidato</a>`
        })}
        <section class="tarjeta" data-tabla></section>
    `);

    const tabla = crearTabla(contenedor.querySelector("[data-tabla]"), {
        filas: candidatos,
        nombreRegistro: ["candidato", "candidatos"],
        placeholder: "Buscar por nombre, cédula o correo...",
        buscarEn: c => `${c.nombre} ${c.cedula} ${c.correo || ""} ${c.puesto || ""}`,
        filtros: [
            {
                clave: "etapa",
                etiqueta: "Todas las etapas",
                opciones: referencias.etapas,
                aplicar: (c, valor) => c.etapa === valor
            },
            {
                clave: "puesto",
                etiqueta: "Todos los puestos",
                opciones: opcionesDe(referencias.puestos, "id_puesto", "nombre", { incluirInactivos: true }),
                aplicar: (c, valor) => String(c.id_puesto) === valor
            }
        ],
        vacio: {
            icono: "candidatos",
            titulo: "Todavía no hay candidatos",
            texto: "Registra el primer candidato para iniciar un proceso de selección.",
            accion: html`<a class="boton boton-primario" href="#/candidatos/nuevo">${icono("mas")} Nuevo candidato</a>`
        },
        columnas: [
            {
                clave: "nombre", titulo: "Candidato", ordenable: true,
                mostrar: c => persona(c.nombre, c.correo || c.cedula, `#/candidatos/${c.id}`)
            },
            { clave: "cedula", titulo: "Cédula", clase: "secundario" },
            {
                clave: "puesto", titulo: "Puesto", ordenable: true,
                mostrar: c => html`<strong class="negrita">${c.puesto || "—"}</strong><br><span class="texto-suave texto-pequeno">${c.departamento || ""}</span>`
            },
            {
                clave: "salario_aspira", titulo: "Aspiración", ordenable: true, clase: "numero",
                mostrar: c => dinero(c.salario_aspira)
            },
            { clave: "etapa", titulo: "Etapa", ordenable: true, mostrar: c => insigniaEtapa(c.etapa) },
            {
                clave: "compatibilidad", titulo: "Idiomas",
                valorOrden: c => c.compatibilidad_idiomas?.estado || "",
                mostrar: c => insigniaCompatibilidad(c.compatibilidad_idiomas, { compacta: true }) || html`<span class="texto-suave">—</span>`
            },
            {
                clave: "fecha_actualizacion", titulo: "Actividad", ordenable: true, clase: "secundario",
                valorOrden: c => c.fecha_actualizacion || c.fecha_postulacion || "",
                mostrar: c => relativa(c.fecha_actualizacion || c.fecha_postulacion)
            },
            {
                clave: "acciones", titulo: html`<span class="solo-lectores">Acciones</span>`, clase: "acciones",
                mostrar: c => html`
                    <div>
                        <a class="boton boton-icono" href="#/candidatos/${c.id}" title="Ver perfil" aria-label="Ver perfil de ${c.nombre}">${icono("ver")}</a>
                        <a class="boton boton-icono" href="#/candidatos/${c.id}/editar" title="Editar" aria-label="Editar a ${c.nombre}">${icono("editar")}</a>
                        ${esAdmin && !c.id_empleado ? html`
                            <button class="boton boton-icono peligro" type="button" data-eliminar="${c.id}" title="Eliminar" aria-label="Eliminar a ${c.nombre}">${icono("eliminar")}</button>
                        ` : ""}
                    </div>
                `
            }
        ]
    });

    contenedor.addEventListener("click", async evento => {

        const boton = evento.target.closest("[data-eliminar]");

        if (!boton) return;

        const candidato = candidatos.find(c => c.id === Number(boton.dataset.eliminar));

        if (await eliminarCandidato(candidato)) {
            candidatos.splice(candidatos.indexOf(candidato), 1);
            tabla.actualizar(candidatos);
        }
    });
}


async function eliminarCandidato(candidato) {

    const aceptado = await confirmar({
        titulo: "Eliminar candidato",
        mensaje: `Se eliminarán ${candidato.nombre}, su perfil profesional, su experiencia laboral y su proceso de selección. Esta acción no se puede deshacer.`,
        textoConfirmar: "Eliminar definitivamente",
        peligro: true
    });

    if (!aceptado) return false;

    try {
        const respuesta = await api.eliminar(`/candidatos/${candidato.id}`);
        notificar(respuesta.mensaje);
        return true;
    } catch (error) {
        notificar(error.message, "error");
        return false;
    }
}


// ==========================================
// FORMULARIO: NUEVO / EDITAR
// ==========================================

export async function vistaFormularioCandidato(contenedor, [id]) {

    const edicion = Boolean(id);

    const [referencias, candidato] = await Promise.all([
        obtenerReferencias({ forzar: true }),
        edicion ? api.get(`/candidatos/${id}`) : null
    ]);

    // Vacantes abiertas (y la actual del candidato, aunque esté cerrada).
    const vacantes = referencias.vacantes.filter(v =>
        (v.estado === "Abierta" && referencias.puestos.find(p => p.id_puesto === v.id_puesto)?.estado === "Activo") ||
        v.id_vacante === candidato?.id_vacante);

    const procesoTerminado = ["Contratado", "Descartado"].includes(candidato?.etapa);

    const v = candidato || {
        fecha_postulacion: hoyISO(),
        fuente_reclutamiento: "AveRH"
    };

    pintar(contenedor, html`

        ${encabezado({
            titulo: edicion ? "Editar candidato" : "Nuevo candidato",
            descripcion: edicion
                ? `Actualiza los datos personales y la postulación de ${candidato.nombre}.`
                : "Registra a la persona y la vacante a la que se postula. El proceso de selección comenzará en la etapa Postulado.",
            volver: edicion
                ? { enlace: `#/candidatos/${id}`, texto: "Volver al perfil" }
                : { enlace: "#/candidatos", texto: "Volver a candidatos" }
        })}

        ${vacantes.length === 0 && !edicion ? html`
            <div class="alerta alerta-aviso mt-2" role="status">
                ${icono("alerta")}
                <div>No hay vacantes abiertas. <a href="#/vacantes">Publica una vacante</a> antes de registrar candidatos.</div>
            </div>
        ` : ""}

        <form class="tarjeta tarjeta-cuerpo formulario-ancho" novalidate>

            <section class="formulario-seccion">
                <h3>Datos personales</h3>
                <p>Información de identificación y contacto.</p>

                <div class="formulario-rejilla">
                    ${campo({
                        nombre: "cedula", etiqueta: "Cédula", requerido: true, valor: v.cedula,
                        placeholder: "000-0000000-0", ayuda: "Cédula dominicana de 11 dígitos.",
                        deshabilitado: Boolean(candidato?.id_empleado)
                    })}
                    ${campo({ nombre: "nombre", etiqueta: "Nombre completo", requerido: true, valor: v.nombre, placeholder: "Nombre y apellidos", atributos: { maxlength: 150, autocomplete: "off" } })}
                    ${campo({ nombre: "correo", etiqueta: "Correo electrónico", tipo: "email", requerido: !edicion, valor: v.correo, placeholder: "correo@ejemplo.com", atributos: { maxlength: 150 } })}
                    ${campo({ nombre: "telefono", etiqueta: "Teléfono", tipo: "tel", valor: v.telefono, placeholder: "809-000-0000", atributos: { maxlength: 20 } })}
                </div>
            </section>

            <section class="formulario-seccion">
                <h3>Postulación</h3>
                <p>Vacante, aspiración salarial y origen del candidato.</p>

                <div class="formulario-rejilla">
                    ${campo({
                        nombre: "id_vacante", etiqueta: "Vacante", tipo: "select", requerido: true,
                        valor: v.id_vacante, vacio: "Seleccione una vacante",
                        deshabilitado: procesoTerminado,
                        ayuda: procesoTerminado ? "El proceso de este candidato ya terminó." : "",
                        opciones: vacantes.map(x => ({ valor: x.id_vacante, texto: `${x.titulo} — ${x.puesto}` }))
                    })}
                    <div class="campo">
                        <span class="campo-etiqueta">Puesto y departamento</span>
                        <div class="dato-derivado" data-puesto>—</div>
                    </div>
                    ${campo({
                        nombre: "salario_aspira", etiqueta: "Salario al que aspira", tipo: "number", requerido: true,
                        valor: v.salario_aspira, prefijo: "RD$", placeholder: "60000",
                        atributos: { min: 1, step: "any" }
                    })}
                    ${campo({
                        nombre: "fecha_postulacion", etiqueta: "Fecha de postulación", tipo: "date",
                        requerido: !edicion, valor: v.fecha_postulacion, atributos: { max: hoyISO() }
                    })}
                    ${campo({
                        nombre: "fuente_reclutamiento", etiqueta: "Fuente de reclutamiento", tipo: "select",
                        valor: v.fuente_reclutamiento, vacio: null,
                        opciones: referencias.fuentes.map(f => ({ valor: f, texto: f }))
                    })}
                    ${campo({ nombre: "recomendado_por", etiqueta: "Recomendado por", valor: v.recomendado_por, placeholder: "Opcional", atributos: { maxlength: 150 } })}
                </div>
            </section>

            <div data-error-general class="mt-2"></div>

            <div class="formulario-acciones">
                <a class="boton boton-secundario" href="${edicion ? `#/candidatos/${id}` : "#/candidatos"}">Cancelar</a>
                <button class="boton boton-primario" type="submit">
                    ${icono("check")} ${edicion ? "Guardar cambios" : "Registrar candidato"}
                </button>
            </div>
        </form>
    `);

    const formulario = contenedor.querySelector("form");
    const selectorVacante = formulario.elements.id_vacante;
    const salario = formulario.elements.salario_aspira;
    const ayudaSalario = formulario.querySelector('[data-campo="salario_aspira"] [data-ayuda]');

    activarMascaraCedula(formulario.elements.cedula);

    // Puesto, departamento y rango salarial de la vacante elegida.
    const puestoSeleccionado = () => {
        const vacante = referencias.vacantes.find(x => String(x.id_vacante) === selectorVacante.value);
        return vacante ? referencias.puestos.find(p => p.id_puesto === vacante.id_puesto) : null;
    };

    const actualizarPuesto = () => {

        const puesto = puestoSeleccionado();

        const vacante = referencias.vacantes.find(x => String(x.id_vacante) === selectorVacante.value);
        const requisitos = (vacante?.requisitos_idiomas || []).map(r => `${r.idioma} ${r.nivel.toLowerCase()}`).join(", ");

        formulario.querySelector("[data-puesto]").textContent = puesto
            ? `${puesto.nombre} · ${puesto.departamento || "Sin departamento"}${requisitos ? ` · Idiomas: ${requisitos}` : ""}`
            : "Se completa al elegir la vacante";

        actualizarRango();
    };

    const actualizarRango = () => {

        const puesto = puestoSeleccionado();

        formulario.querySelector('[data-campo="salario_aspira"]').classList.remove("con-error");

        if (!puesto) {
            ayudaSalario.className = "campo-ayuda";
            ayudaSalario.textContent = "Selecciona primero la vacante.";
            return;
        }

        const valor = Number(salario.value);
        const rango = `${dinero(puesto.salario_minimo)} – ${dinero(puesto.salario_maximo)}`;

        if (!salario.value) {
            ayudaSalario.className = "campo-ayuda";
            ayudaSalario.textContent = `Rango del puesto: ${rango}`;
        } else if (valor < puesto.salario_minimo || valor > puesto.salario_maximo) {
            ayudaSalario.className = "campo-error";
            ayudaSalario.textContent = `Fuera del rango del puesto (${rango}).`;
        } else {
            ayudaSalario.className = "campo-exito";
            ayudaSalario.textContent = `✓ Dentro del rango (${rango}).`;
        }
    };

    selectorVacante.addEventListener("change", actualizarPuesto);
    salario.addEventListener("input", actualizarRango);
    actualizarPuesto();

    alEnviar(formulario, async datos => {

        // Los campos deshabilitados no se envían: se conservan los actuales.
        const cuerpo = {
            ...datos,
            cedula: datos.cedula ?? candidato?.cedula,
            id_vacante: datos.id_vacante ? Number(datos.id_vacante) : candidato?.id_vacante,
            salario_aspira: datos.salario_aspira === "" ? "" : Number(datos.salario_aspira)
        };

        const respuesta = edicion
            ? await api.put(`/candidatos/${id}`, cuerpo)
            : await api.post("/candidatos", cuerpo);

        notificar(edicion ? respuesta.mensaje : `${respuesta.datos.nombre} se registró correctamente. Completa ahora su perfil profesional.`);

        location.hash = edicion
            ? `#/candidatos/${id}`
            : `#/candidatos/${respuesta.datos.id}/perfil`;
    });
}


// ==========================================
// FICHA DEL CANDIDATO
// ==========================================

export async function vistaPerfilCandidato(contenedor, [id]) {

    const c = await api.get(`/candidatos/${id}`);
    const esAdmin = sesion.esAdministrador();

    pintar(contenedor, html`

        <a class="volver" href="#/candidatos">${icono("volver")} Volver a candidatos</a>

        <section class="tarjeta perfil-cabecera">
            ${avatar(c.nombre, "avatar-grande")}
            <div class="perfil-identidad">
                <div class="flex envolver">
                    <h1>${c.nombre}</h1>
                    ${insigniaEtapa(c.etapa)}
                    ${c.id_empleado ? html`<a class="insignia insignia-exito sin-punto" href="#/empleados">${icono("empleado")} Empleado</a>` : ""}
                    ${c.cedula.startsWith("000-") ? html`<span class="insignia sin-punto" title="Cédula de prueba: registro ficticio de demostración">Registro de demostración</span>` : ""}
                </div>
                <p>${c.puesto || "Sin puesto"} · ${c.departamento || "Sin departamento"}</p>
                <ul class="perfil-contacto">
                    <li>${icono("empleado")} ${c.cedula}</li>
                    <li>${icono("correo")} ${c.correo ? html`<a href="mailto:${c.correo}">${c.correo}</a>` : "Sin correo"}</li>
                    <li>${icono("telefono")} ${c.telefono || "Sin teléfono"}</li>
                </ul>
            </div>
            <div class="perfil-acciones">
                ${!c.id_empleado ? html`
                    <label class="mover-etapa">
                        <span class="solo-lectores">Mover a otra etapa</span>
                        <select class="control" data-mover>
                            <option value="">Mover a otra etapa…</option>
                            ${["Postulado", "Entrevista", "Evaluación", "Oferta", "Contratado", "Descartado"]
                                .filter(e => e !== c.etapa)
                                .map(e => html`<option value="${e}">${e}</option>`)}
                        </select>
                    </label>
                ` : ""}
                <a class="boton boton-secundario" href="#/candidatos/${c.id}/editar">${icono("editar")} Editar datos</a>
                <a class="boton boton-primario" href="#/candidatos/${c.id}/perfil">${icono("competencia")} Perfil profesional</a>
            </div>
        </section>


        <section class="rejilla rejilla-principal mt-3">

            <div class="pila">

                <article class="tarjeta">
                    <div class="tarjeta-encabezado"><h2>Postulación</h2></div>
                    <div class="tarjeta-cuerpo">
                        <dl class="datos-lista">
                            <div><dt>Vacante</dt><dd>${c.vacante || "—"}</dd></div>
                            <div><dt>Salario aspirado</dt><dd class="dinero">${dinero(c.salario_aspira)}</dd></div>
                            <div><dt>Fecha de postulación</dt><dd>${fecha(c.fecha_postulacion)}</dd></div>
                            <div><dt>Fuente</dt><dd>${c.fuente_reclutamiento || "—"}</dd></div>
                            <div><dt>Recomendado por</dt><dd>${c.recomendado_por || "—"}</dd></div>
                            <div><dt>Experiencia total</dt><dd>${aniosExperiencia(c.anios_experiencia)}</dd></div>
                        </dl>
                    </div>
                </article>

                <article class="tarjeta">
                    <div class="tarjeta-encabezado">
                        <div>
                            <h2>Idiomas requeridos por la vacante</h2>
                            <p>Comparación con el nivel mínimo exigido · solo informativa</p>
                        </div>
                        ${insigniaCompatibilidad(c.compatibilidad_idiomas)}
                    </div>
                    ${c.compatibilidad_idiomas.total === 0
                        ? html`<p class="tarjeta-cuerpo texto-suave">La vacante ${c.vacante ? html`«${c.vacante}»` : ""} no exige idiomas.</p>`
                        : html`
                            <div class="tabla-contenedor">
                                <table class="tabla tabla-compacta">
                                    <thead><tr><th>Idioma</th><th>Mínimo exigido</th><th>Nivel del candidato</th><th>Resultado</th></tr></thead>
                                    <tbody>
                                        ${c.compatibilidad_idiomas.detalle.map(d => html`
                                            <tr>
                                                <td><strong class="negrita">${d.idioma}</strong></td>
                                                <td>${d.nivel_requerido}</td>
                                                <td>${d.nivel_candidato || html`<span class="texto-suave">No registrado</span>`}</td>
                                                <td>${resultadoIdioma(d.resultado)}</td>
                                            </tr>
                                        `)}
                                    </tbody>
                                </table>
                            </div>
                            <p class="tarjeta-pie texto-suave texto-pequeno">
                                La evaluación apoya la decisión del reclutador; nunca descarta automáticamente al candidato.
                                ${c.compatibilidad_idiomas.sin_informacion ? "«Sin información» significa que el idioma no consta en su perfil profesional." : ""}
                            </p>
                        `}
                </article>

                <article class="tarjeta">
                    <div class="tarjeta-encabezado">
                        <div>
                            <h2>Perfil profesional</h2>
                            <p>Competencias, idiomas y formación</p>
                        </div>
                        <a class="boton boton-fantasma boton-pequeno" href="#/candidatos/${c.id}/perfil">${icono("editar")} Editar</a>
                    </div>
                    <div class="tarjeta-cuerpo perfil-secciones">

                        <div>
                            <h3>Competencias</h3>
                            ${c.competencias.length
                                ? html`<div class="chips">${c.competencias.map(x => html`<span class="chip chip-estatico">${x.descripcion}</span>`)}</div>`
                                : html`<p class="texto-suave">Sin competencias registradas.</p>`}
                        </div>

                        <div>
                            <h3>Idiomas</h3>
                            ${c.idiomas.length
                                ? html`<ul class="lista-idiomas">${c.idiomas.map(x => html`
                                    <li><span>${x.nombre}</span><span class="nivel-idioma" data-nivel="${x.nivel}">${x.nivel}</span></li>`)}</ul>`
                                : html`<p class="texto-suave">Sin idiomas registrados.</p>`}
                        </div>

                        <div>
                            <h3>Formación y capacitaciones</h3>
                            ${c.capacitaciones.length
                                ? html`<ul class="lista-formacion">${c.capacitaciones.map(x => html`
                                    <li>
                                        <span class="formacion-icono">${icono("capacitacion")}</span>
                                        <div>
                                            <strong>${x.descripcion}</strong>
                                            <span>${x.nivel} · ${x.institucion || "Institución no indicada"}</span>
                                            <span class="texto-suave texto-pequeno">${fecha(x.fecha_desde)} – ${x.fecha_hasta ? fecha(x.fecha_hasta) : "Actualidad"}</span>
                                        </div>
                                    </li>`)}</ul>`
                                : html`<p class="texto-suave">Sin capacitaciones registradas.</p>`}
                        </div>
                    </div>
                </article>

                <article class="tarjeta">
                    <div class="tarjeta-encabezado">
                        <div>
                            <h2>Experiencia laboral</h2>
                            <p>${aniosExperiencia(c.anios_experiencia)} en total</p>
                        </div>
                        <button class="boton boton-secundario boton-pequeno" type="button" data-nueva-experiencia>${icono("mas")} Añadir</button>
                    </div>
                    ${c.experiencia.length === 0
                        ? vistaVacia({ icono: "experiencia", titulo: "Sin experiencia registrada", texto: "Añade los empleos anteriores del candidato." })
                        : html`
                            <ul class="linea-tiempo">
                                ${c.experiencia.map(x => html`
                                    <li>
                                        <div class="linea-tiempo-contenido">
                                            <div class="flex-entre">
                                                <div>
                                                    <strong>${x.puesto_ocupado}</strong>
                                                    <span>${x.empresa}</span>
                                                </div>
                                                <div class="flex">
                                                    <button class="boton boton-icono" type="button" data-editar-experiencia="${x.id_experiencia}" aria-label="Editar experiencia en ${x.empresa}">${icono("editar")}</button>
                                                    <button class="boton boton-icono peligro" type="button" data-eliminar-experiencia="${x.id_experiencia}" aria-label="Eliminar experiencia en ${x.empresa}">${icono("eliminar")}</button>
                                                </div>
                                            </div>
                                            <span class="texto-suave texto-pequeno">
                                                ${fecha(x.fecha_desde)} – ${x.fecha_hasta ? fecha(x.fecha_hasta) : "Actualidad"}
                                                ${x.salario ? html` · ${dinero(x.salario)}` : ""}
                                            </span>
                                        </div>
                                    </li>
                                `)}
                            </ul>
                        `}
                </article>
            </div>


            <div class="pila">

                <article class="tarjeta">
                    <div class="tarjeta-encabezado">
                        <div>
                            <h2>Historial del proceso</h2>
                            <p>Cambios de etapa y responsables</p>
                        </div>
                    </div>
                    ${c.historial.length === 0
                        ? vistaVacia({ icono: "reloj", titulo: "Sin movimientos registrados" })
                        : html`
                            <ul class="historial">
                                ${c.historial.map(h => html`
                                    <li>
                                        <span class="historial-punto" data-etapa="${h.etapa_nueva}"></span>
                                        <div>
                                            <div class="flex envolver">
                                                ${h.etapa_anterior && h.etapa_anterior !== h.etapa_nueva
                                                    ? html`${insigniaEtapa(h.etapa_anterior)} ${icono("siguiente", "icono-flecha")} ${insigniaEtapa(h.etapa_nueva)}`
                                                    : insigniaEtapa(h.etapa_nueva)}
                                            </div>
                                            ${h.observacion ? html`<p>${h.observacion}</p>` : ""}
                                            <span class="texto-suave texto-pequeno">
                                                ${fechaHora(h.fecha)}${h.usuario ? html` · ${h.usuario}` : ""}
                                            </span>
                                        </div>
                                    </li>
                                `)}
                            </ul>
                        `}
                </article>

                ${esAdmin && !c.id_empleado ? html`
                    <article class="tarjeta tarjeta-peligro">
                        <div class="tarjeta-cuerpo">
                            <h2>Eliminar candidato</h2>
                            <p class="texto-suave texto-pequeno mt-1">Borra al candidato y todos sus datos asociados. Solo disponible para administradores.</p>
                            <button class="boton boton-secundario boton-pequeno mt-2" type="button" data-eliminar-candidato>${icono("eliminar")} Eliminar candidato</button>
                        </div>
                    </article>
                ` : ""}
            </div>
        </section>
    `);


    const recargar = recargarVista;

    contenedor.querySelector("[data-mover]")?.addEventListener("change", async evento => {

        const etapa = evento.target.value;
        evento.target.value = "";

        if (etapa && await moverDeEtapa(c, etapa)) {
            await recargar();
        }
    });

    contenedor.addEventListener("click", async evento => {

        const objetivo = evento.target.closest("button");

        if (!objetivo) return;

        if (objetivo.matches("[data-nueva-experiencia]")) {
            abrirFormularioExperiencia({ idCandidato: c.id, alGuardar: recargar });
        }

        if (objetivo.dataset.editarExperiencia) {
            const experiencia = c.experiencia.find(x => x.id_experiencia === Number(objetivo.dataset.editarExperiencia));
            abrirFormularioExperiencia({ experiencia: { ...experiencia, id_candidato: c.id }, alGuardar: recargar });
        }

        if (objetivo.dataset.eliminarExperiencia) {
            const experiencia = c.experiencia.find(x => x.id_experiencia === Number(objetivo.dataset.eliminarExperiencia));
            if (await eliminarExperiencia(experiencia)) await recargar();
        }

        if (objetivo.matches("[data-eliminar-candidato]") && await eliminarCandidato(c)) {
            location.hash = "#/candidatos";
        }
    });
}


// ==========================================
// EDITOR DEL PERFIL PROFESIONAL
// ==========================================

export async function vistaEditorPerfil(contenedor, [id]) {

    const [c, referencias] = await Promise.all([
        api.get(`/candidatos/${id}`),
        obtenerReferencias({ forzar: true })
    ]);

    const competenciasActuales = new Set(c.competencias.map(x => x.id_competencia));
    const capacitacionesActuales = new Set(c.capacitaciones.map(x => x.id_capacitacion));
    const idiomasActuales = new Map(c.idiomas.map(x => [x.id_idioma, x.nivel]));

    // Se muestran los elementos activos y los ya asignados (aunque estén inactivos).
    const competencias = referencias.competencias.filter(x => x.estado === "Activo" || competenciasActuales.has(x.id_competencia));
    const idiomas = referencias.idiomas.filter(x => x.estado === "Activo" || idiomasActuales.has(x.id_idioma));
    const capacitaciones = referencias.capacitaciones.filter(x => x.estado === "Activo" || capacitacionesActuales.has(x.id_capacitacion));

    pintar(contenedor, html`

        ${encabezado({
            titulo: "Perfil profesional",
            descripcion: html`Selecciona las competencias, idiomas y formación de <strong>${c.nombre}</strong>.`,
            volver: { enlace: `#/candidatos/${id}`, texto: "Volver al perfil" }
        })}

        <form class="pila" novalidate>

            <section class="tarjeta">
                <div class="tarjeta-encabezado">
                    <div>
                        <h2>Competencias</h2>
                        <p data-contador-competencias></p>
                    </div>
                    <a class="boton boton-fantasma boton-pequeno" href="#/competencias">Gestionar catálogo</a>
                </div>
                <div class="tarjeta-cuerpo">
                    ${competencias.length === 0
                        ? html`<p class="texto-suave">No hay competencias activas en el catálogo.</p>`
                        : html`<div class="chips">
                            ${competencias.map(x => html`
                                <label class="chip">
                                    <input type="checkbox" name="competencia" value="${x.id_competencia}" ${competenciasActuales.has(x.id_competencia) ? "checked" : ""}>
                                    ${x.descripcion}
                                </label>
                            `)}
                        </div>`}
                </div>
            </section>

            <section class="tarjeta">
                <div class="tarjeta-encabezado">
                    <div>
                        <h2>Idiomas</h2>
                        <p>Marca los idiomas que domina e indica su nivel.</p>
                    </div>
                </div>
                <div class="tarjeta-cuerpo">
                    <div class="rejilla-idiomas">
                        ${idiomas.map(x => html`
                            <div class="opcion-idioma">
                                <label class="casilla">
                                    <input type="checkbox" name="idioma" value="${x.id_idioma}" ${idiomasActuales.has(x.id_idioma) ? "checked" : ""}>
                                    <span>${x.nombre}</span>
                                </label>
                                <select class="control" data-nivel="${x.id_idioma}" aria-label="Nivel de ${x.nombre}" ${idiomasActuales.has(x.id_idioma) ? "" : "disabled"}>
                                    ${referencias.niveles_idioma.map(n => html`
                                        <option ${(idiomasActuales.get(x.id_idioma) || "Intermedio") === n ? "selected" : ""}>${n}</option>
                                    `)}
                                </select>
                            </div>
                        `)}
                    </div>
                </div>
            </section>

            <section class="tarjeta">
                <div class="tarjeta-encabezado">
                    <div>
                        <h2>Formación y capacitaciones</h2>
                        <p data-contador-capacitaciones></p>
                    </div>
                    <label class="buscador buscador-compacto">
                        <span class="solo-lectores">Buscar capacitación</span>
                        ${icono("buscar")}
                        <input class="control" type="search" placeholder="Buscar capacitación..." data-buscar-capacitacion>
                    </label>
                </div>
                <div class="tarjeta-cuerpo">
                    <div class="lista-seleccion">
                        ${capacitaciones.map(x => html`
                            <label class="opcion-seleccion" data-texto="${normalizar(`${x.descripcion} ${x.institucion} ${x.nivel}`)}">
                                <input type="checkbox" name="capacitacion" value="${x.id_capacitacion}" ${capacitacionesActuales.has(x.id_capacitacion) ? "checked" : ""}>
                                <span>
                                    <strong>${x.descripcion}</strong>
                                    <small>${x.nivel} · ${x.institucion || "—"}</small>
                                </span>
                            </label>
                        `)}
                    </div>
                    <p class="texto-suave texto-pequeno mt-2">
                        ¿No encuentras una capacitación? Créala primero en <a href="#/capacitaciones">Capacitaciones</a>.
                    </p>
                </div>
            </section>

            <div class="barra-guardar">
                <span class="texto-suave">Los cambios se guardan en MySQL al pulsar «Guardar perfil».</span>
                <div class="flex">
                    <a class="boton boton-secundario" href="#/candidatos/${id}">Cancelar</a>
                    <button class="boton boton-primario" type="submit">${icono("check")} Guardar perfil</button>
                </div>
            </div>
        </form>
    `);

    const formulario = contenedor.querySelector("form");

    const actualizarContadores = () => {

        const comp = formulario.querySelectorAll('[name="competencia"]:checked').length;
        const capa = formulario.querySelectorAll('[name="capacitacion"]:checked').length;

        formulario.querySelector("[data-contador-competencias]").textContent =
            `${comp} seleccionada${comp === 1 ? "" : "s"}`;
        formulario.querySelector("[data-contador-capacitaciones]").textContent =
            `${capa} seleccionada${capa === 1 ? "" : "s"}`;
    };

    formulario.addEventListener("change", evento => {

        if (evento.target.name === "idioma") {
            formulario.querySelector(`[data-nivel="${evento.target.value}"]`).disabled = !evento.target.checked;
        }

        actualizarContadores();
    });

    formulario.querySelector("[data-buscar-capacitacion]").addEventListener("input", evento => {

        const termino = normalizar(evento.target.value);

        formulario.querySelectorAll(".opcion-seleccion").forEach(opcion => {
            opcion.hidden = termino && !opcion.dataset.texto.includes(termino);
        });
    });

    formulario.addEventListener("submit", async evento => {

        evento.preventDefault();

        const valores = nombre => [...formulario.querySelectorAll(`[name="${nombre}"]:checked`)].map(x => Number(x.value));

        const cuerpo = {
            competencias: valores("competencia"),
            capacitaciones: valores("capacitacion"),
            idiomas: valores("idioma").map(idIdioma => ({
                id: idIdioma,
                nivel: formulario.querySelector(`[data-nivel="${idIdioma}"]`).value
            }))
        };

        try {
            await conEspera(evento.submitter, async () => {
                const respuesta = await api.put(`/candidatos/${id}/perfil`, cuerpo);
                notificar(respuesta.mensaje);
                location.hash = `#/candidatos/${id}`;
            });
        } catch (error) {
            notificar(error.message, "error");
        }
    });

    actualizarContadores();
}
