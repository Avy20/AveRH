// ==========================================
// AveRH - Reportes
// Ingresos de empleados y proceso de selección.
// ==========================================

import { api, parametros } from "../nucleo/api.js";
import { html, pintar } from "../nucleo/html.js";
import { icono } from "../nucleo/iconos.js";
import { dinero, fecha, fechaHora, hoyISO, numero, plural } from "../nucleo/formato.js";
import { sesion, obtenerReferencias, opcionesDe } from "../nucleo/estado.js";
import { encabezado, insigniaEtapa, insigniaEstado, persona, barras, vistaCargando, alerta, notificar, conEspera } from "../nucleo/ui.js";
import { campo, leerFormulario } from "../nucleo/formularios.js";
import { crearTabla, exportarExcel } from "../nucleo/tabla.js";


const COLOR_ETAPA = {
    "Postulado": "var(--etapa-postulado)",
    "Entrevista": "var(--etapa-entrevista)",
    "Evaluación": "var(--etapa-evaluacion)",
    "Oferta": "var(--etapa-oferta)",
    "Contratado": "var(--etapa-contratado)",
    "Descartado": "var(--etapa-descartado)"
};


// Períodos rápidos.
function periodo(clave) {

    const hoy = new Date();
    const iso = f => `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, "0")}-${String(f.getDate()).padStart(2, "0")}`;

    switch (clave) {
        case "mes": return { desde: iso(new Date(hoy.getFullYear(), hoy.getMonth(), 1)), hasta: hoyISO() };
        case "trimestre": return { desde: iso(new Date(hoy.getFullYear(), hoy.getMonth() - 2, 1)), hasta: hoyISO() };
        case "anio": return { desde: `${hoy.getFullYear()}-01-01`, hasta: hoyISO() };
        default: return { desde: "", hasta: "" };
    }
}


function textoPeriodo({ desde, hasta }) {

    if (desde && hasta) return `del ${fecha(desde)} al ${fecha(hasta)}`;
    if (desde) return `desde el ${fecha(desde)}`;
    if (hasta) return `hasta el ${fecha(hasta)}`;

    return "todos los registros";
}


function cabeceraImpresion(titulo, periodoDatos) {

    return html`
        <div class="solo-impresion cabecera-impresion">
            <div class="marca">
                <span class="marca-logo">Av</span>
                <span class="marca-texto"><strong>AveRH</strong><span>Reclutamiento y Selección</span></span>
            </div>
            <div>
                <h1>${titulo}</h1>
                <p>Período: ${textoPeriodo(periodoDatos)} · Generado el ${fechaHora(new Date())} por ${sesion.usuario.nombre}</p>
            </div>
        </div>
    `;
}


function indicadorReporte(titulo, valor, detalle = "") {

    return html`
        <div class="indicador indicador-compacto">
            <div>
                <div class="indicador-titulo">${titulo}</div>
                <div class="indicador-valor">${valor}</div>
                ${detalle ? html`<div class="indicador-detalle">${detalle}</div>` : ""}
            </div>
        </div>
    `;
}


// ------------------------------------------
// REPORTE DE INGRESOS
// ------------------------------------------

function pintarIngresos(destino, datos) {

    const r = datos.resumen;

    pintar(destino, html`

        ${cabeceraImpresion("Reporte de ingresos de personal", datos.periodo)}

        <section class="rejilla rejilla-4">
            ${indicadorReporte("Ingresos en el período", numero(r.total), `${r.activos} activos · ${r.inactivos} inactivos`)}
            ${indicadorReporte("Nómina mensual (activos)", dinero(r.nomina_mensual))}
            ${indicadorReporte("Salario promedio", dinero(r.salario_promedio))}
            ${indicadorReporte("Salario máximo", r.total ? dinero(r.salario_maximo) : "—", r.total ? `Mínimo: ${dinero(r.salario_minimo)}` : "")}
        </section>

        <section class="rejilla rejilla-2 mt-3">
            <article class="tarjeta">
                <div class="tarjeta-encabezado"><h2>Por departamento</h2></div>
                <div class="tarjeta-cuerpo">
                    ${datos.por_departamento.length ? barras(datos.por_departamento, { porcentaje: true }) : html`<p class="texto-suave">Sin datos.</p>`}
                </div>
            </article>
            <article class="tarjeta">
                <div class="tarjeta-encabezado"><h2>Por puesto</h2></div>
                <div class="tarjeta-cuerpo">
                    ${datos.por_puesto.length ? barras(datos.por_puesto, { color: "var(--gold-500)" }) : html`<p class="texto-suave">Sin datos.</p>`}
                </div>
            </article>
        </section>

        <article class="tarjeta mt-3">
            <div class="tarjeta-encabezado">
                <div>
                    <h2>Detalle de ingresos</h2>
                    <p>${plural(r.total, "empleado")} · ${textoPeriodo(datos.periodo)}</p>
                </div>
            </div>
            <div data-tabla></div>
        </article>
    `);

    crearTabla(destino.querySelector("[data-tabla]"), {
        filas: datos.empleados,
        porPagina: 1000,
        nombreRegistro: ["empleado", "empleados"],
        vacio: { icono: "empleado", titulo: "No hubo ingresos en este período" },
        columnas: [
            { clave: "nombre", titulo: "Empleado", ordenable: true, mostrar: e => persona(e.nombre, e.cedula) },
            { clave: "fecha_ingreso", titulo: "Ingreso", ordenable: true, clase: "secundario", mostrar: e => fecha(e.fecha_ingreso) },
            { clave: "puesto", titulo: "Puesto", ordenable: true },
            { clave: "departamento", titulo: "Departamento", ordenable: true },
            { clave: "salario_mensual", titulo: "Salario", ordenable: true, clase: "numero", mostrar: e => dinero(e.salario_mensual) },
            { clave: "estado", titulo: "Estado", ordenable: true, mostrar: e => insigniaEstado(e.estado) }
        ]
    });
}


// ------------------------------------------
// REPORTE DEL PROCESO DE SELECCIÓN
// ------------------------------------------

function pintarSeleccion(destino, datos) {

    const r = datos.resumen;

    pintar(destino, html`

        ${cabeceraImpresion("Reporte del proceso de selección", datos.periodo)}

        ${r.sin_fecha_postulacion ? html`
            <div class="alerta alerta-info mb-2">
                ${icono("info")}
                <div>${plural(r.sin_fecha_postulacion, "candidato no tiene", "candidatos no tienen")} fecha de postulación registrada
                y no se incluyen al filtrar por fechas. Usa «Todo» para verlos.</div>
            </div>
        ` : ""}

        <section class="rejilla rejilla-4">
            ${indicadorReporte("Candidatos", numero(r.total), `${r.en_proceso} todavía en proceso`)}
            ${indicadorReporte("Contratados", numero(r.contratados), `${r.descartados} descartados`)}
            ${indicadorReporte("Tasa de contratación", `${r.tasa_contratacion}%`, "Sobre procesos finalizados")}
            ${indicadorReporte("Tiempo medio de contratación", r.dias_promedio_contratacion === null ? "—" : plural(r.dias_promedio_contratacion, "día"), "Desde la postulación hasta el ingreso")}
        </section>

        <section class="rejilla rejilla-3 mt-3">
            <article class="tarjeta">
                <div class="tarjeta-encabezado"><h2>Por etapa</h2></div>
                <div class="tarjeta-cuerpo">
                    ${barras(datos.por_etapa.map(e => ({ ...e, color: COLOR_ETAPA[e.nombre] })))}
                </div>
            </article>
            <article class="tarjeta">
                <div class="tarjeta-encabezado"><h2>Por fuente de reclutamiento</h2></div>
                <div class="tarjeta-cuerpo">
                    ${datos.por_fuente.length ? barras(datos.por_fuente, { color: "var(--gold-500)" }) : html`<p class="texto-suave">Sin datos.</p>`}
                </div>
            </article>
            <article class="tarjeta">
                <div class="tarjeta-encabezado"><h2>Por puesto</h2></div>
                <div class="tarjeta-cuerpo">
                    ${datos.por_puesto.length ? barras(datos.por_puesto, { color: "var(--info-600)" }) : html`<p class="texto-suave">Sin datos.</p>`}
                </div>
            </article>
        </section>

        <article class="tarjeta mt-3">
            <div class="tarjeta-encabezado">
                <div>
                    <h2>Candidatos del período</h2>
                    <p>Según su fecha de postulación · ${textoPeriodo(datos.periodo)}</p>
                </div>
            </div>
            <div data-tabla></div>
        </article>
    `);

    crearTabla(destino.querySelector("[data-tabla]"), {
        filas: datos.candidatos,
        porPagina: 1000,
        nombreRegistro: ["candidato", "candidatos"],
        vacio: { icono: "candidatos", titulo: "No hubo postulaciones en este período" },
        columnas: [
            { clave: "nombre", titulo: "Candidato", ordenable: true, mostrar: c => persona(c.nombre, c.cedula) },
            { clave: "fecha_postulacion", titulo: "Postulación", ordenable: true, clase: "secundario", mostrar: c => fecha(c.fecha_postulacion) },
            { clave: "puesto", titulo: "Puesto", ordenable: true },
            { clave: "fuente_reclutamiento", titulo: "Fuente", ordenable: true },
            { clave: "etapa", titulo: "Etapa", ordenable: true, mostrar: c => insigniaEtapa(c.etapa) }
        ]
    });
}


// Hoja «Resumen»: indicadores y distribuciones del reporte.
const distribucion = (titulo, lista) => [
    ["", null, null],
    [titulo, null, null],
    ...lista.map(g => [g.nombre, g.cantidad, g.porcentaje])
];

function hojaResumen(indicadores, distribuciones) {

    // Cada fila: [concepto, valor, porcentaje]. Los indicadores
    // monetarios van en una columna propia para darles formato.
    const filas = [];

    for (const [concepto, valor, tipo] of indicadores) {
        filas.push([concepto, tipo === "dinero" ? null : valor, null, tipo === "dinero" ? valor : null]);
    }

    for (const [titulo, lista] of distribuciones) {
        for (const fila of distribucion(titulo, lista)) {
            filas.push([fila[0], fila[1], fila[2], null]);
        }
    }

    return {
        nombre: "Resumen",
        filas,
        columnas: [
            { titulo: "Concepto", valor: f => f[0], ancho: 38 },
            { titulo: "Cantidad", valor: f => f[1], tipo: "decimal", ancho: 12 },
            { titulo: "Porcentaje", valor: f => f[2], tipo: "porcentaje", ancho: 12 },
            { titulo: "Importe", valor: f => f[3], tipo: "dinero", ancho: 18 }
        ]
    };
}


const REPORTES = {
    ingresos: {
        titulo: "Ingresos de personal",
        descripcion: "Empleados incorporados en un período, con su distribución y nómina.",
        ruta: "/reportes/ingresos",
        pintar: pintarIngresos,
        filtroDepartamento: true,
        etiquetaFechas: "Fecha de ingreso",
        excel: (datos, filtros) => ({
            titulo: "Reporte de ingresos de personal",
            subtitulo: `Período: ${textoPeriodo(datos.periodo)}${filtros.departamento ? ` · Departamento: ${filtros.departamento}` : ""}`,
            archivo: `reporte_ingresos_${hoyISO()}`,
            hojas: [
                {
                    nombre: "Detalle",
                    filas: datos.empleados,
                    columnas: [
                        { titulo: "Cédula", valor: e => e.cedula, ancho: 16 },
                        { titulo: "Empleado", valor: e => e.nombre },
                        { titulo: "Fecha de ingreso", valor: e => e.fecha_ingreso, tipo: "fecha" },
                        { titulo: "Puesto", valor: e => e.puesto },
                        { titulo: "Departamento", valor: e => e.departamento },
                        { titulo: "Salario mensual", valor: e => e.salario_mensual, tipo: "dinero", total: "suma" },
                        { titulo: "Estado", valor: e => e.estado, ancho: 11 }
                    ]
                },
                hojaResumen([
                    ["Ingresos en el período", datos.resumen.total],
                    ["Empleados activos", datos.resumen.activos],
                    ["Empleados inactivos", datos.resumen.inactivos],
                    ["Nómina mensual (activos)", datos.resumen.nomina_mensual, "dinero"],
                    ["Salario promedio (activos)", datos.resumen.salario_promedio, "dinero"],
                    ["Salario máximo", datos.resumen.salario_maximo, "dinero"],
                    ["Salario mínimo", datos.resumen.salario_minimo, "dinero"]
                ], [
                    ["Distribución por departamento", datos.por_departamento],
                    ["Distribución por puesto", datos.por_puesto]
                ])
            ]
        })
    },
    seleccion: {
        titulo: "Proceso de selección",
        descripcion: "Resultados del reclutamiento: etapas, fuentes, tasa y tiempo de contratación.",
        ruta: "/reportes/seleccion",
        pintar: pintarSeleccion,
        filtroDepartamento: false,
        etiquetaFechas: "Fecha de postulación",
        excel: datos => ({
            titulo: "Reporte del proceso de selección",
            subtitulo: `Período de postulación: ${textoPeriodo(datos.periodo)}`,
            archivo: `reporte_seleccion_${hoyISO()}`,
            hojas: [
                {
                    nombre: "Detalle",
                    filas: datos.candidatos,
                    columnas: [
                        { titulo: "Cédula", valor: c => c.cedula, ancho: 16 },
                        { titulo: "Candidato", valor: c => c.nombre },
                        { titulo: "Fecha de postulación", valor: c => c.fecha_postulacion, tipo: "fecha" },
                        { titulo: "Puesto", valor: c => c.puesto },
                        { titulo: "Departamento", valor: c => c.departamento },
                        { titulo: "Fuente", valor: c => c.fuente_reclutamiento },
                        { titulo: "Etapa", valor: c => c.etapa, ancho: 13 },
                        { titulo: "Salario aspirado", valor: c => c.salario_aspira, tipo: "dinero" },
                        { titulo: "Días hasta la contratación", valor: c => c.dias_hasta_contratacion, tipo: "entero", total: "promedio" }
                    ]
                },
                hojaResumen([
                    ["Candidatos", datos.resumen.total],
                    ["En proceso", datos.resumen.en_proceso],
                    ["Contratados", datos.resumen.contratados],
                    ["Descartados", datos.resumen.descartados],
                    ["Tasa de contratación (%)", datos.resumen.tasa_contratacion],
                    ["Días promedio hasta la contratación", datos.resumen.dias_promedio_contratacion]
                ], [
                    ["Candidatos por etapa", datos.por_etapa],
                    ["Candidatos por fuente", datos.por_fuente],
                    ["Candidatos por puesto", datos.por_puesto]
                ])
            ]
        })
    }
};


export async function vistaReportes(contenedor, [tipo = "ingresos"]) {

    const reporte = REPORTES[tipo];
    const referencias = await obtenerReferencias();
    let ultimo = null;

    pintar(contenedor, html`

        ${encabezado({
            titulo: "Reportes",
            descripcion: reporte.descripcion,
            acciones: html`
                <button class="boton boton-secundario" type="button" data-exportar disabled>${icono("descargar")} Exportar a Excel</button>
                <button class="boton boton-oscuro" type="button" data-imprimir disabled>${icono("imprimir")} Imprimir</button>
            `
        })}

        <nav class="pestanas" aria-label="Tipo de reporte">
            ${Object.entries(REPORTES).map(([clave, r]) => html`
                <a class="pestana ${clave === tipo ? "activa" : ""}" href="#${r.ruta}" ${clave === tipo ? html`aria-current="page"` : ""}>${r.titulo}</a>
            `)}
        </nav>

        <form class="tarjeta filtros-reporte" novalidate>
            <div class="tarjeta-cuerpo">
                <div class="filtros-reporte-fila">
                    ${campo({ nombre: "desde", etiqueta: `${reporte.etiquetaFechas} desde`, tipo: "date" })}
                    ${campo({ nombre: "hasta", etiqueta: "Hasta", tipo: "date" })}
                    ${reporte.filtroDepartamento ? campo({
                        nombre: "id_departamento", etiqueta: "Departamento", tipo: "select", vacio: "Todos",
                        opciones: opcionesDe(referencias.departamentos, "id_departamento", "nombre", { incluirInactivos: true })
                    }) : ""}
                    <button class="boton boton-primario" type="submit">${icono("reporte")} Generar</button>
                </div>
                <div class="flex envolver mt-2">
                    <span class="texto-suave texto-pequeno">Períodos rápidos:</span>
                    <button class="boton boton-fantasma boton-pequeno" type="button" data-periodo="mes">Este mes</button>
                    <button class="boton boton-fantasma boton-pequeno" type="button" data-periodo="trimestre">Últimos 3 meses</button>
                    <button class="boton boton-fantasma boton-pequeno" type="button" data-periodo="anio">Este año</button>
                    <button class="boton boton-fantasma boton-pequeno" type="button" data-periodo="todo">Todo</button>
                </div>
                <div data-error-general class="mt-2"></div>
            </div>
        </form>

        <section class="mt-3 area-reporte" data-reporte></section>
    `);

    const formulario = contenedor.querySelector("form");
    const destino = contenedor.querySelector("[data-reporte]");
    const botonExportar = contenedor.querySelector("[data-exportar]");
    const botonImprimir = contenedor.querySelector("[data-imprimir]");

    async function generar() {

        const filtros = leerFormulario(formulario);

        formulario.querySelector("[data-error-general]").innerHTML = "";

        if (filtros.desde && filtros.hasta && filtros.desde > filtros.hasta) {
            formulario.querySelector("[data-error-general]").innerHTML =
                alerta("error", "La fecha desde no puede ser posterior a la fecha hasta.").toString();
            return;
        }

        pintar(destino, vistaCargando("Generando reporte..."));
        botonExportar.disabled = true;
        botonImprimir.disabled = true;

        try {
            ultimo = await api.get(`/reportes/${tipo}${parametros(filtros)}`);
        } catch (error) {
            destino.innerHTML = "";
            formulario.querySelector("[data-error-general]").innerHTML = alerta("error", error.message).toString();
            return;
        }

        reporte.pintar(destino, ultimo);
        botonExportar.disabled = false;
        botonImprimir.disabled = false;
    }

    formulario.addEventListener("submit", evento => {
        evento.preventDefault();
        generar();
    });

    contenedor.addEventListener("click", async evento => {

        const boton = evento.target.closest("button");

        if (!boton) return;

        if (boton.dataset.periodo) {
            const { desde, hasta } = periodo(boton.dataset.periodo);
            formulario.elements.desde.value = desde;
            formulario.elements.hasta.value = hasta;
            generar();
        }

        if (boton.matches("[data-exportar]") && ultimo) {

            const selector = formulario.elements.id_departamento;
            const departamento = selector?.value ? selector.selectedOptions[0].textContent.trim() : "";

            try {
                await conEspera(boton, () => exportarExcel(reporte.excel(ultimo, { departamento })));
                notificar("Archivo de Excel generado.");
            } catch (error) {
                notificar(error.message, "error");
            }
        }

        if (boton.matches("[data-imprimir]")) {
            window.print();
        }
    });

    await generar();
}
