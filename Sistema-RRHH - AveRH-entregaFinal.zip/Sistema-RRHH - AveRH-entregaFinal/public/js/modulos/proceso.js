// ==========================================
// AveRH - Proceso de selección (tablero)
// ==========================================

import { api } from "../nucleo/api.js";
import { html, pintar } from "../nucleo/html.js";
import { icono } from "../nucleo/iconos.js";
import { dinero, hoyISO, normalizar, aniosExperiencia, plural } from "../nucleo/formato.js";
import { obtenerReferencias, opcionesDe } from "../nucleo/estado.js";
import { encabezado, notificar, abrirModal, avatar, alerta, insigniaCompatibilidad } from "../nucleo/ui.js";
import { campo, alEnviar } from "../nucleo/formularios.js";
import { recargarVista } from "../nucleo/navegacion.js";


// Etapas que cierran el proceso: se muestran en una franja aparte.
const ETAPAS_FINALES = ["Contratado", "Descartado"];

const DESCRIPCION_ETAPA = {
    "Postulado": "Postulaciones recibidas",
    "Entrevista": "Entrevistas programadas",
    "Evaluación": "Pruebas y evaluación",
    "Oferta": "Oferta presentada",
    "Contratado": "Incorporados a la empresa",
    "Descartado": "Procesos cerrados"
};


// ------------------------------------------
// CAMBIO DE ETAPA
// Contratar y descartar piden confirmación con datos;
// las etapas intermedias se aplican directamente.
// Devuelve true si el cambio se guardó.
// ------------------------------------------

export async function moverDeEtapa(candidato, etapa) {

    if (etapa === "Contratado") {
        return abrirContratacion(candidato);
    }

    if (etapa === "Descartado") {
        return abrirDescarte(candidato);
    }

    try {
        const respuesta = await api.put(`/proceso/${candidato.id}/etapa`, { etapa });
        notificar(respuesta.mensaje);
        return true;
    } catch (error) {
        notificar(error.message, "error");
        return false;
    }
}


function abrirContratacion(candidato) {

    return new Promise(resolve => {

        let guardado = false;

        const minimo = candidato.puesto_salario_minimo;
        const maximo = candidato.puesto_salario_maximo;

        const { dialogo, cerrar } = abrirModal({
            titulo: `Contratar a ${candidato.nombre}`,
            descripcion: "Se registrará como empleado en el mismo paso.",
            contenido: html`
                <form novalidate id="formContratacion">
                    <div class="resumen-contratacion">
                        ${avatar(candidato.nombre)}
                        <div>
                            <strong>${candidato.puesto}</strong>
                            <span>${candidato.departamento} · Rango del puesto: ${dinero(minimo)} – ${dinero(maximo)}</span>
                        </div>
                    </div>
                    <div class="formulario-rejilla mt-2">
                        ${campo({ nombre: "fecha_ingreso", etiqueta: "Fecha de ingreso", tipo: "date", requerido: true, valor: hoyISO() })}
                        ${campo({
                            nombre: "salario_mensual", etiqueta: "Salario mensual", tipo: "number", requerido: true,
                            valor: candidato.salario_aspira, prefijo: "RD$",
                            ayuda: `Aspiración del candidato: ${dinero(candidato.salario_aspira)}`,
                            atributos: { min: minimo, max: maximo, step: "any" }
                        })}
                        ${campo({ nombre: "observacion", etiqueta: "Observación", tipo: "textarea", ancho: "completo", placeholder: "Opcional: condiciones de la oferta aceptada, comentarios...", atributos: { maxlength: 255 } })}
                    </div>
                    <div data-error-general class="mt-2"></div>
                </form>
            `,
            acciones: html`
                <button class="boton boton-secundario" type="button" data-cerrar>Cancelar</button>
                <button class="boton boton-primario" type="submit" form="formContratacion">${icono("contratado")} Confirmar contratación</button>
            `,
            alCerrar: () => resolve(guardado)
        });

        alEnviar(dialogo.querySelector("form"), async datos => {

            const respuesta = await api.put(`/proceso/${candidato.id}/etapa`, {
                etapa: "Contratado",
                observacion: datos.observacion,
                contratacion: {
                    fecha_ingreso: datos.fecha_ingreso,
                    salario_mensual: Number(datos.salario_mensual)
                }
            });

            notificar(respuesta.mensaje);
            guardado = true;
            cerrar();
        });
    });
}


function abrirDescarte(candidato) {

    return new Promise(resolve => {

        let guardado = false;

        const { dialogo, cerrar } = abrirModal({
            titulo: `Descartar a ${candidato.nombre}`,
            descripcion: "El proceso de selección de este candidato se cerrará.",
            tamano: "pequeno",
            contenido: html`
                <form novalidate id="formDescarte">
                    ${campo({ nombre: "observacion", etiqueta: "Motivo", tipo: "textarea", placeholder: "Ej.: no cumple la experiencia mínima requerida.", atributos: { maxlength: 255 } })}
                    <div data-error-general class="mt-2"></div>
                </form>
            `,
            acciones: html`
                <button class="boton boton-secundario" type="button" data-cerrar>Cancelar</button>
                <button class="boton boton-peligro" type="submit" form="formDescarte">Descartar candidato</button>
            `,
            alCerrar: () => resolve(guardado)
        });

        alEnviar(dialogo.querySelector("form"), async datos => {

            const respuesta = await api.put(`/proceso/${candidato.id}/etapa`, {
                etapa: "Descartado",
                observacion: datos.observacion
            });

            notificar(respuesta.mensaje);
            guardado = true;
            cerrar();
        });
    });
}


// ------------------------------------------
// TABLERO
// ------------------------------------------

function tarjetaCandidato(c, etapas) {

    const bloqueado = Boolean(c.id_empleado);
    const dias = Number(c.dias_en_etapa);

    return html`
        <article class="tarjeta-proceso" data-id="${c.id}" draggable="${bloqueado ? "false" : "true"}"
            data-texto="${normalizar(`${c.nombre} ${c.puesto} ${c.cedula}`)}" data-puesto="${c.id_puesto}">

            <div class="tarjeta-proceso-cabecera">
                ${avatar(c.nombre)}
                <div class="persona-datos">
                    <a href="#/candidatos/${c.id}">${c.nombre}</a>
                    <span>${c.puesto || "Sin puesto"}</span>
                </div>
                ${bloqueado
                    ? html`<span class="tarjeta-proceso-agarre" title="Contratado: ya es empleado">${icono("candado")}</span>`
                    : insigniaCompatibilidad(c.compatibilidad_idiomas, { compacta: true })}
            </div>

            <dl class="tarjeta-proceso-datos">
                <div><dt>Aspiración</dt><dd class="dinero">${dinero(c.salario_aspira)}</dd></div>
                <div><dt>Experiencia</dt><dd>${Number(c.anios_experiencia) > 0 ? aniosExperiencia(c.anios_experiencia) : html`<span class="texto-suave">Sin registrar</span>`}</dd></div>
            </dl>

            <div class="tarjeta-proceso-pie">
                <span class="dias-etapa ${dias > 30 && !["Contratado", "Descartado"].includes(c.etapa) ? "atrasado" : ""}"
                    title="Tiempo en la etapa actual">
                    ${icono("reloj")} ${Number.isFinite(dias) ? (dias === 0 ? "Hoy" : `${dias} ${dias === 1 ? "día" : "días"}`) : "—"}
                </span>
                ${bloqueado
                    ? html`<a class="insignia insignia-exito sin-punto" href="#/empleados">Empleado</a>`
                    : html`
                        <label>
                            <span class="solo-lectores">Mover a ${c.nombre} a otra etapa</span>
                            <select class="selector-etapa" data-mover="${c.id}">
                                ${etapas.map(e => html`<option value="${e}" ${e === c.etapa ? "selected" : ""}>${e}</option>`)}
                            </select>
                        </label>
                    `}
            </div>
        </article>
    `;
}


export async function vistaProceso(contenedor) {

    const [{ etapas, candidatos }, referencias] = await Promise.all([
        api.get("/proceso"),
        obtenerReferencias()
    ]);

    const porEtapa = Object.fromEntries(etapas.map(e => [e, candidatos.filter(c => c.etapa === e)]));

    const activos = candidatos.filter(c => !["Contratado", "Descartado"].includes(c.etapa)).length;
    const finalizados = porEtapa["Contratado"].length + porEtapa["Descartado"].length;
    const tasa = finalizados ? Math.round((porEtapa["Contratado"].length / finalizados) * 100) : 0;

    const columna = etapa => html`
        <div class="columna-proceso" data-etapa="${etapa}">
            <header class="columna-proceso-cabecera">
                <div>
                    <h2>${etapa}</h2>
                    <p>${DESCRIPCION_ETAPA[etapa]}</p>
                </div>
                <span class="columna-proceso-total" data-total>${porEtapa[etapa].length}</span>
            </header>
            <div class="columna-proceso-cuerpo" data-soltar="${etapa}">
                ${porEtapa[etapa].map(c => tarjetaCandidato(c, etapas))}
                <p class="columna-proceso-vacia" ${porEtapa[etapa].length ? "hidden" : ""}>Sin candidatos en esta etapa</p>
            </div>
        </div>
    `;

    pintar(contenedor, html`

        ${encabezado({
            titulo: "Proceso de selección",
            descripcion: "Arrastra cada tarjeta a su nueva etapa o usa el selector. Cada cambio queda registrado en el historial del candidato.",
            acciones: html`<a class="boton boton-primario" href="#/candidatos/nuevo">${icono("mas")} Nuevo candidato</a>`
        })}

        <section class="resumen-proceso">
            <div><strong>${candidatos.length}</strong><span>Candidatos</span></div>
            <div><strong>${activos}</strong><span>En curso</span></div>
            <div><strong>${porEtapa["Contratado"].length}</strong><span>Contratados</span></div>
            <div><strong>${tasa}%</strong><span>Tasa de contratación</span></div>
        </section>

        <nav class="navegador-etapas" aria-label="Ir a una etapa">
            ${etapas.map(etapa => html`
                <button type="button" data-ir="${etapa}">${etapa} <strong data-total-etapa="${etapa}">${porEtapa[etapa].length}</strong></button>
            `)}
        </nav>

        <div class="tarjeta herramientas herramientas-proceso">
            <label class="buscador">
                <span class="solo-lectores">Buscar candidato</span>
                ${icono("buscar")}
                <input class="control" type="search" placeholder="Buscar candidato..." data-buscar>
            </label>
            <label>
                <span class="solo-lectores">Filtrar por puesto</span>
                <select class="control" data-filtro-puesto>
                    <option value="">Todos los puestos</option>
                    ${opcionesDe(referencias.puestos, "id_puesto", "nombre", { incluirInactivos: true })
                        .map(op => html`<option value="${op.valor}">${op.texto}</option>`)}
                </select>
            </label>
            <div class="herramientas-fin" data-visibles>${plural(candidatos.length, "candidato")}</div>
        </div>

        <section class="tablero" aria-label="Etapas activas del proceso">
            ${etapas.filter(e => !ETAPAS_FINALES.includes(e)).map(columna)}
        </section>

        <h2 class="titulo-finalizados">Procesos finalizados</h2>

        <section class="tablero tablero-finalizados" aria-label="Procesos finalizados">
            ${ETAPAS_FINALES.map(columna)}
        </section>
    `);


    const buscador = contenedor.querySelector("[data-buscar]");
    const filtroPuesto = contenedor.querySelector("[data-filtro-puesto]");

    const aplicarFiltros = () => {

        const termino = normalizar(buscador.value);
        const puesto = filtroPuesto.value;
        let visibles = 0;

        contenedor.querySelectorAll(".columna-proceso").forEach(columna => {

            let enColumna = 0;

            columna.querySelectorAll(".tarjeta-proceso").forEach(tarjeta => {
                const visible = (!termino || tarjeta.dataset.texto.includes(termino)) &&
                    (!puesto || tarjeta.dataset.puesto === puesto);
                tarjeta.hidden = !visible;
                if (visible) enColumna++;
            });

            columna.querySelector("[data-total]").textContent = enColumna;
            contenedor.querySelector(`[data-total-etapa="${columna.dataset.etapa}"]`).textContent = enColumna;
            columna.querySelector(".columna-proceso-vacia").hidden = enColumna > 0;
            visibles += enColumna;
        });

        contenedor.querySelector("[data-visibles]").textContent = plural(visibles, "candidato");
    };

    buscador.addEventListener("input", aplicarFiltros);

    // Ir a la columna de una etapa y resaltarla un momento.
    contenedor.querySelector(".navegador-etapas").addEventListener("click", evento => {

        const boton = evento.target.closest("[data-ir]");

        if (!boton) return;

        const columna = contenedor.querySelector(`.columna-proceso[data-etapa="${boton.dataset.ir}"]`);

        columna.scrollIntoView({ behavior: "smooth", block: "center" });
        columna.classList.add("resaltada");
        setTimeout(() => columna.classList.remove("resaltada"), 1400);
    });
    filtroPuesto.addEventListener("change", aplicarFiltros);


    const mover = async (id, etapa) => {

        const candidato = candidatos.find(c => c.id === Number(id));

        if (!candidato || candidato.etapa === etapa) return;

        const tarjeta = contenedor.querySelector(`.tarjeta-proceso[data-id="${id}"]`);
        tarjeta?.classList.add("guardando");

        const guardado = await moverDeEtapa(candidato, etapa);

        tarjeta?.classList.remove("guardando");

        if (guardado) {
            recargarVista();
        } else {
            // Se restaura el selector a la etapa actual.
            const selector = tarjeta?.querySelector("[data-mover]");
            if (selector) selector.value = candidato.etapa;
        }
    };


    // Selector accesible (teclado y lectores de pantalla).
    contenedor.addEventListener("change", evento => {
        const selector = evento.target.closest("[data-mover]");
        if (selector) mover(selector.dataset.mover, selector.value);
    });


    // Arrastrar y soltar.
    let arrastrado = null;

    contenedor.addEventListener("dragstart", evento => {

        const tarjeta = evento.target.closest('.tarjeta-proceso[draggable="true"]');

        if (!tarjeta) return;

        arrastrado = tarjeta.dataset.id;
        evento.dataTransfer.effectAllowed = "move";
        evento.dataTransfer.setData("text/plain", arrastrado);
        requestAnimationFrame(() => tarjeta.classList.add("arrastrando"));
    });

    contenedor.addEventListener("dragend", evento => {
        evento.target.closest(".tarjeta-proceso")?.classList.remove("arrastrando");
        contenedor.querySelectorAll(".sobre").forEach(z => z.classList.remove("sobre"));
        arrastrado = null;
    });

    contenedor.addEventListener("dragover", evento => {

        const zona = evento.target.closest("[data-soltar]");

        if (!zona || !arrastrado) return;

        evento.preventDefault();
        evento.dataTransfer.dropEffect = "move";

        contenedor.querySelectorAll(".sobre").forEach(z => z !== zona && z.classList.remove("sobre"));
        zona.classList.add("sobre");
    });

    contenedor.addEventListener("dragleave", evento => {
        const zona = evento.target.closest("[data-soltar]");
        if (zona && !zona.contains(evento.relatedTarget)) zona.classList.remove("sobre");
    });

    contenedor.addEventListener("drop", evento => {

        const zona = evento.target.closest("[data-soltar]");

        if (!zona) return;

        evento.preventDefault();
        zona.classList.remove("sobre");

        const id = evento.dataTransfer.getData("text/plain") || arrastrado;

        if (id) mover(id, zona.dataset.soltar);
    });


    if (candidatos.length === 0) {
        contenedor.querySelector(".herramientas-proceso").insertAdjacentHTML(
            "afterend",
            alerta("info", "Todavía no hay candidatos en el proceso. Registra uno para empezar.").toString()
        );
    }
}
