// ==========================================
// AveRH - Consulta de candidatos por criterios
// ==========================================

import { api, parametros } from "../nucleo/api.js";
import { html, pintar } from "../nucleo/html.js";
import { icono } from "../nucleo/iconos.js";
import { dinero, aniosExperiencia, hoyISO, plural } from "../nucleo/formato.js";
import { obtenerReferencias, opcionesDe } from "../nucleo/estado.js";
import { encabezado, insigniaEtapa, persona, vistaCargando, alerta, notificar, conEspera, insigniaCompatibilidad } from "../nucleo/ui.js";
import { campo, leerFormulario } from "../nucleo/formularios.js";
import { crearTabla, exportarExcel } from "../nucleo/tabla.js";


// Los filtros se conservan al volver a esta pantalla.
let ultimosFiltros = null;


export async function vistaConsulta(contenedor) {

    const referencias = await obtenerReferencias({ forzar: true });

    const opcion = (lista, valor, texto) =>
        opcionesDe(lista, valor, texto, { incluirInactivos: true });

    pintar(contenedor, html`

        ${encabezado({
            titulo: "Consulta por criterios",
            descripcion: "Encuentra candidatos combinando datos personales, salariales y de perfil profesional. Todos los criterios son opcionales."
        })}

        <form class="tarjeta" novalidate>

            <div class="tarjeta-encabezado">
                <div>
                    <h2>Criterios de búsqueda</h2>
                    <p>Se mostrarán los candidatos que cumplan <strong>todos</strong> los criterios indicados.</p>
                </div>
            </div>

            <div class="tarjeta-cuerpo">

                <section class="formulario-seccion">
                    <h3>Candidato y postulación</h3>
                    <div class="formulario-rejilla rejilla-filtros">
                        ${campo({ nombre: "texto", etiqueta: "Nombre, cédula o correo", placeholder: "Ej.: Laura o 402-" })}
                        ${campo({ nombre: "id_puesto", etiqueta: "Puesto", tipo: "select", vacio: "Todos", opciones: opcion(referencias.puestos, "id_puesto", "nombre") })}
                        ${campo({ nombre: "id_departamento", etiqueta: "Departamento", tipo: "select", vacio: "Todos", opciones: opcion(referencias.departamentos, "id_departamento", "nombre") })}
                        ${campo({ nombre: "etapa", etiqueta: "Etapa del proceso", tipo: "select", vacio: "Todas", opciones: referencias.etapas.map(e => ({ valor: e, texto: e })) })}
                        ${campo({ nombre: "salario_min", etiqueta: "Aspiración mínima", tipo: "number", prefijo: "RD$", atributos: { min: 0, step: "any" } })}
                        ${campo({ nombre: "salario_max", etiqueta: "Aspiración máxima", tipo: "number", prefijo: "RD$", atributos: { min: 0, step: "any" } })}
                        ${campo({ nombre: "experiencia_min", etiqueta: "Experiencia mínima (años)", tipo: "number", atributos: { min: 0, max: 50, step: 0.5 } })}
                        ${campo({ nombre: "fuente", etiqueta: "Fuente de reclutamiento", tipo: "select", vacio: "Todas", opciones: referencias.fuentes.map(f => ({ valor: f, texto: f })) })}
                    </div>
                </section>

                <section class="formulario-seccion">
                    <h3>Perfil profesional</h3>
                    <div class="formulario-rejilla rejilla-filtros">
                        ${campo({ nombre: "id_idioma", etiqueta: "Idioma", tipo: "select", vacio: "Cualquiera", opciones: opcion(referencias.idiomas, "id_idioma", "nombre") })}
                        ${campo({ nombre: "nivel_idioma", etiqueta: "Nivel mínimo del idioma", tipo: "select", vacio: null, opciones: referencias.niveles_idioma.map(n => ({ valor: n, texto: n })) })}
                        ${campo({ nombre: "id_capacitacion", etiqueta: "Capacitación", tipo: "select", vacio: "Cualquiera", opciones: opcion(referencias.capacitaciones, "id_capacitacion", "descripcion") })}
                        ${campo({ nombre: "nivel_capacitacion", etiqueta: "Nivel de formación", tipo: "select", vacio: "Cualquiera", opciones: referencias.niveles_capacitacion.map(n => ({ valor: n, texto: n })) })}
                    </div>

                    <div class="campo mt-2">
                        <span class="campo-etiqueta">Competencias (debe tenerlas todas)</span>
                        <div class="chips">
                            ${referencias.competencias.map(c => html`
                                <label class="chip">
                                    <input type="checkbox" name="competencia" value="${c.id_competencia}">
                                    ${c.descripcion}
                                </label>
                            `)}
                        </div>
                    </div>
                </section>

                <div data-error-general class="mt-2"></div>
            </div>

            <div class="tarjeta-pie flex-entre envolver">
                <span class="texto-suave texto-pequeno" data-resumen-filtros>Sin criterios: se muestran todos los candidatos.</span>
                <div class="flex">
                    <button class="boton boton-secundario" type="reset">Limpiar</button>
                    <button class="boton boton-primario" type="submit">${icono("buscar")} Buscar candidatos</button>
                </div>
            </div>
        </form>

        <section class="mt-3" data-resultados></section>
    `);


    const formulario = contenedor.querySelector("form");
    const resultados = contenedor.querySelector("[data-resultados]");
    let ultimaBusqueda = [];

    const leerFiltros = () => {

        const datos = leerFormulario(formulario);

        delete datos.competencia;

        datos.competencias = [...formulario.querySelectorAll('[name="competencia"]:checked')].map(x => x.value);

        // El nivel del idioma solo tiene sentido con un idioma elegido.
        if (!datos.id_idioma) delete datos.nivel_idioma;

        return datos;
    };

    const contarFiltros = filtros =>
        Object.entries(filtros).filter(([, v]) => (Array.isArray(v) ? v.length : v)).length;


    async function buscar() {

        const filtros = leerFiltros();
        ultimosFiltros = filtros;

        const cantidad = contarFiltros(filtros);

        formulario.querySelector("[data-resumen-filtros]").textContent = cantidad
            ? `${plural(cantidad, "criterio aplicado", "criterios aplicados")}.`
            : "Sin criterios: se muestran todos los candidatos.";

        formulario.querySelector("[data-error-general]").innerHTML = "";
        pintar(resultados, vistaCargando("Buscando candidatos..."));

        try {
            ultimaBusqueda = await api.get(`/consultas/candidatos${parametros(filtros)}`);
        } catch (error) {
            resultados.innerHTML = "";
            formulario.querySelector("[data-error-general]").innerHTML = alerta("error", error.message).toString();
            return;
        }

        pintar(resultados, html`
            <div class="tarjeta">
                <div class="tarjeta-encabezado">
                    <div>
                        <h2>Resultados</h2>
                        <p>${plural(ultimaBusqueda.length, "candidato encontrado", "candidatos encontrados")}</p>
                    </div>
                    <button class="boton boton-secundario boton-pequeno" type="button" data-exportar ${ultimaBusqueda.length ? "" : "disabled"}>
                        ${icono("descargar")} Exportar a Excel
                    </button>
                </div>
                <div data-tabla></div>
            </div>
        `);

        crearTabla(resultados.querySelector("[data-tabla]"), {
            filas: ultimaBusqueda,
            porPagina: 15,
            nombreRegistro: ["candidato", "candidatos"],
            vacio: { icono: "buscar", titulo: "Ningún candidato cumple todos los criterios", texto: "Prueba a quitar algún criterio o a ampliar los rangos." },
            columnas: [
                { clave: "nombre", titulo: "Candidato", ordenable: true, mostrar: c => persona(c.nombre, c.cedula, `#/candidatos/${c.id}`) },
                {
                    clave: "puesto", titulo: "Puesto", ordenable: true,
                    mostrar: c => html`<strong class="negrita">${c.puesto}</strong><br><span class="texto-suave texto-pequeno">${c.departamento}</span>`
                },
                {
                    clave: "competencias", titulo: "Perfil",
                    mostrar: c => html`
                        <div class="perfil-resumen">
                            ${c.competencias ? html`<span title="${c.competencias}">${icono("competencia")} ${c.competencias}</span>` : ""}
                            ${c.idiomas ? html`<span title="${c.idiomas}">${icono("idioma")} ${c.idiomas}</span>` : ""}
                            ${!c.competencias && !c.idiomas ? html`<span class="texto-suave">Perfil sin completar</span>` : ""}
                        </div>
                    `
                },
                { clave: "anios_experiencia", titulo: "Experiencia", ordenable: true, clase: "secundario", mostrar: c => aniosExperiencia(c.anios_experiencia) },
                { clave: "salario_aspira", titulo: "Aspiración", ordenable: true, clase: "numero", mostrar: c => dinero(c.salario_aspira) },
                { clave: "etapa", titulo: "Etapa", ordenable: true, mostrar: c => insigniaEtapa(c.etapa) },
                {
                    clave: "compatibilidad", titulo: "Idiomas de la vacante",
                    valorOrden: c => c.compatibilidad_idiomas?.estado || "",
                    mostrar: c => insigniaCompatibilidad(c.compatibilidad_idiomas, { compacta: true }) || html`<span class="texto-suave">—</span>`
                }
            ]
        });
    }


    formulario.addEventListener("submit", evento => {
        evento.preventDefault();
        buscar();
    });

    formulario.addEventListener("reset", () => {
        ultimosFiltros = null;
        setTimeout(buscar);
    });

    resultados.addEventListener("click", async evento => {

        const boton = evento.target.closest("[data-exportar]");

        if (!boton) return;

        const columnas = [
            { titulo: "Cédula", valor: c => c.cedula, ancho: 16 },
            { titulo: "Nombre", valor: c => c.nombre },
            { titulo: "Correo", valor: c => c.correo },
            { titulo: "Teléfono", valor: c => c.telefono, ancho: 15 },
            { titulo: "Puesto", valor: c => c.puesto },
            { titulo: "Departamento", valor: c => c.departamento },
            { titulo: "Etapa", valor: c => c.etapa, ancho: 13 },
            { titulo: "Salario aspirado", valor: c => c.salario_aspira, tipo: "dinero" },
            { titulo: "Años de experiencia", valor: c => c.anios_experiencia, tipo: "decimal" },
            { titulo: "Competencias", valor: c => c.competencias, ancho: 45 },
            { titulo: "Idiomas", valor: c => c.idiomas, ancho: 35 }
        ];

        const criterios = contarFiltros(ultimosFiltros || {});

        try {
            await conEspera(boton, () => exportarExcel({
                titulo: "Consulta de candidatos por criterios",
                subtitulo: `${ultimaBusqueda.length} candidatos · ${criterios ? `${criterios} criterio(s) aplicado(s)` : "sin criterios"}`,
                archivo: `consulta_candidatos_${hoyISO()}`,
                hojas: [{ nombre: "Candidatos", columnas, filas: ultimaBusqueda }]
            }));
            notificar("Archivo de Excel generado.");
        } catch (error) {
            notificar(error.message, "error");
        }
    });


    // Restaura los filtros de la última búsqueda.
    if (ultimosFiltros) {

        for (const [clave, valor] of Object.entries(ultimosFiltros)) {

            if (clave === "competencias") {
                valor.forEach(id => {
                    const casilla = formulario.querySelector(`[name="competencia"][value="${id}"]`);
                    if (casilla) casilla.checked = true;
                });
            } else if (formulario.elements[clave]) {
                formulario.elements[clave].value = valor;
            }
        }
    }

    await buscar();
}
