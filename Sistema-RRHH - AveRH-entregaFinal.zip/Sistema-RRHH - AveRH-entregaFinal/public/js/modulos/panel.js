// ==========================================
// AveRH - Panel principal
// ==========================================

import { api } from "../nucleo/api.js";
import { html, pintar } from "../nucleo/html.js";
import { icono } from "../nucleo/iconos.js";
import { dinero, numero, mes, relativa, fechaCorta, plural } from "../nucleo/formato.js";
import { sesion } from "../nucleo/estado.js";
import { encabezado, insigniaEtapa, persona, vistaVacia, barras } from "../nucleo/ui.js";


const COLOR_ETAPA = {
    "Postulado": "var(--etapa-postulado)",
    "Entrevista": "var(--etapa-entrevista)",
    "Evaluación": "var(--etapa-evaluacion)",
    "Oferta": "var(--etapa-oferta)",
    "Contratado": "var(--etapa-contratado)",
    "Descartado": "var(--etapa-descartado)"
};


function saludo() {

    const hora = new Date().getHours();

    if (hora < 12) return "Buenos días";
    if (hora < 19) return "Buenas tardes";

    return "Buenas noches";
}


function indicador({ titulo, valor, detalle, nombreIcono, tono = "", enlace }) {

    return html`
        <a class="indicador indicador-enlace" href="${enlace}">
            <span class="indicador-icono ${tono}">${icono(nombreIcono)}</span>
            <div>
                <div class="indicador-titulo">${titulo}</div>
                <div class="indicador-valor">${valor}</div>
                <div class="indicador-detalle">${detalle}</div>
            </div>
        </a>
    `;
}


function graficoContrataciones(serie) {

    const maximo = Math.max(1, ...serie.map(p => p.cantidad));

    return html`
        <div class="columnas-grafico" role="img"
            aria-label="${serie.map(p => `${mes(p.mes)}: ${p.cantidad}`).join(", ")}">
            ${serie.map(punto => html`
                <div class="columna-grafico">
                    <span class="columna-valor">${punto.cantidad}</span>
                    <div class="columna-pista">
                        <div class="columna-relleno" style="height:${punto.cantidad ? Math.max(4, Math.round((punto.cantidad / maximo) * 100)) : 0}%"></div>
                    </div>
                    <span class="columna-etiqueta">${mes(punto.mes, true)}</span>
                </div>
            `)}
        </div>
    `;
}


function textoActividad(evento) {

    if (!evento.etapa_anterior) {
        return html`registró a <a href="#/candidatos/${evento.id_candidato}">${evento.candidato}</a>`;
    }

    if (evento.etapa_anterior === evento.etapa_nueva) {
        return html`actualizó a <a href="#/candidatos/${evento.id_candidato}">${evento.candidato}</a>: ${evento.observacion || ""}`;
    }

    return html`movió a <a href="#/candidatos/${evento.id_candidato}">${evento.candidato}</a> a ${insigniaEtapa(evento.etapa_nueva)}`;
}


export async function vistaPanel(contenedor) {

    const datos = await api.get("/panel");
    const ind = datos.indicadores;
    const nombre = sesion.usuario.nombre.split(" ")[0];

    const totalEmbudo = datos.embudo.reduce((t, e) => t + e.cantidad, 0);

    pintar(contenedor, html`

        ${encabezado({
            titulo: `${saludo()}, ${nombre}`,
            descripcion: "Este es el estado actual del reclutamiento en AveRH.",
            acciones: html`
                <a class="boton boton-secundario" href="#/proceso">${icono("proceso")} Ver proceso</a>
                <a class="boton boton-primario" href="#/candidatos/nuevo">${icono("mas")} Nuevo candidato</a>
            `
        })}

        <section class="rejilla rejilla-4" aria-label="Indicadores principales">
            ${indicador({
                titulo: "Candidatos registrados",
                valor: numero(ind.candidatos),
                detalle: html`<strong>${numero(ind.postulaciones_mes)}</strong> ${ind.postulaciones_mes === 1 ? "postulación" : "postulaciones"} este mes`,
                nombreIcono: "candidatos",
                enlace: "#/candidatos"
            })}
            ${indicador({
                titulo: "En proceso de selección",
                valor: numero(ind.en_proceso),
                detalle: "Sin decisión final todavía",
                nombreIcono: "proceso",
                tono: "azul",
                enlace: "#/proceso"
            })}
            ${indicador({
                titulo: "Empleados activos",
                valor: numero(ind.empleados_activos),
                detalle: html`<strong>${numero(ind.contrataciones_mes)}</strong> ${ind.contrataciones_mes === 1 ? "contratación" : "contrataciones"} este mes`,
                nombreIcono: "empleado",
                tono: "marino",
                enlace: "#/empleados"
            })}
            ${indicador({
                titulo: "Vacantes abiertas",
                valor: numero(ind.vacantes_abiertas),
                detalle: `${plural(ind.plazas_abiertas, "plaza disponible", "plazas disponibles")}`,
                nombreIcono: "vacante",
                tono: "dorado",
                enlace: "#/vacantes"
            })}
        </section>


        <section class="rejilla rejilla-principal mt-3">

            <article class="tarjeta">
                <div class="tarjeta-encabezado">
                    <div>
                        <h2>Embudo de selección</h2>
                        <p>Candidatos por etapa del proceso</p>
                    </div>
                    <a class="boton boton-fantasma boton-pequeno" href="#/proceso">Abrir tablero ${icono("siguiente")}</a>
                </div>
                <div class="tarjeta-cuerpo">
                    ${barras(datos.embudo.map(e => ({
                        nombre: e.etapa,
                        cantidad: e.cantidad,
                        color: COLOR_ETAPA[e.etapa]
                    })))}
                    <p class="texto-suave texto-pequeno mt-2">
                        ${plural(totalEmbudo, "candidato")} en total · Nómina mensual activa: ${dinero(ind.nomina_mensual)}
                    </p>
                </div>
            </article>

            <article class="tarjeta">
                <div class="tarjeta-encabezado">
                    <div>
                        <h2>Contrataciones</h2>
                        <p>Ingresos de los últimos 6 meses</p>
                    </div>
                </div>
                <div class="tarjeta-cuerpo">
                    ${graficoContrataciones(datos.contrataciones)}
                </div>
            </article>

        </section>


        <section class="rejilla rejilla-principal mt-3">

            <article class="tarjeta">
                <div class="tarjeta-encabezado">
                    <div>
                        <h2>Candidatos recientes</h2>
                        <p>Registrados o modificados más recientemente</p>
                    </div>
                    <a class="boton boton-fantasma boton-pequeno" href="#/candidatos">Ver todos ${icono("siguiente")}</a>
                </div>
                ${datos.recientes.length === 0
                    ? vistaVacia({ icono: "candidatos", titulo: "Aún no hay candidatos" })
                    : html`
                        <ul class="lista-recientes">
                            ${datos.recientes.map(c => html`
                                <li>
                                    ${persona(c.nombre, `${c.puesto || "Sin puesto"} · ${c.departamento || ""}`, `#/candidatos/${c.id}`)}
                                    <div class="lista-recientes-fin">
                                        ${insigniaEtapa(c.etapa)}
                                        <span class="texto-suave texto-pequeno"
                                            title="${c.fecha_actualizacion ? "Última modificación" : "Fecha de postulación"}">
                                            ${c.fecha_referencia ? relativa(c.fecha_referencia) : "—"}
                                        </span>
                                    </div>
                                </li>
                            `)}
                        </ul>
                    `}
            </article>

            <div class="pila">

                <article class="tarjeta">
                    <div class="tarjeta-encabezado">
                        <div>
                            <h2>Vacantes por cerrar</h2>
                            <p>Próximas fechas de cierre</p>
                        </div>
                    </div>
                    ${datos.vacantes_por_cerrar.length === 0
                        ? vistaVacia({ icono: "vacante", titulo: "No hay vacantes abiertas" })
                        : html`
                            <ul class="lista-simple">
                                ${datos.vacantes_por_cerrar.map(v => html`
                                    <li>
                                        <div>
                                            <strong>${v.titulo}</strong>
                                            <span>${plural(v.postulantes, "postulante")} · ${plural(v.cantidad_vacantes, "plaza")}</span>
                                        </div>
                                        ${v.fecha_cierre === null
                                            ? html`<span class="insignia sin-punto">Sin fecha</span>`
                                            : v.dias_restantes < 0
                                                ? html`<span class="insignia insignia-peligro sin-punto" title="${fechaCorta(v.fecha_cierre)}">Vencida</span>`
                                                : html`<span class="insignia ${v.dias_restantes <= 7 ? "insignia-aviso" : "insignia-info"} sin-punto"
                                                    title="${fechaCorta(v.fecha_cierre)}">
                                                    ${v.dias_restantes === 0 ? "Cierra hoy" : `${v.dias_restantes} días`}
                                                  </span>`}
                                    </li>
                                `)}
                            </ul>
                        `}
                </article>

                <article class="tarjeta">
                    <div class="tarjeta-encabezado">
                        <div>
                            <h2>Actividad reciente</h2>
                            <p>Últimas acciones del equipo</p>
                        </div>
                    </div>
                    ${datos.actividad.length === 0
                        ? vistaVacia({ icono: "reloj", titulo: "Sin actividad todavía", texto: "Aquí aparecerán los movimientos del proceso de selección." })
                        : html`
                            <ul class="actividad">
                                ${datos.actividad.map(evento => html`
                                    <li>
                                        <span class="actividad-punto"></span>
                                        <div>
                                            <p><strong>${evento.usuario || "Alguien"}</strong> ${textoActividad(evento)}</p>
                                            <span class="texto-suave texto-pequeno">${relativa(evento.fecha)}</span>
                                        </div>
                                    </li>
                                `)}
                            </ul>
                        `}
                </article>

            </div>

        </section>
    `);
}
