// ==========================================
// AveRH - Experiencia laboral
// ==========================================

import { api } from "../nucleo/api.js";
import { html, pintar } from "../nucleo/html.js";
import { icono } from "../nucleo/iconos.js";
import { dinero, fecha, hoyISO } from "../nucleo/formato.js";
import { encabezado, notificar, confirmar, abrirModal, persona } from "../nucleo/ui.js";
import { campo, alEnviar } from "../nucleo/formularios.js";
import { crearTabla } from "../nucleo/tabla.js";
import { recargarVista } from "../nucleo/navegacion.js";


function duracion(meses) {

    const total = Number(meses || 0);
    const anios = Math.floor(total / 12);
    const resto = total % 12;

    const partes = [];

    if (anios) partes.push(`${anios} ${anios === 1 ? "año" : "años"}`);
    if (resto || !anios) partes.push(`${resto} ${resto === 1 ? "mes" : "meses"}`);

    return partes.join(" y ");
}


// ------------------------------------------
// FORMULARIO (modal) — lo usa también la ficha del candidato
// ------------------------------------------

export async function abrirFormularioExperiencia({ experiencia = null, idCandidato = null, candidatos = null, alGuardar }) {

    const edicion = Boolean(experiencia?.id_experiencia);
    const datos = experiencia || { id_candidato: idCandidato };

    // Si se abre desde el módulo general, se elige el candidato.
    const lista = idCandidato || edicion ? null : (candidatos || await api.get("/candidatos"));

    const { dialogo, cerrar } = abrirModal({
        titulo: edicion ? "Editar experiencia laboral" : "Nueva experiencia laboral",
        descripcion: "Deja vacía la fecha de finalización si es el empleo actual.",
        contenido: html`
            <form novalidate id="formExperiencia">
                <div class="formulario-rejilla">
                    ${lista ? campo({
                        nombre: "id_candidato", etiqueta: "Candidato", tipo: "select", requerido: true, ancho: "completo",
                        vacio: "Seleccione un candidato",
                        opciones: lista.map(c => ({ valor: c.id, texto: `${c.nombre} · ${c.cedula}` }))
                    }) : ""}
                    ${campo({ nombre: "empresa", etiqueta: "Empresa", requerido: true, valor: datos.empresa, atributos: { maxlength: 150 } })}
                    ${campo({ nombre: "puesto_ocupado", etiqueta: "Puesto ocupado", requerido: true, valor: datos.puesto_ocupado, atributos: { maxlength: 100 } })}
                    ${campo({ nombre: "fecha_desde", etiqueta: "Desde", tipo: "date", requerido: true, valor: datos.fecha_desde, atributos: { max: hoyISO() } })}
                    ${campo({ nombre: "fecha_hasta", etiqueta: "Hasta", tipo: "date", valor: datos.fecha_hasta, ayuda: "Vacío = empleo actual", atributos: { max: hoyISO() } })}
                    ${campo({ nombre: "salario", etiqueta: "Salario mensual", tipo: "number", valor: datos.salario, prefijo: "RD$", ayuda: "Opcional", atributos: { min: 0, step: "any" } })}
                </div>
                <div data-error-general class="mt-2"></div>
            </form>
        `,
        acciones: html`
            <button class="boton boton-secundario" type="button" data-cerrar>Cancelar</button>
            <button class="boton boton-primario" type="submit" form="formExperiencia">${icono("check")} Guardar</button>
        `
    });

    alEnviar(dialogo.querySelector("form"), async valores => {

        const cuerpo = {
            ...valores,
            id_candidato: Number(valores.id_candidato || datos.id_candidato),
            salario: valores.salario === "" ? null : Number(valores.salario)
        };

        const respuesta = edicion
            ? await api.put(`/experiencias/${experiencia.id_experiencia}`, cuerpo)
            : await api.post("/experiencias", cuerpo);

        notificar(respuesta.mensaje);
        cerrar();
        await alGuardar?.();
    });
}


export async function eliminarExperiencia(experiencia) {

    const aceptado = await confirmar({
        titulo: "Eliminar experiencia",
        mensaje: `¿Eliminar la experiencia como ${experiencia.puesto_ocupado} en ${experiencia.empresa}?`,
        textoConfirmar: "Eliminar",
        peligro: true
    });

    if (!aceptado) return false;

    try {
        notificar((await api.eliminar(`/experiencias/${experiencia.id_experiencia}`)).mensaje);
        return true;
    } catch (error) {
        notificar(error.message, "error");
        return false;
    }
}


// ------------------------------------------
// MÓDULO
// ------------------------------------------

export async function vistaExperiencia(contenedor) {

    const [experiencias, candidatos] = await Promise.all([
        api.get("/experiencias"),
        api.get("/candidatos")
    ]);

    const conExperiencia = new Set(experiencias.map(e => e.id_candidato)).size;

    pintar(contenedor, html`
        ${encabezado({
            titulo: "Experiencia laboral",
            descripcion: "Historial de empleos anteriores de los candidatos. Se tiene en cuenta en la consulta por criterios.",
            acciones: html`<button class="boton boton-primario" type="button" data-nueva>${icono("mas")} Nueva experiencia</button>`
        })}

        <section class="rejilla rejilla-3">
            <div class="indicador indicador-compacto">
                <span class="indicador-icono">${icono("experiencia")}</span>
                <div><div class="indicador-titulo">Experiencias registradas</div><div class="indicador-valor">${experiencias.length}</div></div>
            </div>
            <div class="indicador indicador-compacto">
                <span class="indicador-icono azul">${icono("candidatos")}</span>
                <div><div class="indicador-titulo">Candidatos con experiencia</div><div class="indicador-valor">${conExperiencia} <small class="texto-suave">de ${candidatos.length}</small></div></div>
            </div>
            <div class="indicador indicador-compacto">
                <span class="indicador-icono dorado">${icono("reloj")}</span>
                <div><div class="indicador-titulo">Empleos actuales</div><div class="indicador-valor">${experiencias.filter(e => !e.fecha_hasta).length}</div></div>
            </div>
        </section>

        <section class="tarjeta mt-3" data-tabla></section>
    `);

    const recargar = recargarVista;

    crearTabla(contenedor.querySelector("[data-tabla]"), {
        filas: experiencias,
        nombreRegistro: ["experiencia", "experiencias"],
        placeholder: "Buscar por candidato, empresa o puesto...",
        buscarEn: e => `${e.candidato} ${e.cedula} ${e.empresa} ${e.puesto_ocupado}`,
        filtros: [{
            clave: "candidato",
            etiqueta: "Todos los candidatos",
            opciones: candidatos
                .filter(c => experiencias.some(e => e.id_candidato === c.id))
                .map(c => ({ valor: c.id, texto: c.nombre }))
                .sort((a, b) => a.texto.localeCompare(b.texto)),
            aplicar: (e, valor) => String(e.id_candidato) === valor
        }],
        vacio: { icono: "experiencia", titulo: "No hay experiencias registradas" },
        columnas: [
            { clave: "candidato", titulo: "Candidato", ordenable: true, mostrar: e => persona(e.candidato, e.cedula, `#/candidatos/${e.id_candidato}`) },
            { clave: "empresa", titulo: "Empresa", ordenable: true, mostrar: e => html`<strong class="negrita">${e.empresa}</strong>` },
            { clave: "puesto_ocupado", titulo: "Puesto", ordenable: true },
            {
                clave: "fecha_desde", titulo: "Período", ordenable: true, clase: "secundario",
                mostrar: e => html`${fecha(e.fecha_desde)} – ${e.fecha_hasta ? fecha(e.fecha_hasta) : html`<span class="insignia insignia-info sin-punto">Actual</span>`}`
            },
            { clave: "meses", titulo: "Duración", ordenable: true, clase: "secundario", mostrar: e => duracion(e.meses) },
            { clave: "salario", titulo: "Salario", ordenable: true, clase: "numero", mostrar: e => dinero(e.salario) },
            {
                clave: "acciones", titulo: html`<span class="solo-lectores">Acciones</span>`, clase: "acciones",
                mostrar: e => html`
                    <div>
                        <button class="boton boton-icono" type="button" data-editar="${e.id_experiencia}" aria-label="Editar">${icono("editar")}</button>
                        <button class="boton boton-icono peligro" type="button" data-eliminar="${e.id_experiencia}" aria-label="Eliminar">${icono("eliminar")}</button>
                    </div>
                `
            }
        ]
    });

    contenedor.addEventListener("click", async evento => {

        const boton = evento.target.closest("button");

        if (!boton) return;

        if (boton.matches("[data-nueva]")) {
            abrirFormularioExperiencia({ candidatos, alGuardar: recargar });
        }

        if (boton.dataset.editar) {
            abrirFormularioExperiencia({
                experiencia: experiencias.find(e => e.id_experiencia === Number(boton.dataset.editar)),
                alGuardar: recargar
            });
        }

        if (boton.dataset.eliminar) {
            const experiencia = experiencias.find(e => e.id_experiencia === Number(boton.dataset.eliminar));
            if (await eliminarExperiencia(experiencia)) await recargar();
        }
    });
}
