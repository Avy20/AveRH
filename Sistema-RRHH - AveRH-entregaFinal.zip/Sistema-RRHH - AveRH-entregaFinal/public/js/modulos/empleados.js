// ==========================================
// AveRH - Empleados
// ==========================================

import { api } from "../nucleo/api.js";
import { html, pintar } from "../nucleo/html.js";
import { icono } from "../nucleo/iconos.js";
import { dinero, fecha, numero, hoyISO } from "../nucleo/formato.js";
import { sesion, obtenerReferencias, opcionesDe } from "../nucleo/estado.js";
import { encabezado, notificar, confirmar, abrirModal, persona, insigniaEstado, conEspera } from "../nucleo/ui.js";
import { campo, alEnviar, activarMascaraCedula } from "../nucleo/formularios.js";
import { crearTabla, exportarExcel } from "../nucleo/tabla.js";
import { recargarVista } from "../nucleo/navegacion.js";


function antiguedad(meses) {

    const total = Number(meses || 0);

    if (total < 1) return "Menos de 1 mes";
    if (total < 12) return `${total} ${total === 1 ? "mes" : "meses"}`;

    const anios = Math.floor(total / 12);

    return `${anios} ${anios === 1 ? "año" : "años"}${total % 12 ? ` y ${total % 12} m` : ""}`;
}


async function abrirFormularioEmpleado(empleado = null) {

    const referencias = await obtenerReferencias({ forzar: true });
    const edicion = Boolean(empleado);
    const v = empleado || { fecha_ingreso: hoyISO() };

    const { dialogo, cerrar } = abrirModal({
        titulo: edicion ? `Editar a ${empleado.nombre}` : "Nuevo empleado",
        descripcion: edicion
            ? "El salario debe respetar el rango del puesto."
            : "Normalmente los empleados se crean al contratar a un candidato desde el proceso de selección.",
        contenido: html`
            <form novalidate id="formEmpleado">
                <div class="formulario-rejilla">
                    ${campo({
                        nombre: "cedula", etiqueta: "Cédula", requerido: !edicion, valor: v.cedula,
                        placeholder: "000-0000000-0", deshabilitado: edicion,
                        ayuda: edicion ? "La cédula no se puede modificar." : "Cédula dominicana de 11 dígitos."
                    })}
                    ${campo({ nombre: "nombre", etiqueta: "Nombre completo", requerido: true, valor: v.nombre, atributos: { maxlength: 150 } })}
                    ${campo({
                        nombre: "id_puesto", etiqueta: "Puesto", tipo: "select", requerido: true, valor: v.id_puesto,
                        opciones: opcionesDe(referencias.puestos, "id_puesto", p => `${p.nombre} · ${p.departamento}`, { actual: v.id_puesto })
                    })}
                    ${campo({ nombre: "fecha_ingreso", etiqueta: "Fecha de ingreso", tipo: "date", requerido: true, valor: v.fecha_ingreso })}
                    ${campo({
                        nombre: "salario_mensual", etiqueta: "Salario mensual", tipo: "number", requerido: true,
                        valor: v.salario_mensual, prefijo: "RD$", atributos: { min: 1, step: "any" }
                    })}
                </div>
                <div data-error-general class="mt-2"></div>
            </form>
        `,
        acciones: html`
            <button class="boton boton-secundario" type="button" data-cerrar>Cancelar</button>
            <button class="boton boton-primario" type="submit" form="formEmpleado">${icono("check")} Guardar</button>
        `
    });

    const formulario = dialogo.querySelector("form");

    if (!edicion) {
        activarMascaraCedula(formulario.elements.cedula);
    }

    // Rango salarial del puesto elegido.
    const ayuda = formulario.querySelector('[data-campo="salario_mensual"] [data-ayuda]');

    const mostrarRango = () => {
        const puesto = referencias.puestos.find(p => String(p.id_puesto) === formulario.elements.id_puesto.value);
        ayuda.className = "campo-ayuda";
        ayuda.textContent = puesto ? `Rango del puesto: ${dinero(puesto.salario_minimo)} – ${dinero(puesto.salario_maximo)}` : "";
    };

    formulario.elements.id_puesto.addEventListener("change", mostrarRango);
    mostrarRango();

    alEnviar(formulario, async datos => {

        const cuerpo = {
            ...datos,
            id_puesto: Number(datos.id_puesto),
            salario_mensual: datos.salario_mensual === "" ? "" : Number(datos.salario_mensual)
        };

        const respuesta = edicion
            ? await api.put(`/empleados/${empleado.id}`, cuerpo)
            : await api.post("/empleados", cuerpo);

        notificar(respuesta.mensaje);
        cerrar();
        recargarVista();
    });
}


export async function vistaEmpleados(contenedor) {

    const [empleados, referencias] = await Promise.all([
        api.get("/empleados"),
        obtenerReferencias()
    ]);

    const activos = empleados.filter(e => e.estado === "Activo");
    const nomina = activos.reduce((t, e) => t + Number(e.salario_mensual), 0);
    const esAdmin = sesion.esAdministrador();

    pintar(contenedor, html`

        ${encabezado({
            titulo: "Empleados",
            descripcion: "Personal contratado. Los candidatos contratados en el proceso de selección aparecen aquí automáticamente.",
            acciones: html`
                <button class="boton boton-secundario" type="button" data-exportar>${icono("descargar")} Exportar a Excel</button>
                <button class="boton boton-primario" type="button" data-nuevo>${icono("mas")} Nuevo empleado</button>
            `
        })}

        <section class="rejilla rejilla-4">
            <div class="indicador indicador-compacto">
                <span class="indicador-icono marino">${icono("empleado")}</span>
                <div><div class="indicador-titulo">Empleados activos</div><div class="indicador-valor">${activos.length}</div>
                <div class="indicador-detalle">${empleados.length - activos.length} inactivos</div></div>
            </div>
            <div class="indicador indicador-compacto">
                <span class="indicador-icono">${icono("dinero")}</span>
                <div><div class="indicador-titulo">Nómina mensual</div><div class="indicador-valor">${dinero(nomina)}</div></div>
            </div>
            <div class="indicador indicador-compacto">
                <span class="indicador-icono dorado">${icono("tendencia")}</span>
                <div><div class="indicador-titulo">Salario promedio</div><div class="indicador-valor">${dinero(activos.length ? Math.round(nomina / activos.length) : 0)}</div></div>
            </div>
            <div class="indicador indicador-compacto">
                <span class="indicador-icono azul">${icono("departamento")}</span>
                <div><div class="indicador-titulo">Departamentos</div><div class="indicador-valor">${numero(new Set(activos.map(e => e.departamento)).size)}</div>
                <div class="indicador-detalle">con personal activo</div></div>
            </div>
        </section>

        <section class="tarjeta mt-3" data-tabla></section>
    `);

    const tabla = crearTabla(contenedor.querySelector("[data-tabla]"), {
        filas: empleados,
        nombreRegistro: ["empleado", "empleados"],
        placeholder: "Buscar por nombre, cédula o puesto...",
        buscarEn: e => `${e.nombre} ${e.cedula} ${e.puesto} ${e.departamento}`,
        claseFila: e => (e.estado === "Activo" ? "" : "fila-inactiva"),
        filtros: [
            { clave: "estado", etiqueta: "Todos los estados", opciones: ["Activo", "Inactivo"], aplicar: (e, v) => e.estado === v },
            {
                clave: "departamento", etiqueta: "Todos los departamentos",
                opciones: opcionesDe(referencias.departamentos, "id_departamento", "nombre", { incluirInactivos: true }),
                aplicar: (e, v) => String(e.id_departamento) === v
            }
        ],
        vacio: { icono: "empleado", titulo: "No hay empleados registrados", texto: "Contrata a un candidato desde el proceso de selección." },
        columnas: [
            {
                clave: "nombre", titulo: "Empleado", ordenable: true,
                mostrar: e => persona(e.nombre, e.cedula, e.id_candidato ? `#/candidatos/${e.id_candidato}` : "")
            },
            {
                clave: "puesto", titulo: "Puesto", ordenable: true,
                mostrar: e => html`<strong class="negrita">${e.puesto || "—"}</strong><br><span class="texto-suave texto-pequeno">${e.departamento || ""}</span>`
            },
            { clave: "fecha_ingreso", titulo: "Ingreso", ordenable: true, clase: "secundario", mostrar: e => fecha(e.fecha_ingreso) },
            { clave: "meses_antiguedad", titulo: "Antigüedad", ordenable: true, clase: "secundario", mostrar: e => antiguedad(e.meses_antiguedad) },
            { clave: "salario_mensual", titulo: "Salario", ordenable: true, clase: "numero", mostrar: e => dinero(e.salario_mensual) },
            { clave: "estado", titulo: "Estado", ordenable: true, mostrar: e => insigniaEstado(e.estado) },
            {
                clave: "acciones", titulo: html`<span class="solo-lectores">Acciones</span>`, clase: "acciones",
                mostrar: e => html`
                    <div>
                        <button class="boton boton-icono" type="button" data-editar="${e.id}" title="Editar" aria-label="Editar a ${e.nombre}">${icono("editar")}</button>
                        <button class="boton boton-icono" type="button" data-estado="${e.id}"
                            title="${e.estado === "Activo" ? "Desactivar" : "Activar"}" aria-label="${e.estado === "Activo" ? "Desactivar" : "Activar"} a ${e.nombre}">
                            ${icono("encender")}
                        </button>
                        ${esAdmin ? html`
                            <button class="boton boton-icono peligro" type="button" data-eliminar="${e.id}" title="Eliminar" aria-label="Eliminar a ${e.nombre}">${icono("eliminar")}</button>
                        ` : ""}
                    </div>
                `
            }
        ]
    });

    contenedor.addEventListener("click", async evento => {

        const boton = evento.target.closest("button");

        if (!boton) return;

        const empleado = empleados.find(e => e.id === Number(boton.dataset.editar || boton.dataset.estado || boton.dataset.eliminar));

        if (boton.matches("[data-nuevo]")) {
            abrirFormularioEmpleado();
        }

        if (boton.matches("[data-exportar]")) {
            const filas = tabla.filasVisibles();

            try {
                await conEspera(boton, () => exportarExcel({
                    titulo: "Empleados",
                    subtitulo: `${filas.length} de ${empleados.length} empleados (según los filtros aplicados)`,
                    archivo: `empleados_averh_${hoyISO()}`,
                    hojas: [{
                        nombre: "Empleados",
                        filas,
                        columnas: [
                            { titulo: "Cédula", valor: e => e.cedula, ancho: 16 },
                            { titulo: "Nombre", valor: e => e.nombre },
                            { titulo: "Puesto", valor: e => e.puesto },
                            { titulo: "Departamento", valor: e => e.departamento },
                            { titulo: "Fecha de ingreso", valor: e => e.fecha_ingreso, tipo: "fecha" },
                            { titulo: "Antigüedad (meses)", valor: e => e.meses_antiguedad, tipo: "entero" },
                            { titulo: "Salario mensual", valor: e => e.salario_mensual, tipo: "dinero", total: "suma" },
                            { titulo: "Estado", valor: e => e.estado }
                        ]
                    }]
                }));
                notificar("Archivo de Excel generado.");
            } catch (error) {
                notificar(error.message, "error");
            }
        }

        if (boton.dataset.editar) {
            abrirFormularioEmpleado(empleado);
        }

        if (boton.dataset.estado) {

            const desactivar = empleado.estado === "Activo";

            if (desactivar && !await confirmar({
                titulo: "Desactivar empleado",
                mensaje: `${empleado.nombre} dejará de contar en la nómina y en los indicadores de personal activo.`,
                textoConfirmar: "Desactivar"
            })) return;

            try {
                const respuesta = await api.patch(`/empleados/${empleado.id}/estado`, { estado: desactivar ? "Inactivo" : "Activo" });
                notificar(respuesta.mensaje);
                recargarVista();
            } catch (error) {
                notificar(error.message, "error");
            }
        }

        if (boton.dataset.eliminar) {

            if (!await confirmar({
                titulo: "Eliminar empleado",
                mensaje: `Se eliminará el registro de ${empleado.nombre}. Si solo ha dejado la empresa, es preferible desactivarlo para conservar el historial.`,
                textoConfirmar: "Eliminar",
                peligro: true
            })) return;

            try {
                notificar((await api.eliminar(`/empleados/${empleado.id}`)).mensaje);
                recargarVista();
            } catch (error) {
                notificar(error.message, "error");
            }
        }
    });
}
