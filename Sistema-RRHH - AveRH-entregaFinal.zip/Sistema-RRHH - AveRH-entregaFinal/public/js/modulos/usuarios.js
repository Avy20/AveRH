// ==========================================
// AveRH - Administración de usuarios
// (solo administradores)
// ==========================================

import { api } from "../nucleo/api.js";
import { html, pintar } from "../nucleo/html.js";
import { icono } from "../nucleo/iconos.js";
import { fecha } from "../nucleo/formato.js";
import { sesion } from "../nucleo/estado.js";
import { encabezado, notificar, confirmar, abrirModal, persona, insigniaEstado } from "../nucleo/ui.js";
import { campo, alEnviar, marcarError } from "../nucleo/formularios.js";
import { crearTabla } from "../nucleo/tabla.js";
import { recargarVista } from "../nucleo/navegacion.js";


const ROLES = [
    { valor: "Administrador", texto: "Administrador — acceso completo" },
    { valor: "Recursos Humanos", texto: "Recursos Humanos — sin administración de usuarios" }
];


function abrirFormularioUsuario(usuario = null) {

    const edicion = Boolean(usuario);
    const esUnoMismo = edicion && usuario.id === sesion.usuario.id;

    const { dialogo, cerrar } = abrirModal({
        titulo: edicion ? "Editar usuario" : "Nuevo usuario",
        descripcion: edicion
            ? "Deja la contraseña vacía para conservar la actual."
            : "El usuario iniciará sesión con su correo y esta contraseña.",
        contenido: html`
            <form novalidate id="formUsuario" autocomplete="off">
                <div class="formulario-rejilla">
                    ${campo({ nombre: "nombre", etiqueta: "Nombre completo", requerido: true, valor: usuario?.nombre, atributos: { maxlength: 150, minlength: 3 } })}
                    ${campo({ nombre: "correo", etiqueta: "Correo electrónico", tipo: "email", requerido: true, valor: usuario?.correo, atributos: { maxlength: 150 } })}
                    ${campo({
                        nombre: "rol", etiqueta: "Rol", tipo: "select", requerido: true, ancho: "completo",
                        valor: usuario?.rol, opciones: ROLES, deshabilitado: esUnoMismo,
                        ayuda: esUnoMismo ? "No puedes cambiar tu propio rol." : ""
                    })}
                    ${campo({
                        nombre: "contrasena", etiqueta: edicion ? "Nueva contraseña" : "Contraseña", tipo: "password",
                        requerido: !edicion, ayuda: "Mínimo 8 caracteres.",
                        atributos: { minlength: 8, maxlength: 72, autocomplete: "new-password" }
                    })}
                    ${campo({
                        nombre: "confirmar", etiqueta: "Confirmar contraseña", tipo: "password", requerido: !edicion,
                        atributos: { maxlength: 72, autocomplete: "new-password" }
                    })}
                </div>
                <div data-error-general class="mt-2"></div>
            </form>
        `,
        acciones: html`
            <button class="boton boton-secundario" type="button" data-cerrar>Cancelar</button>
            <button class="boton boton-primario" type="submit" form="formUsuario">${icono("check")} Guardar</button>
        `
    });

    const formulario = dialogo.querySelector("form");

    alEnviar(formulario, async datos => {

        // Las contraseñas no se recortan: se leen tal cual.
        const contrasena = formulario.elements.contrasena.value;

        if (contrasena !== formulario.elements.confirmar.value) {
            marcarError(formulario, "confirmar", "Las contraseñas no coinciden.");
            return;
        }

        const cuerpo = {
            nombre: datos.nombre,
            correo: datos.correo,
            rol: esUnoMismo ? usuario.rol : datos.rol,
            ...(contrasena ? { contrasena } : {})
        };

        const respuesta = edicion
            ? await api.put(`/usuarios/${usuario.id}`, cuerpo)
            : await api.post("/usuarios", cuerpo);

        if (esUnoMismo) {
            sesion.establecer({ ...sesion.usuario, nombre: cuerpo.nombre, correo: cuerpo.correo });
            document.querySelector("#usuarioActual strong").textContent = cuerpo.nombre;
        }

        notificar(respuesta.mensaje);
        cerrar();
        recargarVista();
    });
}


export async function vistaUsuarios(contenedor) {

    const usuarios = await api.get("/usuarios");
    const activos = usuarios.filter(u => u.estado === "Activo");
    const administradores = activos.filter(u => u.rol === "Administrador").length;

    pintar(contenedor, html`

        ${encabezado({
            titulo: "Usuarios",
            descripcion: "Cuentas con acceso a AveRH y sus permisos. Las contraseñas se guardan cifradas (bcrypt).",
            acciones: html`<button class="boton boton-primario" type="button" data-nuevo>${icono("mas")} Nuevo usuario</button>`
        })}

        <section class="rejilla rejilla-3">
            <div class="indicador indicador-compacto">
                <span class="indicador-icono marino">${icono("candidatos")}</span>
                <div><div class="indicador-titulo">Usuarios registrados</div><div class="indicador-valor">${usuarios.length}</div></div>
            </div>
            <div class="indicador indicador-compacto">
                <span class="indicador-icono">${icono("check")}</span>
                <div><div class="indicador-titulo">Usuarios activos</div><div class="indicador-valor">${activos.length}</div></div>
            </div>
            <div class="indicador indicador-compacto">
                <span class="indicador-icono dorado">${icono("seguridad")}</span>
                <div><div class="indicador-titulo">Administradores activos</div><div class="indicador-valor">${administradores}</div></div>
            </div>
        </section>

        <div class="alerta alerta-info mt-3">
            ${icono("info")}
            <div>
                <strong>Permisos.</strong> El rol <em>Administrador</em> gestiona usuarios y puede eliminar registros.
                <em>Recursos Humanos</em> realiza todo el proceso de reclutamiento, pero no elimina datos ni administra cuentas.
            </div>
        </div>

        <section class="tarjeta mt-3" data-tabla></section>
    `);

    crearTabla(contenedor.querySelector("[data-tabla]"), {
        filas: usuarios,
        nombreRegistro: ["usuario", "usuarios"],
        placeholder: "Buscar por nombre o correo...",
        buscarEn: u => `${u.nombre} ${u.correo}`,
        claseFila: u => (u.estado === "Activo" ? "" : "fila-inactiva"),
        filtros: [
            { clave: "rol", etiqueta: "Todos los roles", opciones: ["Administrador", "Recursos Humanos"], aplicar: (u, v) => u.rol === v },
            { clave: "estado", etiqueta: "Todos los estados", opciones: ["Activo", "Inactivo"], aplicar: (u, v) => u.estado === v }
        ],
        columnas: [
            {
                clave: "nombre", titulo: "Usuario", ordenable: true,
                mostrar: u => html`${persona(u.nombre, u.correo)}${u.id === sesion.usuario.id ? html`<span class="insignia insignia-info sin-punto etiqueta-tu">Tú</span>` : ""}`
            },
            {
                clave: "rol", titulo: "Rol", ordenable: true,
                mostrar: u => html`<span class="insignia sin-punto ${u.rol === "Administrador" ? "insignia-dorada" : "insignia-info"}">${u.rol}</span>`
            },
            { clave: "estado", titulo: "Estado", ordenable: true, mostrar: u => insigniaEstado(u.estado) },
            { clave: "fecha_creacion", titulo: "Alta", ordenable: true, clase: "secundario", mostrar: u => fecha(u.fecha_creacion) },
            {
                clave: "acciones", titulo: html`<span class="solo-lectores">Acciones</span>`, clase: "acciones",
                mostrar: u => html`
                    <div>
                        <button class="boton boton-icono" type="button" data-editar="${u.id}" title="Editar" aria-label="Editar a ${u.nombre}">${icono("editar")}</button>
                        ${u.id === sesion.usuario.id ? "" : html`
                            <button class="boton boton-secundario boton-pequeno" type="button" data-estado="${u.id}">
                                ${u.estado === "Activo" ? "Desactivar" : "Activar"}
                            </button>
                        `}
                    </div>
                `
            }
        ]
    });

    contenedor.addEventListener("click", async evento => {

        const boton = evento.target.closest("button");

        if (!boton) return;

        const usuario = usuarios.find(u => u.id === Number(boton.dataset.editar || boton.dataset.estado));

        if (boton.matches("[data-nuevo]")) {
            abrirFormularioUsuario();
        }

        if (boton.dataset.editar) {
            abrirFormularioUsuario(usuario);
        }

        if (boton.dataset.estado) {

            const desactivar = usuario.estado === "Activo";

            if (desactivar && !await confirmar({
                titulo: "Desactivar usuario",
                mensaje: `${usuario.nombre} perderá el acceso a AveRH de inmediato, incluso si tiene la sesión abierta.`,
                textoConfirmar: "Desactivar"
            })) return;

            try {
                const respuesta = await api.patch(`/usuarios/${usuario.id}/estado`, { estado: desactivar ? "Inactivo" : "Activo" });
                notificar(respuesta.mensaje);
                recargarVista();
            } catch (error) {
                notificar(error.message, "error");
            }
        }
    });
}
