// ==========================================
// AveRH - Catálogos
// Una sola implementación para vacantes, puestos,
// departamentos, competencias, idiomas y capacitaciones.
// ==========================================

import { api } from "../nucleo/api.js";
import { html, pintar } from "../nucleo/html.js";
import { icono } from "../nucleo/iconos.js";
import { dinero, fecha, hoyISO, plural } from "../nucleo/formato.js";
import { sesion, obtenerReferencias, invalidarReferencias, opcionesDe } from "../nucleo/estado.js";
import { encabezado, notificar, confirmar, abrirModal, insigniaEstado } from "../nucleo/ui.js";
import { campo, alEnviar } from "../nucleo/formularios.js";
import { crearTabla } from "../nucleo/tabla.js";
import { recargarVista } from "../nucleo/navegacion.js";


const numeroONulo = valor => (valor === "" || valor === undefined ? null : Number(valor));


// ------------------------------------------
// DEFINICIÓN DE CADA CATÁLOGO
// ------------------------------------------

const CATALOGOS = {

    vacantes: {
        id: "id_vacante",
        titulo: "Vacantes",
        descripcion: "Ofertas de empleo publicadas. Los candidatos se registran en una vacante abierta.",
        singular: "vacante",
        femenino: true,
        registros: ["vacante", "vacantes"],
        icono: "vacante",
        nombre: v => v.titulo,
        estados: ["Abierta", "Cerrada"],
        uso: v => (v.postulantes ? plural(v.postulantes, "postulante") : ""),
        buscarEn: v => `${v.titulo} ${v.puesto} ${v.departamento}`,
        filtros: ref => [{
            clave: "puesto", etiqueta: "Todos los puestos",
            opciones: opcionesDe(ref.puestos, "id_puesto", "nombre", { incluirInactivos: true }),
            aplicar: (v, valor) => String(v.id_puesto) === valor
        }],
        columnas: [
            {
                clave: "titulo", titulo: "Vacante", ordenable: true,
                mostrar: v => html`<strong class="negrita">${v.titulo}</strong><br><span class="texto-suave texto-pequeno">${v.puesto} · ${v.departamento || ""}</span>`
            },
            {
                clave: "salario_minimo", titulo: "Oferta salarial", clase: "numero",
                mostrar: v => v.salario_minimo || v.salario_maximo
                    ? html`${dinero(v.salario_minimo)} – ${dinero(v.salario_maximo)}`
                    : html`<span class="texto-suave">Según puesto</span>`
            },
            { clave: "cantidad_vacantes", titulo: "Plazas", ordenable: true, clase: "numero" },
            {
                clave: "postulantes", titulo: "Postulantes", ordenable: true, clase: "numero",
                mostrar: v => html`${v.postulantes}${v.contratados ? html` <span class="texto-suave texto-pequeno">(${v.contratados} contratados)</span>` : ""}`
            },
            {
                clave: "requisitos_idiomas", titulo: "Idiomas requeridos",
                mostrar: v => (v.requisitos_idiomas || []).length
                    ? html`<div class="chips-mini">${v.requisitos_idiomas.map(r => html`<span class="chip-mini" title="Nivel mínimo">${r.idioma} · ${r.nivel}</span>`)}</div>`
                    : html`<span class="texto-suave texto-pequeno">No requeridos</span>`
            },
            {
                clave: "fecha_cierre", titulo: "Publicación / cierre", ordenable: true, clase: "secundario",
                mostrar: v => html`${fecha(v.fecha_publicacion)}<br>${v.fecha_cierre ? fecha(v.fecha_cierre) : "Sin cierre"}`
            }
        ],
        campos: (ref, v) => html`
            ${campo({
                nombre: "id_puesto", etiqueta: "Puesto", tipo: "select", requerido: true, valor: v.id_puesto,
                opciones: opcionesDe(ref.puestos, "id_puesto", p => `${p.nombre} · ${p.departamento}`, { actual: v.id_puesto })
            })}
            ${campo({ nombre: "titulo", etiqueta: "Título de la vacante", requerido: true, valor: v.titulo, atributos: { maxlength: 100 } })}
            ${campo({ nombre: "descripcion", etiqueta: "Descripción", tipo: "textarea", ancho: "completo", valor: v.descripcion, atributos: { maxlength: 255 } })}
            ${campo({ nombre: "salario_minimo", etiqueta: "Salario mínimo ofrecido", tipo: "number", prefijo: "RD$", valor: v.salario_minimo, ayuda: "Opcional. Dentro del rango del puesto.", atributos: { min: 1, step: "any" } })}
            ${campo({ nombre: "salario_maximo", etiqueta: "Salario máximo ofrecido", tipo: "number", prefijo: "RD$", valor: v.salario_maximo, ayuda: "Opcional.", atributos: { min: 1, step: "any" } })}
            ${campo({ nombre: "cantidad_vacantes", etiqueta: "Plazas", tipo: "number", requerido: true, valor: v.cantidad_vacantes ?? 1, atributos: { min: 1, max: 999, step: 1 } })}
            ${campo({ nombre: "experiencia_minima", etiqueta: "Experiencia mínima (años)", tipo: "number", valor: v.experiencia_minima ?? 0, atributos: { min: 0, max: 50, step: 0.5 } })}
            <div></div>
            ${campo({ nombre: "fecha_publicacion", etiqueta: "Fecha de publicación", tipo: "date", requerido: true, valor: v.fecha_publicacion || hoyISO() })}
            ${campo({ nombre: "fecha_cierre", etiqueta: "Fecha de cierre", tipo: "date", valor: v.fecha_cierre, ayuda: "Opcional." })}
            <div class="campo ancho-completo" data-campo="idiomas">
                <span class="campo-etiqueta">Requisitos de idiomas</span>
                <div class="requisitos-idiomas" data-requisitos></div>
                <small class="campo-ayuda" data-ayuda>Nivel mínimo aceptable para cada idioma. Los idiomas no añadidos se consideran «No requerido».</small>
            </div>
        `,
        // Requisitos de idiomas: filas compactas, solo de los idiomas exigidos.
        alAbrir: (formulario, ref, v) => {

            const contenedor = formulario.querySelector("[data-requisitos]");
            const idiomas = ref.idiomas;
            const requisitos = new Map((v.requisitos_idiomas || []).map(r => [r.id_idioma, r.nivel]));

            const pintarRequisitos = () => {

                const disponibles = idiomas.filter(i => i.estado === "Activo" && !requisitos.has(i.id_idioma));

                pintar(contenedor, html`
                    ${[...requisitos].map(([idIdioma, nivel]) => {
                        const idioma = idiomas.find(i => i.id_idioma === idIdioma);
                        return html`
                            <div class="requisito-idioma">
                                ${icono("idioma")}
                                <span>${idioma?.nombre || "Idioma"}</span>
                                <select class="control" data-nivel-requisito="${idIdioma}" aria-label="Nivel mínimo de ${idioma?.nombre || ""}">
                                    ${ref.niveles_requisito.map(n => html`<option ${n === nivel ? "selected" : ""}>${n}</option>`)}
                                </select>
                                <button class="boton boton-icono" type="button" data-quitar-requisito="${idIdioma}" aria-label="Quitar ${idioma?.nombre || ""}">${icono("cerrar")}</button>
                            </div>
                        `;
                    })}
                    ${disponibles.length ? html`
                        <select class="control agregar-idioma" data-agregar-idioma aria-label="Añadir idioma requerido">
                            <option value="">+ Añadir idioma requerido…</option>
                            ${disponibles.map(i => html`<option value="${i.id_idioma}">${i.nombre}</option>`)}
                        </select>
                    ` : ""}
                `);
            };

            contenedor.addEventListener("change", evento => {

                if (evento.target.matches("[data-agregar-idioma]") && evento.target.value) {
                    requisitos.set(Number(evento.target.value), "Intermedio");
                    pintarRequisitos();
                    contenedor.querySelector("[data-agregar-idioma]")?.focus();
                }

                if (evento.target.dataset.nivelRequisito) {
                    requisitos.set(Number(evento.target.dataset.nivelRequisito), evento.target.value);
                }
            });

            contenedor.addEventListener("click", evento => {
                const boton = evento.target.closest("[data-quitar-requisito]");
                if (boton) {
                    requisitos.delete(Number(boton.dataset.quitarRequisito));
                    pintarRequisitos();
                }
            });

            formulario.leerRequisitos = () => [...requisitos].map(([id_idioma, nivel]) => ({ id_idioma, nivel }));

            pintarRequisitos();
        },
        convertir: (d, formulario) => ({
            ...d,
            idiomas: formulario.leerRequisitos(),
            id_puesto: Number(d.id_puesto),
            salario_minimo: numeroONulo(d.salario_minimo),
            salario_maximo: numeroONulo(d.salario_maximo),
            cantidad_vacantes: numeroONulo(d.cantidad_vacantes),
            experiencia_minima: numeroONulo(d.experiencia_minima)
        })
    },

    puestos: {
        id: "id_puesto",
        titulo: "Puestos",
        descripcion: "Puestos de trabajo con su departamento, nivel de riesgo y rango salarial.",
        singular: "puesto",
        registros: ["puesto", "puestos"],
        icono: "puesto",
        nombre: p => p.nombre,
        uso: p => [p.candidatos && plural(p.candidatos, "candidato"), p.empleados && plural(p.empleados, "empleado")].filter(Boolean).join(" y "),
        buscarEn: p => `${p.nombre} ${p.departamento} ${p.descripcion || ""}`,
        filtros: ref => [{
            clave: "departamento", etiqueta: "Todos los departamentos",
            opciones: opcionesDe(ref.departamentos, "id_departamento", "nombre", { incluirInactivos: true }),
            aplicar: (p, valor) => String(p.id_departamento) === valor
        }],
        columnas: [
            {
                clave: "nombre", titulo: "Puesto", ordenable: true,
                mostrar: p => html`<strong class="negrita">${p.nombre}</strong>${p.descripcion ? html`<br><span class="texto-suave texto-pequeno">${p.descripcion}</span>` : ""}`
            },
            { clave: "departamento", titulo: "Departamento", ordenable: true },
            {
                clave: "nivel_riesgo", titulo: "Riesgo", ordenable: true,
                mostrar: p => html`<span class="insignia sin-punto ${{ Alto: "insignia-peligro", Medio: "insignia-aviso", Bajo: "insignia-exito" }[p.nivel_riesgo] || ""}">${p.nivel_riesgo || "—"}</span>`
            },
            { clave: "salario_minimo", titulo: "Rango salarial", ordenable: true, clase: "numero", mostrar: p => html`${dinero(p.salario_minimo)} – ${dinero(p.salario_maximo)}` },
            {
                clave: "candidatos", titulo: "Candidatos / empleados", clase: "numero",
                mostrar: p => html`${p.candidatos} / ${p.empleados}`
            }
        ],
        campos: (ref, p) => html`
            ${campo({ nombre: "nombre", etiqueta: "Nombre del puesto", requerido: true, valor: p.nombre, atributos: { maxlength: 100 } })}
            ${campo({
                nombre: "id_departamento", etiqueta: "Departamento", tipo: "select", requerido: true, valor: p.id_departamento,
                opciones: opcionesDe(ref.departamentos, "id_departamento", "nombre", { actual: p.id_departamento })
            })}
            ${campo({ nombre: "descripcion", etiqueta: "Descripción", tipo: "textarea", ancho: "completo", valor: p.descripcion, atributos: { maxlength: 255 } })}
            ${campo({
                nombre: "nivel_riesgo", etiqueta: "Nivel de riesgo", tipo: "select", requerido: true, valor: p.nivel_riesgo,
                opciones: ref.niveles_riesgo.map(n => ({ valor: n, texto: n }))
            })}
            <div></div>
            ${campo({ nombre: "salario_minimo", etiqueta: "Salario mínimo", tipo: "number", requerido: true, prefijo: "RD$", valor: p.salario_minimo, atributos: { min: 1, step: "any" } })}
            ${campo({ nombre: "salario_maximo", etiqueta: "Salario máximo", tipo: "number", requerido: true, prefijo: "RD$", valor: p.salario_maximo, atributos: { min: 1, step: "any" } })}
        `,
        convertir: d => ({
            ...d,
            id_departamento: Number(d.id_departamento),
            salario_minimo: numeroONulo(d.salario_minimo),
            salario_maximo: numeroONulo(d.salario_maximo)
        })
    },

    departamentos: {
        id: "id_departamento",
        titulo: "Departamentos",
        descripcion: "Áreas de la organización a las que pertenecen los puestos.",
        singular: "departamento",
        registros: ["departamento", "departamentos"],
        icono: "departamento",
        nombre: d => d.nombre,
        uso: d => (d.puestos ? plural(d.puestos, "puesto") : ""),
        buscarEn: d => d.nombre,
        columnas: [
            { clave: "nombre", titulo: "Departamento", ordenable: true, mostrar: d => html`<strong class="negrita">${d.nombre}</strong>` },
            { clave: "puestos", titulo: "Puestos", ordenable: true, clase: "numero" }
        ],
        campos: (ref, d) => campo({ nombre: "nombre", etiqueta: "Nombre", requerido: true, valor: d.nombre, ancho: "completo", atributos: { maxlength: 100 } }),
        convertir: d => d
    },

    competencias: {
        id: "id_competencia",
        titulo: "Competencias",
        descripcion: "Habilidades profesionales que se asignan a los candidatos y se usan en la consulta por criterios.",
        singular: "competencia",
        femenino: true,
        registros: ["competencia", "competencias"],
        icono: "competencia",
        nombre: c => c.descripcion,
        uso: c => (c.candidatos ? plural(c.candidatos, "candidato") : ""),
        buscarEn: c => c.descripcion,
        columnas: [
            { clave: "descripcion", titulo: "Competencia", ordenable: true, mostrar: c => html`<strong class="negrita">${c.descripcion}</strong>` },
            { clave: "candidatos", titulo: "Candidatos", ordenable: true, clase: "numero" }
        ],
        campos: (ref, c) => campo({ nombre: "descripcion", etiqueta: "Descripción", requerido: true, valor: c.descripcion, ancho: "completo", placeholder: "Ej.: Trabajo en equipo", atributos: { maxlength: 255 } }),
        convertir: d => d
    },

    idiomas: {
        id: "id_idioma",
        titulo: "Idiomas",
        descripcion: "Idiomas que pueden dominar los candidatos.",
        singular: "idioma",
        registros: ["idioma", "idiomas"],
        icono: "idioma",
        nombre: i => i.nombre,
        uso: i => (i.candidatos ? plural(i.candidatos, "candidato") : ""),
        buscarEn: i => i.nombre,
        columnas: [
            { clave: "nombre", titulo: "Idioma", ordenable: true, mostrar: i => html`<strong class="negrita">${i.nombre}</strong>` },
            { clave: "candidatos", titulo: "Candidatos", ordenable: true, clase: "numero" }
        ],
        campos: (ref, i) => campo({ nombre: "nombre", etiqueta: "Nombre", requerido: true, valor: i.nombre, ancho: "completo", atributos: { maxlength: 100 } }),
        convertir: d => d
    },

    capacitaciones: {
        id: "id_capacitacion",
        titulo: "Capacitaciones",
        descripcion: "Formación académica y cursos que pueden tener los candidatos.",
        singular: "capacitación",
        femenino: true,
        registros: ["capacitación", "capacitaciones"],
        icono: "capacitacion",
        nombre: c => c.descripcion,
        uso: c => (c.candidatos ? plural(c.candidatos, "candidato") : ""),
        buscarEn: c => `${c.descripcion} ${c.institucion} ${c.nivel}`,
        filtros: ref => [{
            clave: "nivel", etiqueta: "Todos los niveles", opciones: ref.niveles_capacitacion,
            aplicar: (c, valor) => c.nivel === valor
        }],
        columnas: [
            {
                clave: "descripcion", titulo: "Capacitación", ordenable: true,
                mostrar: c => html`<strong class="negrita">${c.descripcion}</strong><br><span class="texto-suave texto-pequeno">${c.institucion}</span>`
            },
            { clave: "nivel", titulo: "Nivel", ordenable: true, mostrar: c => html`<span class="insignia insignia-dorada sin-punto">${c.nivel}</span>` },
            { clave: "fecha_desde", titulo: "Período", ordenable: true, clase: "secundario", mostrar: c => html`${fecha(c.fecha_desde)} – ${fecha(c.fecha_hasta)}` },
            { clave: "candidatos", titulo: "Candidatos", ordenable: true, clase: "numero" }
        ],
        campos: (ref, c) => html`
            ${campo({ nombre: "descripcion", etiqueta: "Descripción", requerido: true, valor: c.descripcion, ancho: "completo", atributos: { maxlength: 255 } })}
            ${campo({
                nombre: "nivel", etiqueta: "Nivel", tipo: "select", requerido: true, valor: c.nivel,
                opciones: ref.niveles_capacitacion.map(n => ({ valor: n, texto: n }))
            })}
            ${campo({ nombre: "institucion", etiqueta: "Institución", requerido: true, valor: c.institucion, atributos: { maxlength: 150 } })}
            ${campo({ nombre: "fecha_desde", etiqueta: "Fecha de inicio", tipo: "date", requerido: true, valor: c.fecha_desde, atributos: { max: hoyISO() } })}
            ${campo({ nombre: "fecha_hasta", etiqueta: "Fecha de finalización", tipo: "date", requerido: true, valor: c.fecha_hasta })}
        `,
        convertir: d => d
    }
};


// ------------------------------------------
// FORMULARIO
// ------------------------------------------

async function abrirFormulario(tipo, config, registro = null) {

    const referencias = await obtenerReferencias({ forzar: true });
    const edicion = Boolean(registro);
    const articulo = config.femenino ? "Nueva" : "Nuevo";

    const { dialogo, cerrar } = abrirModal({
        titulo: edicion ? `Editar ${config.singular}` : `${articulo} ${config.singular}`,
        tamano: tipo === "vacantes" || tipo === "puestos" || tipo === "capacitaciones" ? "grande" : "pequeno",
        contenido: html`
            <form novalidate id="formCatalogo">
                <div class="formulario-rejilla ${["departamentos", "competencias", "idiomas"].includes(tipo) ? "una-columna" : ""}">
                    ${config.campos(referencias, registro || {})}
                </div>
                <div data-error-general class="mt-2"></div>
            </form>
        `,
        acciones: html`
            <button class="boton boton-secundario" type="button" data-cerrar>Cancelar</button>
            <button class="boton boton-primario" type="submit" form="formCatalogo">${icono("check")} Guardar</button>
        `
    });

    const formulario = dialogo.querySelector("form");

    config.alAbrir?.(formulario, referencias, registro || {});

    alEnviar(formulario, async datos => {

        const cuerpo = config.convertir(datos, formulario);

        const respuesta = edicion
            ? await api.put(`/${tipo}/${registro[config.id]}`, cuerpo)
            : await api.post(`/${tipo}`, cuerpo);

        invalidarReferencias();
        notificar(respuesta.mensaje);
        cerrar();
        recargarVista();
    });
}


// ------------------------------------------
// VISTA
// ------------------------------------------

export async function vistaCatalogo(contenedor, [tipo]) {

    const config = CATALOGOS[tipo];

    const [registros, referencias] = await Promise.all([
        api.get(`/${tipo}`),
        obtenerReferencias()
    ]);

    const esAdmin = sesion.esAdministrador();
    const [estadoActivo, estadoInactivo] = config.estados || ["Activo", "Inactivo"];
    const activos = registros.filter(r => r.estado === estadoActivo).length;
    const articulo = config.femenino ? "Nueva" : "Nuevo";

    pintar(contenedor, html`
        ${encabezado({
            titulo: config.titulo,
            descripcion: config.descripcion,
            acciones: html`<button class="boton boton-primario" type="button" data-nuevo>${icono("mas")} ${articulo} ${config.singular}</button>`
        })}

        <p class="resumen-catalogo">
            <span>${icono(config.icono)} ${plural(registros.length, config.registros[0], config.registros[1])}</span>
            <span class="insignia insignia-exito">${activos} ${tipo === "vacantes" ? "abiertas" : (config.femenino ? "activas" : "activos")}</span>
            ${registros.length - activos ? html`<span class="insignia">${registros.length - activos} ${tipo === "vacantes" ? "cerradas" : (config.femenino ? "inactivas" : "inactivos")}</span>` : ""}
        </p>

        <section class="tarjeta" data-tabla></section>
    `);

    crearTabla(contenedor.querySelector("[data-tabla]"), {
        filas: registros,
        nombreRegistro: config.registros,
        placeholder: `Buscar ${config.registros[1]}...`,
        buscarEn: config.buscarEn,
        filtros: [
            ...(config.filtros ? config.filtros(referencias) : []),
            { clave: "estado", etiqueta: "Todos los estados", opciones: [estadoActivo, estadoInactivo], aplicar: (r, v) => r.estado === v }
        ],
        claseFila: r => (r.estado === estadoActivo ? "" : "fila-inactiva"),
        vacio: {
            icono: config.icono,
            titulo: `No hay ${config.registros[1]} registrad${config.femenino ? "as" : "os"}`,
            accion: html`<button class="boton boton-primario" type="button" data-nuevo>${icono("mas")} ${articulo} ${config.singular}</button>`
        },
        columnas: [
            ...config.columnas,
            { clave: "estado", titulo: "Estado", ordenable: true, mostrar: r => insigniaEstado(r.estado) },
            {
                clave: "acciones", titulo: html`<span class="solo-lectores">Acciones</span>`, clase: "acciones",
                mostrar: r => {

                    const enUso = config.uso(r);
                    const nombre = config.nombre(r);
                    const textoEstado = r.estado === estadoActivo
                        ? (tipo === "vacantes" ? "Cerrar vacante" : "Desactivar")
                        : (tipo === "vacantes" ? "Reabrir vacante" : "Activar");

                    return html`
                        <div>
                            <button class="boton boton-icono" type="button" data-editar="${r[config.id]}" title="Editar" aria-label="Editar ${nombre}">${icono("editar")}</button>
                            <button class="boton boton-icono" type="button" data-estado="${r[config.id]}" title="${textoEstado}" aria-label="${textoEstado}: ${nombre}">${icono("encender")}</button>
                            ${esAdmin ? html`
                                <button class="boton boton-icono peligro" type="button" data-eliminar="${r[config.id]}"
                                    title="${enUso ? `En uso (${enUso}): desactívalo en lugar de eliminarlo` : "Eliminar"}"
                                    aria-label="Eliminar ${nombre}" ${enUso ? "disabled" : ""}>
                                    ${icono("eliminar")}
                                </button>
                            ` : ""}
                        </div>
                    `;
                }
            }
        ]
    });


    contenedor.addEventListener("click", async evento => {

        const boton = evento.target.closest("button");

        if (!boton) return;

        const id = Number(boton.dataset.editar || boton.dataset.estado || boton.dataset.eliminar);
        const registro = registros.find(r => r[config.id] === id);

        if (boton.matches("[data-nuevo]")) {
            abrirFormulario(tipo, config);
        }

        if (boton.dataset.editar) {
            abrirFormulario(tipo, config, registro);
        }

        if (boton.dataset.estado) {

            const nuevoEstado = registro.estado === estadoActivo ? estadoInactivo : estadoActivo;

            try {
                const respuesta = await api.patch(`/${tipo}/${id}/estado`, { estado: nuevoEstado });
                invalidarReferencias();
                notificar(respuesta.mensaje);
                recargarVista();
            } catch (error) {
                notificar(error.message, "error");
            }
        }

        if (boton.dataset.eliminar) {

            const aceptado = await confirmar({
                titulo: `Eliminar ${config.singular}`,
                mensaje: `¿Eliminar «${config.nombre(registro)}»? Esta acción no se puede deshacer.`,
                textoConfirmar: "Eliminar",
                peligro: true
            });

            if (!aceptado) return;

            try {
                const respuesta = await api.eliminar(`/${tipo}/${id}`);
                invalidarReferencias();
                notificar(respuesta.mensaje);
                recargarVista();
            } catch (error) {
                notificar(error.message, "error");
            }
        }
    });
}
