// ==========================================
// AveRH - Pantalla de inicio de sesión
// ==========================================

import { api } from "./nucleo/api.js";
import { alEnviar } from "./nucleo/formularios.js";


if (location.protocol === "file:" || location.port === "5500") {
    location.replace("http://localhost:3000/login.html");
}


// Pantalla a la que se vuelve tras iniciar sesión.
function destino() {

    try {

        const volver = sessionStorage.getItem("averh_volver");
        sessionStorage.removeItem("averh_volver");

        if (volver && /^#\/[\w/-]*$/.test(volver)) {
            return `/${volver}`;
        }

    } catch {
        // Sin almacenamiento: se va al panel.
    }

    return "/#/panel";
}


// Si ya hay una sesión abierta, se entra directamente.
api.get("/auth/me")
    .then(() => location.replace(destino()))
    .catch(() => {});


const formulario = document.getElementById("formLogin");

alEnviar(formulario, async datos => {
    // La contraseña se envía tal cual, sin recortar espacios.
    await api.post("/auth/login", { correo: datos.correo, contrasena: formulario.elements.contrasena.value });
    location.replace(destino());
});


const botonVer = document.getElementById("verContrasena");
const campoContrasena = document.getElementById("contrasena");

botonVer.addEventListener("click", () => {

    const visible = campoContrasena.type === "text";

    campoContrasena.type = visible ? "password" : "text";
    botonVer.setAttribute("aria-pressed", String(!visible));
    botonVer.setAttribute("aria-label", visible ? "Mostrar contraseña" : "Ocultar contraseña");
});
