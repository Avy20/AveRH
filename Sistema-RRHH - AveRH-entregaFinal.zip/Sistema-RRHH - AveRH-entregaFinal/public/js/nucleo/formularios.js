// ==========================================
// AveRH - Formularios
// ==========================================

import { html, crudo } from "./html.js";
import { alerta, conEspera } from "./ui.js";


// ------------------------------------------
// CAMPO
// campo({ nombre, etiqueta, tipo, valor, requerido, opciones, ayuda, ... })
// tipo: text | email | tel | number | date | password | select | textarea
// ------------------------------------------

export function campo({
    nombre,
    etiqueta,
    tipo = "text",
    valor = "",
    requerido = false,
    opciones = [],
    vacio = "Seleccione una opción",
    ayuda = "",
    placeholder = "",
    ancho = "",
    prefijo = "",
    atributos = {},
    deshabilitado = false
}) {

    const id = `campo-${nombre}`;
    const valorTexto = valor ?? "";

    const extras = Object.entries(atributos)
        .map(([clave, v]) => ` ${clave}="${String(v).replace(/"/g, "&quot;")}"`)
        .join("");

    let control;

    if (tipo === "select") {

        control = html`
            <select class="control" id="${id}" name="${nombre}" ${requerido ? "required" : ""} ${deshabilitado ? "disabled" : ""}>
                ${vacio !== null ? html`<option value="">${vacio}</option>` : ""}
                ${opciones.map(op => html`
                    <option value="${op.valor}" ${String(op.valor) === String(valorTexto) ? "selected" : ""} ${op.deshabilitada ? "disabled" : ""}>
                        ${op.texto}
                    </option>
                `)}
            </select>
        `;

    } else if (tipo === "textarea") {

        control = html`
            <textarea class="control" id="${id}" name="${nombre}" placeholder="${placeholder}"
                ${requerido ? "required" : ""} ${deshabilitado ? "disabled" : ""}>${valorTexto}</textarea>
        `;

    } else {

        // Los atributos extra (min, max, maxlength...) son
        // generados por AveRH, no por el usuario.
        control = html`
            <input class="control" id="${id}" name="${nombre}" type="${tipo}" value="${valorTexto}"
                placeholder="${placeholder}" ${requerido ? "required" : ""} ${deshabilitado ? "disabled" : ""}
                ${crudo(extras)}>
        `;
    }

    return html`
        <div class="campo ${ancho === "completo" ? "ancho-completo" : ""}" data-campo="${nombre}">
            <label for="${id}">${etiqueta}${requerido ? html`<span class="requerido" aria-hidden="true">*</span>` : ""}</label>
            ${prefijo ? html`<div class="control-con-prefijo"><span>${prefijo}</span>${control}</div>` : control}
            <small class="campo-ayuda" data-ayuda>${ayuda}</small>
        </div>
    `;
}


// ------------------------------------------
// LECTURA
// ------------------------------------------

export function leerFormulario(formulario) {

    const datos = {};

    for (const [clave, valor] of new FormData(formulario).entries()) {
        datos[clave] = typeof valor === "string" ? valor.trim() : valor;
    }

    return datos;
}


// ------------------------------------------
// ERRORES
// ------------------------------------------

export function limpiarErrores(formulario) {

    formulario.querySelectorAll(".campo.con-error").forEach(c => {

        c.classList.remove("con-error");

        const ayuda = c.querySelector("[data-ayuda]");

        if (ayuda?.dataset.original !== undefined) {
            ayuda.textContent = ayuda.dataset.original;
            ayuda.className = "campo-ayuda";
        }
    });

    const general = formulario.querySelector("[data-error-general]");

    if (general) {
        general.innerHTML = "";
    }
}


export function marcarError(formulario, nombreCampo, mensaje) {

    const contenedor = formulario.querySelector(`.campo[data-campo="${nombreCampo}"]`);

    if (!contenedor) {
        return false;
    }

    const ayuda = contenedor.querySelector("[data-ayuda]");

    if (ayuda.dataset.original === undefined) {
        ayuda.dataset.original = ayuda.textContent;
    }

    contenedor.classList.add("con-error");
    ayuda.className = "campo-error";
    ayuda.textContent = mensaje;

    contenedor.querySelector(".control")?.focus();

    return true;
}


// Muestra el error junto al campo indicado por la API o,
// si no hay campo, como alerta general del formulario.
export function mostrarError(formulario, error) {

    limpiarErrores(formulario);

    if (error.campo && marcarError(formulario, error.campo, error.message)) {
        return;
    }

    const general = formulario.querySelector("[data-error-general]");

    if (general) {
        general.innerHTML = alerta("error", error.message).toString();
        general.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
}


// Envía un formulario: valida en el navegador, muestra la espera
// en el botón y los errores devueltos por la API.
export function alEnviar(formulario, accion) {

    formulario.addEventListener("submit", async evento => {

        evento.preventDefault();

        const boton = evento.submitter || formulario.querySelector("[type=submit]");

        limpiarErrores(formulario);

        // Validación nativa: campos obligatorios, correo, mínimos...
        const invalido = [...formulario.elements].find(el => el.willValidate && !el.checkValidity());

        if (invalido) {
            marcarError(formulario, invalido.name, mensajeNativo(invalido));
            return;
        }

        try {
            await conEspera(boton, () => accion(leerFormulario(formulario), formulario));
        } catch (error) {
            mostrarError(formulario, error);
        }
    });
}


function mensajeNativo(control) {

    const v = control.validity;
    const etiqueta = control.closest(".campo")?.querySelector("label")?.textContent.replace("*", "").trim() || "Este campo";

    if (v.valueMissing) return `${etiqueta}: este campo es obligatorio.`;
    if (v.typeMismatch && control.type === "email") return "Introduce un correo electrónico válido.";
    if (v.rangeUnderflow) return `El valor mínimo es ${control.min}.`;
    if (v.rangeOverflow) return `El valor máximo es ${control.max}.`;
    if (v.tooShort) return `Debe tener al menos ${control.minLength} caracteres.`;
    if (v.patternMismatch) return control.title || "El formato no es válido.";

    return control.validationMessage;
}


// ------------------------------------------
// CÉDULA DOMINICANA
// ------------------------------------------

export function cedulaValida(cedula) {

    const n = String(cedula || "").replace(/\D/g, "");

    if (n.length !== 11) {
        return false;
    }

    let suma = 0;

    for (let i = 0; i < 10; i++) {
        let producto = Number(n[i]) * (i % 2 === 0 ? 1 : 2);
        if (producto >= 10) producto -= 9;
        suma += producto;
    }

    return (10 - (suma % 10)) % 10 === Number(n[10]);
}


// Aplica el formato 000-0000000-0 mientras se escribe y
// muestra si el dígito verificador es correcto.
export function activarMascaraCedula(input) {

    const contenedor = input.closest(".campo");
    const ayuda = contenedor.querySelector("[data-ayuda]");
    const textoOriginal = ayuda.textContent;

    const actualizar = () => {

        const n = input.value.replace(/\D/g, "").slice(0, 11);

        let texto = n;
        if (n.length > 3) texto = `${n.slice(0, 3)}-${n.slice(3)}`;
        if (n.length > 10) texto = `${n.slice(0, 3)}-${n.slice(3, 10)}-${n.slice(10)}`;

        input.value = texto;

        contenedor.classList.remove("con-error");

        if (n.length < 11) {
            ayuda.className = "campo-ayuda";
            ayuda.textContent = textoOriginal;
        } else if (cedulaValida(n)) {
            ayuda.className = "campo-exito";
            ayuda.textContent = "✓ Cédula válida";
        } else {
            ayuda.className = "campo-error";
            ayuda.textContent = "El dígito verificador no es correcto.";
        }
    };

    input.addEventListener("input", actualizar);
    input.setAttribute("inputmode", "numeric");
    input.setAttribute("maxlength", "13");
    input.setAttribute("autocomplete", "off");
}
