// ==========================================
// AveRH - Estado compartido de la aplicación
// ==========================================

import { api } from "./api.js";


// ---------- Sesión ----------

let usuario = null;

export const sesion = {

    get usuario() {
        return usuario;
    },

    establecer(datos) {
        usuario = datos;
    },

    esAdministrador() {
        return usuario?.rol === "Administrador";
    }
};


// ---------- Referencias (catálogos para formularios) ----------
// Se guardan en memoria y se invalidan al modificar un catálogo.

let referencias = null;

export async function obtenerReferencias({ forzar = false } = {}) {

    if (!referencias || forzar) {
        referencias = api.get("/referencias").catch(error => {
            referencias = null;
            throw error;
        });
    }

    return referencias;
}

export function invalidarReferencias() {
    referencias = null;
}


// Opciones para un <select> a partir de una lista.
export function opcionesDe(lista, valor, texto, { incluirInactivos = false, actual = null } = {}) {

    return lista
        .filter(item =>
            incluirInactivos ||
            !item.estado ||
            item.estado === "Activo" ||
            item.estado === "Abierta" ||
            String(item[valor]) === String(actual))
        .map(item => ({
            valor: item[valor],
            texto: typeof texto === "function" ? texto(item) : item[texto]
        }));
}
