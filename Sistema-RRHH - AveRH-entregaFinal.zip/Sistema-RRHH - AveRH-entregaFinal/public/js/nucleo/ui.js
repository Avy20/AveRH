// ==========================================
// AveRH - Componentes de interfaz
// Notificaciones, modales, confirmaciones,
// insignias y estados de carga / vacío / error.
// ==========================================

import { html, pintar } from "./html.js";
import { icono } from "./iconos.js";
import { iniciales, tono } from "./formato.js";


// ------------------------------------------
// NOTIFICACIONES
// ------------------------------------------

export function notificar(mensaje, tipo = "exito") {

    let contenedor = document.querySelector(".notificaciones");

    if (!contenedor) {
        contenedor = document.createElement("div");
        contenedor.className = "notificaciones";
        contenedor.setAttribute("aria-live", "polite");
        document.body.append(contenedor);
    }

    const nombreIcono = { exito: "check", error: "cerrar", aviso: "alerta" }[tipo] || "info";

    const elemento = document.createElement("div");
    elemento.className = `notificacion ${tipo}`;
    elemento.setAttribute("role", tipo === "error" ? "alert" : "status");

    pintar(elemento, html`
        <span class="notificacion-icono">${icono(nombreIcono)}</span>
        <span class="notificacion-texto">${mensaje}</span>
        <button class="notificacion-cerrar" type="button" aria-label="Cerrar">×</button>
    `);

    const cerrar = () => {
        elemento.classList.add("saliendo");
        setTimeout(() => elemento.remove(), 200);
    };

    elemento.querySelector("button").addEventListener("click", cerrar);
    setTimeout(cerrar, tipo === "error" ? 7000 : 4500);

    contenedor.append(elemento);

    // Como máximo cuatro notificaciones a la vez.
    [...contenedor.children].slice(0, -4).forEach(n => n.remove());
}


// ------------------------------------------
// MODAL
// abrirModal devuelve { dialogo, cerrar }.
// Los botones con data-cerrar cierran el modal.
// ------------------------------------------

export function abrirModal({ titulo, descripcion = "", contenido, acciones = "", tamano = "", alCerrar } = {}) {

    const dialogo = document.createElement("dialog");
    dialogo.className = `modal ${tamano ? `modal-${tamano}` : ""}`;
    dialogo.setAttribute("aria-labelledby", "modalTitulo");

    pintar(dialogo, html`
        <div class="modal-encabezado">
            <div>
                <h2 id="modalTitulo">${titulo}</h2>
                ${descripcion ? html`<p>${descripcion}</p>` : ""}
            </div>
            <button class="boton boton-icono" type="button" data-cerrar aria-label="Cerrar">
                ${icono("cerrar")}
            </button>
        </div>
        <div class="modal-cuerpo">${contenido}</div>
        ${acciones ? html`<div class="modal-acciones">${acciones}</div>` : ""}
    `);

    document.body.append(dialogo);

    const cerrar = () => {
        if (dialogo.open) {
            dialogo.close();
        }
    };

    dialogo.addEventListener("close", () => {
        dialogo.remove();
        alCerrar?.();
    });

    dialogo.addEventListener("click", evento => {

        if (evento.target.closest("[data-cerrar]")) {
            cerrar();
        }

        // Clic en el fondo oscuro.
        if (evento.target === dialogo) {
            cerrar();
        }
    });

    dialogo.showModal();

    // Primer campo editable, o el botón principal.
    const enfoque = dialogo.querySelector("input:not([type=hidden]):not([disabled]), select, textarea, .modal-acciones .boton-primario, .modal-acciones .boton-peligro");
    enfoque?.focus();

    return { dialogo, cerrar };
}


// ------------------------------------------
// CONFIRMACIÓN (sustituye a confirm())
// Devuelve una promesa con true / false.
// ------------------------------------------

export function confirmar({ titulo, mensaje, textoConfirmar = "Confirmar", peligro = false }) {

    return new Promise(resolve => {

        let aceptado = false;

        const { dialogo, cerrar } = abrirModal({
            titulo,
            tamano: "pequeno",
            contenido: html`
                <div class="confirmacion">
                    <span class="confirmacion-icono ${peligro ? "peligro" : ""}">
                        ${icono(peligro ? "eliminar" : "alerta")}
                    </span>
                    <p>${mensaje}</p>
                </div>
            `,
            acciones: html`
                <button class="boton boton-secundario" type="button" data-cerrar>Cancelar</button>
                <button class="boton ${peligro ? "boton-peligro" : "boton-primario"}" type="button" data-aceptar>
                    ${textoConfirmar}
                </button>
            `,
            alCerrar: () => resolve(aceptado)
        });

        dialogo.querySelector("[data-aceptar]").addEventListener("click", () => {
            aceptado = true;
            cerrar();
        });

        dialogo.querySelector("[data-aceptar]").focus();
    });
}


// ------------------------------------------
// BOTÓN EN ESPERA
// ------------------------------------------

export async function conEspera(boton, accion) {

    if (!boton) {
        return accion();
    }

    boton.disabled = true;
    boton.classList.add("cargando");

    try {
        return await accion();
    } finally {
        boton.disabled = false;
        boton.classList.remove("cargando");
    }
}


// ------------------------------------------
// FRAGMENTOS
// ------------------------------------------

export function insigniaEtapa(etapa) {
    return html`<span class="insignia" data-etapa="${etapa}">${etapa}</span>`;
}

export function insigniaEstado(estado) {

    const clase = {
        Activo: "insignia-exito",
        Abierta: "insignia-exito",
        Inactivo: "insignia-peligro",
        Cerrada: ""
    }[estado] ?? "";

    return html`<span class="insignia ${clase}">${estado}</span>`;
}

export function avatar(nombre, clase = "") {
    return html`<span class="avatar ${clase}" data-tono="${tono(nombre)}" aria-hidden="true">${iniciales(nombre)}</span>`;
}

export function persona(nombre, detalle = "", enlace = "") {

    return html`
        <div class="persona">
            ${avatar(nombre)}
            <div class="persona-datos">
                ${enlace ? html`<a href="${enlace}">${nombre}</a>` : html`<strong>${nombre}</strong>`}
                ${detalle ? html`<span>${detalle}</span>` : ""}
            </div>
        </div>
    `;
}

export function encabezado({ titulo, descripcion = "", acciones = "", volver = null }) {

    return html`
        ${volver ? html`
            <a class="volver" href="${volver.enlace}">${icono("volver")} ${volver.texto}</a>
        ` : ""}
        <header class="encabezado">
            <div>
                <h1>${titulo}</h1>
                ${descripcion ? html`<p>${descripcion}</p>` : ""}
            </div>
            ${acciones ? html`<div class="encabezado-acciones">${acciones}</div>` : ""}
        </header>
    `;
}

export function vistaCargando(texto = "Cargando información...") {

    return html`
        <div class="cargando-bloque" role="status">
            <span class="indicador-carga"></span>
            <span>${texto}</span>
        </div>
    `;
}

export function vistaVacia({ icono: nombreIcono = "vacio", titulo, texto = "", accion = "" }) {

    return html`
        <div class="vacio">
            ${icono(nombreIcono)}
            <strong>${titulo}</strong>
            ${texto ? html`<p>${texto}</p>` : ""}
            ${accion}
        </div>
    `;
}

export function vistaError(error, { titulo = "No se pudo cargar la información" } = {}) {

    return html`
        <div class="tarjeta">
            <div class="vacio">
                ${icono("alerta")}
                <strong>${titulo}</strong>
                <p>${error?.message || "Error desconocido."}</p>
                <button class="boton boton-secundario" type="button" data-accion="reintentar">
                    ${icono("actualizar")} Reintentar
                </button>
            </div>
        </div>
    `;
}

export function alerta(tipo, mensaje) {

    const nombreIcono = { error: "alerta", aviso: "alerta", exito: "check" }[tipo] || "info";

    return html`<div class="alerta alerta-${tipo}" role="${tipo === "error" ? "alert" : "status"}">${icono(nombreIcono)}<div>${mensaje}</div></div>`;
}

export function barras(filas, { porcentaje = false, color = null } = {}) {

    const maximo = Math.max(1, ...filas.map(f => f.cantidad));

    return html`
        <div class="barras">
            ${filas.map(fila => html`
                <div class="barra-fila">
                    <span title="${fila.nombre}">${fila.nombre}</span>
                    <div class="barra-pista">
                        <div class="barra-relleno" style="width:${Math.round((fila.cantidad / maximo) * 100)}%;${fila.color || color ? `background:${fila.color || color}` : ""}"></div>
                    </div>
                    <strong>${porcentaje ? `${fila.porcentaje}%` : fila.cantidad}</strong>
                </div>
            `)}
        </div>
    `;
}


// ------------------------------------------
// COMPATIBILIDAD DE IDIOMAS CON LA VACANTE
// Informativa: nunca descarta a un candidato.
// ------------------------------------------

const TEXTO_COMPATIBILIDAD = {
    cumple: "Cumple los idiomas",
    incompleto: "Idiomas sin información",
    no_cumple: "No cumple algún idioma",
    sin_requisitos: "Sin requisitos de idiomas"
};

const TEXTO_RESULTADO = {
    cumple: "Cumple",
    no_cumple: "No cumple",
    sin_informacion: "Sin información"
};

export function insigniaCompatibilidad(compatibilidad, { compacta = false } = {}) {

    if (!compatibilidad || compatibilidad.estado === "sin_requisitos") {
        return compacta ? "" : html`<span class="compatibilidad" data-estado="sin_requisitos">${TEXTO_COMPATIBILIDAD.sin_requisitos}</span>`;
    }

    const titulo = compatibilidad.detalle
        .map(d => `${d.idioma} (mín. ${d.nivel_requerido}): ${TEXTO_RESULTADO[d.resultado]}${d.nivel_candidato ? ` — tiene ${d.nivel_candidato}` : ""}`)
        .join("\n");

    return html`
        <span class="compatibilidad" data-estado="${compatibilidad.estado}" title="${titulo}">
            ${icono("idioma")}
            ${compacta
                ? `${compatibilidad.cumple}/${compatibilidad.total}`
                : `${TEXTO_COMPATIBILIDAD[compatibilidad.estado]} · ${compatibilidad.cumple}/${compatibilidad.total}`}
        </span>
    `;
}

export function resultadoIdioma(resultado) {
    return html`<span class="resultado-idioma" data-resultado="${resultado}">${TEXTO_RESULTADO[resultado]}</span>`;
}
