// ==========================================
// AveRH - Formato de datos para mostrar
// ==========================================

const MESES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
const MESES_LARGOS = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];


export function dinero(valor) {

    if (valor === null || valor === undefined || valor === "") {
        return "—";
    }

    return `RD$ ${Number(valor).toLocaleString("en-US", { maximumFractionDigits: 2 })}`;
}


export function numero(valor, decimales = 0) {

    return Number(valor || 0).toLocaleString("en-US", {
        minimumFractionDigits: 0,
        maximumFractionDigits: decimales
    });
}


// Convierte "AAAA-MM-DD" (DATE) o un ISO (DATETIME) en Date local.
export function aFecha(valor) {

    if (!valor) {
        return null;
    }

    if (valor instanceof Date) {
        return valor;
    }

    const texto = String(valor);

    if (/^\d{4}-\d{2}-\d{2}$/.test(texto)) {
        const [a, m, d] = texto.split("-").map(Number);
        return new Date(a, m - 1, d);
    }

    const fecha = new Date(texto);

    return Number.isNaN(fecha.getTime()) ? null : fecha;
}


// 08/10/2026
export function fecha(valor) {

    const f = aFecha(valor);

    if (!f) {
        return "—";
    }

    return `${String(f.getDate()).padStart(2, "0")}/${String(f.getMonth() + 1).padStart(2, "0")}/${f.getFullYear()}`;
}


// 8 oct 2026
export function fechaCorta(valor) {

    const f = aFecha(valor);

    return f ? `${f.getDate()} ${MESES[f.getMonth()]} ${f.getFullYear()}` : "—";
}


// 8 oct 2026, 14:35
export function fechaHora(valor) {

    const f = aFecha(valor);

    if (!f) {
        return "—";
    }

    return `${fechaCorta(f)}, ${String(f.getHours()).padStart(2, "0")}:${String(f.getMinutes()).padStart(2, "0")}`;
}


// "2026-10" → "octubre 2026"
export function mes(clave, corto = false) {

    const [a, m] = String(clave).split("-").map(Number);

    return corto
        ? `${MESES[m - 1]} ${String(a).slice(2)}`
        : `${MESES_LARGOS[m - 1]} ${a}`;
}


// "hace 3 días", "hoy", "ayer"
export function relativa(valor) {

    const f = aFecha(valor);

    if (!f) {
        return "—";
    }

    const ahora = new Date();
    const segundos = Math.round((ahora - f) / 1000);
    const tieneHora = !/^\d{4}-\d{2}-\d{2}$/.test(String(valor));

    if (tieneHora && segundos >= 0) {
        if (segundos < 60) return "hace un momento";
        if (segundos < 3600) return `hace ${Math.floor(segundos / 60)} min`;
        if (segundos < 86400 && f.getDate() === ahora.getDate()) return `hoy, ${String(f.getHours()).padStart(2, "0")}:${String(f.getMinutes()).padStart(2, "0")}`;
    }

    const inicioHoy = new Date(ahora.getFullYear(), ahora.getMonth(), ahora.getDate());
    const inicioFecha = new Date(f.getFullYear(), f.getMonth(), f.getDate());
    const dias = Math.round((inicioHoy - inicioFecha) / 86400000);

    if (dias === 0) return "hoy";
    if (dias === 1) return "ayer";
    if (dias > 1 && dias < 30) return `hace ${dias} días`;
    if (dias < 0 && dias > -30) return `en ${-dias} días`;

    return fechaCorta(f);
}


export function hoyISO() {

    const f = new Date();

    return `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, "0")}-${String(f.getDate()).padStart(2, "0")}`;
}


export function iniciales(nombre) {

    const palabras = String(nombre || "?").trim().split(/\s+/).filter(Boolean);

    if (palabras.length === 1) {
        return palabras[0].slice(0, 2).toUpperCase();
    }

    return (palabras[0][0] + palabras[1][0]).toUpperCase();
}


// Color estable para el avatar de cada persona (1–7).
export function tono(texto) {

    let suma = 0;

    for (const caracter of String(texto || "")) {
        suma = (suma * 31 + caracter.charCodeAt(0)) >>> 0;
    }

    return (suma % 7) + 1;
}


export function plural(cantidad, singular, pluralTexto = `${singular}s`) {
    return `${numero(cantidad)} ${Number(cantidad) === 1 ? singular : pluralTexto}`;
}


export function aniosExperiencia(valor) {

    const anios = Number(valor || 0);

    if (anios <= 0) return "Sin experiencia";
    if (anios < 1) return `${Math.max(1, Math.round(anios * 12))} meses`;

    return `${numero(anios, 1)} ${anios === 1 ? "año" : "años"}`;
}


// Quita acentos y pasa a minúsculas (para búsquedas).
export function normalizar(texto) {

    return String(texto ?? "")
        .normalize("NFD")
        .replace(/[̀-ͯ]/g, "")
        .toLowerCase();
}
