// ==========================================
// AveRH - Recarga de la vista actual
// Vuelve a pintar la pantalla con datos actualizados,
// sin mostrar el indicador de carga ni mover el scroll.
// ==========================================

export function recargarVista() {
    window.dispatchEvent(new CustomEvent("averh:recargar"));
}
