// ==========================================
// AveRH - Cliente de la API
// ==========================================

export class ErrorApi extends Error {

    constructor(mensaje, estado = 0, campo = null) {
        super(mensaje);
        this.estado = estado;
        this.campo = campo;
    }
}


// Recuerda la pantalla actual para volver a ella tras iniciar sesión.
export function irAlLogin() {

    try {
        if (location.hash && location.hash !== "#/") {
            sessionStorage.setItem("averh_volver", location.hash);
        }
    } catch {
        // El almacenamiento puede no estar disponible.
    }

    location.replace("/login.html");
}


async function peticion(metodo, ruta, cuerpo) {

    let respuesta;

    try {

        respuesta = await fetch(`/api${ruta}`, {
            method: metodo,
            credentials: "same-origin",
            headers: {
                "Accept": "application/json",
                ...(metodo === "GET" ? {} : { "Content-Type": "application/json" })
            },
            body: metodo === "GET" ? undefined : JSON.stringify(cuerpo ?? {})
        });

    } catch {

        throw new ErrorApi(
            "No se pudo conectar con el servidor de AveRH. Comprueba que esté en marcha."
        );
    }

    let datos = null;

    try {
        datos = await respuesta.json();
    } catch {
        datos = null;
    }

    if (respuesta.status === 401 && !ruta.startsWith("/auth/")) {
        irAlLogin();
    }

    if (!respuesta.ok || !datos?.correcto) {
        throw new ErrorApi(
            datos?.mensaje || "Ocurrió un error inesperado. Inténtalo de nuevo.",
            respuesta.status,
            datos?.campo || null
        );
    }

    return datos;
}


// Las lecturas devuelven directamente los datos;
// las modificaciones devuelven { datos, mensaje }.
export const api = {
    get: async ruta => (await peticion("GET", ruta)).datos,
    post: (ruta, cuerpo) => peticion("POST", ruta, cuerpo),
    put: (ruta, cuerpo) => peticion("PUT", ruta, cuerpo),
    patch: (ruta, cuerpo) => peticion("PATCH", ruta, cuerpo),
    eliminar: ruta => peticion("DELETE", ruta)
};


// Construye "?a=1&b=2" omitiendo valores vacíos.
export function parametros(objeto) {

    const busqueda = new URLSearchParams();

    for (const [clave, valor] of Object.entries(objeto)) {

        if (valor === undefined || valor === null || valor === "") continue;
        if (Array.isArray(valor) && valor.length === 0) continue;

        busqueda.set(clave, Array.isArray(valor) ? valor.join(",") : valor);
    }

    const texto = busqueda.toString();

    return texto ? `?${texto}` : "";
}
