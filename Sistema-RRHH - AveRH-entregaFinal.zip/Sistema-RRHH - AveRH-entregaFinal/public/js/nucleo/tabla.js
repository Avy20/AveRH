// ==========================================
// AveRH - Tabla de datos
//
// crearTabla(contenedor, {
//   columnas: [{ clave, titulo, ordenable, clase, mostrar(fila) }],
//   filas, buscarEn(fila) → texto, filtros: [{ clave, etiqueta, opciones, aplicar(fila, valor) }],
//   porPagina, vacio: { titulo, texto }, acciones (HTML a la derecha)
// })
// ==========================================

import { html, pintar } from "./html.js";
import { icono } from "./iconos.js";
import { normalizar, plural } from "./formato.js";
import { vistaVacia } from "./ui.js";


export function crearTabla(contenedor, opciones) {

    const {
        columnas,
        buscarEn = null,
        placeholder = "Buscar...",
        filtros = [],
        porPagina = 12,
        vacio = { titulo: "No hay registros", texto: "" },
        acciones = "",
        claseFila = () => "",
        nombreRegistro = ["registro", "registros"]
    } = opciones;

    const estado = {
        filas: opciones.filas || [],
        busqueda: "",
        filtros: Object.fromEntries(filtros.map(f => [f.clave, f.inicial ?? ""])),
        orden: opciones.ordenInicial || null,
        pagina: 1
    };


    pintar(contenedor, html`
        ${buscarEn || filtros.length || acciones ? html`
            <div class="herramientas">
                ${buscarEn ? html`
                    <label class="buscador">
                        <span class="solo-lectores">Buscar</span>
                        ${icono("buscar")}
                        <input class="control" type="search" placeholder="${placeholder}" data-busqueda>
                    </label>
                ` : ""}
                ${filtros.map(f => html`
                    <label>
                        <span class="solo-lectores">${f.etiqueta}</span>
                        <select class="control" data-filtro="${f.clave}">
                            <option value="">${f.etiqueta}</option>
                            ${f.opciones.map(op => html`
                                <option value="${op.valor ?? op}" ${String(op.valor ?? op) === String(estado.filtros[f.clave]) ? "selected" : ""}>${op.texto ?? op}</option>
                            `)}
                        </select>
                    </label>
                `)}
                <div class="herramientas-fin">
                    <span data-contador></span>
                    ${acciones}
                </div>
            </div>
        ` : ""}
        <div class="tabla-contenedor" data-cuerpo></div>
        <div class="paginacion" data-paginacion hidden></div>
    `);

    const cuerpo = contenedor.querySelector("[data-cuerpo]");
    const paginacion = contenedor.querySelector("[data-paginacion]");
    const contador = contenedor.querySelector("[data-contador]");


    function filasVisibles() {

        let filas = estado.filas;

        if (buscarEn && estado.busqueda) {
            const termino = normalizar(estado.busqueda);
            filas = filas.filter(fila => normalizar(buscarEn(fila)).includes(termino));
        }

        for (const filtro of filtros) {
            const valor = estado.filtros[filtro.clave];
            if (valor !== "") {
                filas = filas.filter(fila => filtro.aplicar(fila, valor));
            }
        }

        if (estado.orden) {

            const { clave, direccion } = estado.orden;
            const columna = columnas.find(c => c.clave === clave);
            const valorDe = columna?.valorOrden || (fila => fila[clave]);

            filas = [...filas].sort((a, b) => {

                const x = valorDe(a);
                const y = valorDe(b);

                if (x === y) return 0;
                if (x === null || x === undefined) return 1;
                if (y === null || y === undefined) return -1;

                const comparacion = typeof x === "number" && typeof y === "number"
                    ? x - y
                    : String(x).localeCompare(String(y), "es", { numeric: true, sensitivity: "base" });

                return direccion === "asc" ? comparacion : -comparacion;
            });
        }

        return filas;
    }


    function dibujar() {

        const filas = filasVisibles();
        const totalPaginas = Math.max(1, Math.ceil(filas.length / porPagina));

        estado.pagina = Math.min(estado.pagina, totalPaginas);

        const inicio = (estado.pagina - 1) * porPagina;
        const pagina = filas.slice(inicio, inicio + porPagina);

        if (contador) {
            contador.textContent = plural(filas.length, nombreRegistro[0], nombreRegistro[1]);
        }

        if (filas.length === 0) {

            const hayFiltros = estado.busqueda || Object.values(estado.filtros).some(v => v !== "");

            pintar(cuerpo, vistaVacia(hayFiltros
                ? { icono: "buscar", titulo: "Sin coincidencias", texto: "Prueba con otra búsqueda o quita los filtros." }
                : vacio));

            paginacion.hidden = true;
            return;
        }

        pintar(cuerpo, html`
            <table class="tabla">
                <thead>
                    <tr>
                        ${columnas.map(c => {

                            const ordenada = estado.orden?.clave === c.clave;
                            const flecha = ordenada ? (estado.orden.direccion === "asc" ? "▲" : "▼") : "↕";

                            return html`
                                <th scope="col" class="${c.clase || ""} ${c.ordenable ? "ordenable" : ""}"
                                    ${c.ordenable ? html`data-ordenar="${c.clave}" tabindex="0"` : ""}
                                    ${ordenada ? html`aria-sort="${estado.orden.direccion === "asc" ? "ascending" : "descending"}"` : ""}>
                                    ${c.titulo}${c.ordenable ? html`<span class="flecha" aria-hidden="true">${flecha}</span>` : ""}
                                </th>
                            `;
                        })}
                    </tr>
                </thead>
                <tbody>
                    ${pagina.map(fila => html`
                        <tr class="${claseFila(fila)}">
                            ${columnas.map(c => html`
                                <td class="${c.clase || ""}">${c.mostrar ? c.mostrar(fila) : (fila[c.clave] ?? "—")}</td>
                            `)}
                        </tr>
                    `)}
                </tbody>
            </table>
        `);

        paginacion.hidden = totalPaginas <= 1;

        if (totalPaginas > 1) {
            pintar(paginacion, html`
                <span>Mostrando ${inicio + 1}–${inicio + pagina.length} de ${filas.length}</span>
                <div class="paginacion-botones">
                    <button class="boton boton-secundario boton-pequeno" type="button" data-pagina="-1" ${estado.pagina === 1 ? "disabled" : ""}>
                        ${icono("anterior")} Anterior
                    </button>
                    <button class="boton boton-secundario boton-pequeno" type="button" data-pagina="1" ${estado.pagina === totalPaginas ? "disabled" : ""}>
                        Siguiente ${icono("siguiente")}
                    </button>
                </div>
            `);
        }
    }


    // ---------- Eventos ----------

    contenedor.querySelector("[data-busqueda]")?.addEventListener("input", evento => {
        estado.busqueda = evento.target.value;
        estado.pagina = 1;
        dibujar();
    });

    contenedor.querySelectorAll("[data-filtro]").forEach(select => {
        select.addEventListener("change", () => {
            estado.filtros[select.dataset.filtro] = select.value;
            estado.pagina = 1;
            dibujar();
        });
    });

    const ordenar = th => {

        const clave = th.dataset.ordenar;

        estado.orden = estado.orden?.clave === clave && estado.orden.direccion === "asc"
            ? { clave, direccion: "desc" }
            : { clave, direccion: "asc" };

        dibujar();
    };

    cuerpo.addEventListener("click", evento => {
        const th = evento.target.closest("[data-ordenar]");
        if (th) ordenar(th);
    });

    cuerpo.addEventListener("keydown", evento => {
        const th = evento.target.closest("[data-ordenar]");
        if (th && (evento.key === "Enter" || evento.key === " ")) {
            evento.preventDefault();
            ordenar(th);
        }
    });

    paginacion.addEventListener("click", evento => {
        const boton = evento.target.closest("[data-pagina]");
        if (boton) {
            estado.pagina += Number(boton.dataset.pagina);
            dibujar();
        }
    });

    dibujar();


    return {
        actualizar(filas) {
            estado.filas = filas;
            dibujar();
        },
        filasVisibles
    };
}


// ------------------------------------------
// EXPORTAR A EXCEL (.xlsx)
// El servidor genera un archivo nativo de Excel con las filas
// indicadas (las que el usuario ve, con sus filtros).
//
// hojas: [{ nombre, columnas: [{ titulo, valor(fila), tipo, ancho, total }], filas }]
// tipo: texto | fecha | dinero | entero | decimal | porcentaje
// ------------------------------------------

export async function exportarExcel({ titulo, subtitulo = "", archivo, hojas }) {

    const cuerpo = {
        titulo,
        subtitulo,
        archivo,
        hojas: hojas.map(hoja => ({
            nombre: hoja.nombre,
            columnas: hoja.columnas.map(({ titulo: t, tipo, ancho, total }) => ({ titulo: t, tipo, ancho, total })),
            filas: hoja.filas.map(fila => hoja.columnas.map(c => {
                const valor = c.valor(fila);
                return valor === undefined || valor === "" ? null : (typeof valor === "number" ? valor : String(valor));
            }))
        }))
    };

    let respuesta;

    try {
        respuesta = await fetch("/api/exportaciones/excel", {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(cuerpo)
        });
    } catch {
        throw new Error("No se pudo conectar con el servidor para generar el Excel.");
    }

    if (!respuesta.ok) {
        const datos = await respuesta.json().catch(() => null);
        throw new Error(datos?.mensaje || "No se pudo generar el archivo de Excel.");
    }

    const nombre = /filename="([^"]+)"/.exec(respuesta.headers.get("Content-Disposition") || "")?.[1] || "averh.xlsx";
    const archivoExcel = await respuesta.blob();
    const enlace = document.createElement("a");

    enlace.href = URL.createObjectURL(archivoExcel);
    enlace.download = nombre;
    document.body.append(enlace);
    enlace.click();
    enlace.remove();

    setTimeout(() => URL.revokeObjectURL(enlace.href), 2000);

    return nombre;
}
