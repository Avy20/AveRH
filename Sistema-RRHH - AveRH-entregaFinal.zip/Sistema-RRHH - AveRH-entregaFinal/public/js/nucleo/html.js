// ==========================================
// AveRH - Plantillas HTML seguras
//
// html`<p>${valor}</p>` escapa automáticamente cada valor
// interpolado, así los datos de MySQL nunca se interpretan
// como HTML. Las plantillas anidadas y las listas se
// insertan tal cual porque ya fueron escapadas.
// ==========================================

class HtmlSeguro {

    constructor(texto) {
        this.texto = texto;
    }

    toString() {
        return this.texto;
    }
}


const ENTIDADES = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
    "`": "&#96;"
};

export function escapar(valor) {
    return String(valor).replace(/[&<>"'`]/g, caracter => ENTIDADES[caracter]);
}


function convertir(valor) {

    if (valor === null || valor === undefined || valor === false) {
        return "";
    }

    if (valor instanceof HtmlSeguro) {
        return valor.texto;
    }

    if (Array.isArray(valor)) {
        return valor.map(convertir).join("");
    }

    return escapar(valor);
}


export function html(partes, ...valores) {

    let resultado = partes[0];

    valores.forEach((valor, i) => {
        resultado += convertir(valor) + partes[i + 1];
    });

    return new HtmlSeguro(resultado);
}


// Solo para HTML generado por AveRH (por ejemplo, iconos SVG).
export function crudo(texto) {
    return new HtmlSeguro(texto);
}


export function pintar(elemento, contenido) {
    elemento.innerHTML = convertir(contenido);
    return elemento;
}
