// ==========================================
// AveRH - Aplicación principal
// Sesión, menú lateral y navegación por rutas (#/ruta).
// ==========================================

import { api, irAlLogin } from "./nucleo/api.js";
import { html, pintar } from "./nucleo/html.js";
import { icono } from "./nucleo/iconos.js";
import { sesion } from "./nucleo/estado.js";
import { avatar, vistaCargando, vistaError } from "./nucleo/ui.js";

import { vistaPanel } from "./modulos/panel.js";
import { vistaCandidatos, vistaFormularioCandidato, vistaPerfilCandidato, vistaEditorPerfil } from "./modulos/candidatos.js";
import { vistaProceso } from "./modulos/proceso.js";
import { vistaEmpleados } from "./modulos/empleados.js";
import { vistaExperiencia } from "./modulos/experiencia.js";
import { vistaConsulta } from "./modulos/consulta.js";
import { vistaReportes } from "./modulos/reportes.js";
import { vistaCatalogo } from "./modulos/catalogos.js";
import { vistaUsuarios } from "./modulos/usuarios.js";


// AveRH se sirve desde Node: si se abre con Live Server o
// como archivo, se redirige al servidor.
if (location.protocol === "file:" || location.port === "5500") {
    location.replace("http://localhost:3000/");
}


// ------------------------------------------
// MENÚ
// ------------------------------------------

const MENU = [
    { grupo: "General" },
    { ruta: "/panel", texto: "Panel principal", icono: "panel" },

    { grupo: "Reclutamiento" },
    { ruta: "/vacantes", texto: "Vacantes", icono: "vacante" },
    { ruta: "/candidatos", texto: "Candidatos", icono: "candidatos" },
    { ruta: "/proceso", texto: "Proceso de selección", icono: "proceso" },
    { ruta: "/experiencia", texto: "Experiencia laboral", icono: "experiencia" },

    { grupo: "Personal" },
    { ruta: "/empleados", texto: "Empleados", icono: "empleado" },

    { grupo: "Análisis" },
    { ruta: "/consulta", texto: "Consulta por criterios", icono: "buscar" },
    { ruta: "/reportes", texto: "Reportes", icono: "reporte" },

    { grupo: "Catálogos" },
    { ruta: "/puestos", texto: "Puestos", icono: "puesto" },
    { ruta: "/departamentos", texto: "Departamentos", icono: "departamento" },
    { ruta: "/competencias", texto: "Competencias", icono: "competencia" },
    { ruta: "/idiomas", texto: "Idiomas", icono: "idioma" },
    { ruta: "/capacitaciones", texto: "Capacitaciones", icono: "capacitacion" },

    { grupo: "Administración", admin: true },
    { ruta: "/usuarios", texto: "Usuarios", icono: "seguridad", admin: true }
];


// ------------------------------------------
// RUTAS
// ------------------------------------------

const RUTAS = [
    { patron: /^\/panel$/, vista: vistaPanel, titulo: "Panel principal", menu: "/panel" },
    { patron: /^\/candidatos$/, vista: vistaCandidatos, titulo: "Candidatos", menu: "/candidatos" },
    { patron: /^\/candidatos\/nuevo$/, vista: vistaFormularioCandidato, titulo: "Nuevo candidato", menu: "/candidatos" },
    { patron: /^\/candidatos\/(\d+)$/, vista: vistaPerfilCandidato, titulo: "Perfil del candidato", menu: "/candidatos" },
    { patron: /^\/candidatos\/(\d+)\/editar$/, vista: vistaFormularioCandidato, titulo: "Editar candidato", menu: "/candidatos" },
    { patron: /^\/candidatos\/(\d+)\/perfil$/, vista: vistaEditorPerfil, titulo: "Perfil profesional", menu: "/candidatos" },
    { patron: /^\/proceso$/, vista: vistaProceso, titulo: "Proceso de selección", menu: "/proceso" },
    { patron: /^\/experiencia$/, vista: vistaExperiencia, titulo: "Experiencia laboral", menu: "/experiencia" },
    { patron: /^\/empleados$/, vista: vistaEmpleados, titulo: "Empleados", menu: "/empleados" },
    { patron: /^\/consulta$/, vista: vistaConsulta, titulo: "Consulta por criterios", menu: "/consulta" },
    { patron: /^\/reportes(?:\/(ingresos|seleccion))?$/, vista: vistaReportes, titulo: "Reportes", menu: "/reportes" },
    { patron: /^\/(vacantes|puestos|departamentos|competencias|idiomas|capacitaciones)$/, vista: vistaCatalogo, titulo: null, menu: null },
    { patron: /^\/usuarios$/, vista: vistaUsuarios, titulo: "Usuarios", menu: "/usuarios", admin: true }
];


// ------------------------------------------
// ESTRUCTURA
// ------------------------------------------

function pintarMenu() {

    const esAdmin = sesion.esAdministrador();

    pintar(document.getElementById("navegacion"), html`
        ${MENU.filter(item => !item.admin || esAdmin).map(item => item.grupo
            ? html`<p class="nav-grupo">${item.grupo}</p>`
            : html`<a class="nav-enlace" href="#${item.ruta}" data-ruta="${item.ruta}">${icono(item.icono)}<span>${item.texto}</span></a>`
        )}
    `);

    const u = sesion.usuario;

    pintar(document.getElementById("usuarioActual"), html`
        <div class="usuario-datos">
            <strong>${u.nombre}</strong>
            <span>${u.rol}</span>
        </div>
        ${avatar(u.nombre)}
    `);
}


function marcarMenu(rutaMenu) {

    document.querySelectorAll(".nav-enlace").forEach(enlace => {
        const activo = enlace.dataset.ruta === rutaMenu;
        enlace.classList.toggle("activo", activo);
        enlace.toggleAttribute("aria-current", activo);
    });
}


function tituloDeRuta(ruta, coincidencia) {

    if (ruta.titulo) {
        return ruta.titulo;
    }

    return MENU.find(item => item.ruta === `/${coincidencia[1]}`)?.texto || "AveRH";
}


// ------------------------------------------
// NAVEGACIÓN
// ------------------------------------------

let limpiezaVistaActual = null;
let navegacionActual = 0;

async function navegar({ recarga = false } = {}) {

    const ruta = (location.hash.replace(/^#/, "") || "/panel").split("?")[0];
    const contenido = document.getElementById("contenido");

    let destino = null;
    let coincidencia = null;

    for (const r of RUTAS) {
        coincidencia = ruta.match(r.patron);
        if (coincidencia) {
            destino = r;
            break;
        }
    }

    if (!destino || (destino.admin && !sesion.esAdministrador())) {
        location.replace("#/panel");
        return;
    }

    // Una vista puede devolver una función de limpieza
    // (por ejemplo, para quitar escuchas globales).
    if (typeof limpiezaVistaActual === "function") {
        limpiezaVistaActual();
    }

    limpiezaVistaActual = null;

    const id = ++navegacionActual;
    const titulo = tituloDeRuta(destino, coincidencia);

    document.title = `${titulo} · AveRH`;
    document.getElementById("tituloPagina").textContent = titulo;
    marcarMenu(destino.menu || ruta);
    document.body.classList.remove("menu-abierto");

    // Cada vista recibe un contenedor nuevo: sus escuchas de
    // eventos desaparecen con él al cambiar de pantalla.
    // En una recarga se pinta fuera de la página y se sustituye
    // al terminar, sin parpadeo ni salto de scroll.
    const vista = document.createElement("div");
    vista.className = recarga ? "vista sin-animacion" : "vista";

    if (!recarga) {
        contenido.replaceChildren(vista);
        pintar(vista, vistaCargando());
        window.scrollTo({ top: 0 });
    }

    try {

        const limpieza = await destino.vista(vista, coincidencia.slice(1), {
            esVigente: () => id === navegacionActual
        });

        if (id === navegacionActual) {
            limpiezaVistaActual = limpieza;
            if (recarga) contenido.replaceChildren(vista);
        }

    } catch (error) {

        console.error(error);

        if (id === navegacionActual) {
            contenido.replaceChildren(vista);
            pintar(vista, vistaError(error));
            vista.querySelector("[data-accion=reintentar]")?.addEventListener("click", () => navegar());
        }
    }
}


// ------------------------------------------
// INICIO
// ------------------------------------------

async function iniciar() {

    let usuario;

    try {
        usuario = await api.get("/auth/me");
    } catch {
        irAlLogin();
        return;
    }

    sesion.establecer(usuario);
    pintarMenu();

    document.getElementById("botonSalir").addEventListener("click", async () => {
        try {
            await api.post("/auth/logout");
        } finally {
            location.replace("/login.html");
        }
    });

    document.getElementById("botonMenu").addEventListener("click", () => {
        document.body.classList.toggle("menu-abierto");
    });

    document.querySelector(".fondo-menu").addEventListener("click", () => {
        document.body.classList.remove("menu-abierto");
    });

    window.addEventListener("hashchange", () => navegar());
    window.addEventListener("averh:recargar", () => navegar({ recarga: true }));

    document.body.classList.remove("sesion-pendiente");

    // replaceState no dispara "hashchange": se navega una sola vez.
    if (!location.hash || location.hash === "#/") {
        history.replaceState(null, "", "#/panel");
    }

    await navegar();
}


iniciar();
