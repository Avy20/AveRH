// ==========================================
// AveRH - Validación de datos
//
// Cada ruta describe sus campos con un esquema:
//   { nombre: { tipo: "texto", requerido: true, max: 150, etiqueta: "Nombre" } }
// validar() devuelve los datos limpios o lanza un
// error 400 con el campo que falló.
// ==========================================

const { solicitudInvalida } = require("./errores");

const CORREO_VALIDO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const FECHA_VALIDA = /^\d{4}-\d{2}-\d{2}$/;
const TELEFONO_VALIDO = /^[0-9+()\-\s]{7,20}$/;

// Nombres de persona: letras (con acentos), espacios, apóstrofos, puntos y guiones.
const NOMBRE_PERSONA = /^[A-Za-zÀ-ÖØ-öø-ÿ' .-]+$/;


// Cédula dominicana: 11 dígitos con dígito verificador (algoritmo de Luhn).
function cedulaDominicanaValida(cedula) {

    const numeros = String(cedula || "").replace(/\D/g, "");

    if (numeros.length !== 11) {
        return false;
    }

    let suma = 0;

    for (let i = 0; i < 10; i++) {

        let producto = Number(numeros[i]) * (i % 2 === 0 ? 1 : 2);

        if (producto >= 10) {
            producto -= 9;
        }

        suma += producto;
    }

    return (10 - (suma % 10)) % 10 === Number(numeros[10]);
}


// Formato 000-0000000-0
function formatearCedula(cedula) {

    const n = String(cedula || "").replace(/\D/g, "");

    return `${n.slice(0, 3)}-${n.slice(3, 10)}-${n.slice(10, 11)}`;
}


function fechaValida(texto) {

    if (!FECHA_VALIDA.test(texto)) {
        return false;
    }

    const fecha = new Date(`${texto}T00:00:00Z`);

    return !Number.isNaN(fecha.getTime()) &&
        fecha.toISOString().slice(0, 10) === texto;
}


function hoyISO() {

    const hoy = new Date();

    const mes = String(hoy.getMonth() + 1).padStart(2, "0");
    const dia = String(hoy.getDate()).padStart(2, "0");

    return `${hoy.getFullYear()}-${mes}-${dia}`;
}


function validarCampo(nombre, regla, valorOriginal) {

    const etiqueta = regla.etiqueta || nombre;

    let valor = valorOriginal;

    // Las contraseñas se conservan exactamente como se escribieron.
    if (typeof valor === "string" && regla.tipo !== "secreto") {
        valor = valor.trim();
    }

    const vacio =
        valor === undefined ||
        valor === null ||
        valor === "";

    if (vacio) {

        if (regla.requerido) {
            const obligatorio = /^La\b/.test(etiqueta) ? "obligatoria" : "obligatorio";
            throw solicitudInvalida(`${etiqueta} es ${obligatorio}.`, nombre);
        }

        return regla.porDefecto !== undefined ? regla.porDefecto : null;
    }

    switch (regla.tipo) {

        case "texto": {

            valor = String(valor).replace(/\s+/g, " ");

            if (regla.min && valor.length < regla.min) {
                throw solicitudInvalida(`${etiqueta} debe tener al menos ${regla.min} caracteres.`, nombre);
            }

            if (regla.max && valor.length > regla.max) {
                throw solicitudInvalida(`${etiqueta} no puede superar ${regla.max} caracteres.`, nombre);
            }

            if (regla.patron && !regla.patron.test(valor)) {
                throw solicitudInvalida(`${etiqueta} ${regla.mensajePatron || "no tiene un formato válido."}`, nombre);
            }

            return valor;
        }

        case "secreto": {

            valor = String(valor);

            if (regla.min && valor.length < regla.min) {
                throw solicitudInvalida(`${etiqueta} debe tener al menos ${regla.min} caracteres.`, nombre);
            }

            // bcrypt solo utiliza los primeros 72 bytes.
            if (Buffer.byteLength(valor, "utf8") > (regla.max || 72)) {
                throw solicitudInvalida(`${etiqueta} es demasiado larga.`, nombre);
            }

            return valor;
        }

        case "correo": {

            valor = String(valor).toLowerCase();

            if (!CORREO_VALIDO.test(valor) || valor.length > (regla.max || 150)) {
                throw solicitudInvalida(`${etiqueta} no es un correo electrónico válido.`, nombre);
            }

            return valor;
        }

        case "telefono": {

            valor = String(valor);

            if (!TELEFONO_VALIDO.test(valor)) {
                throw solicitudInvalida(`${etiqueta} no es un teléfono válido.`, nombre);
            }

            return valor;
        }

        case "cedula": {

            if (!cedulaDominicanaValida(valor)) {
                throw solicitudInvalida(`${etiqueta} no es una cédula dominicana válida.`, nombre);
            }

            return formatearCedula(valor);
        }

        case "entero":
        case "decimal": {

            const numero = Number(valor);

            const valido =
                Number.isFinite(numero) &&
                (regla.tipo === "decimal" || Number.isInteger(numero));

            if (!valido) {
                throw solicitudInvalida(`${etiqueta} debe ser un número válido.`, nombre);
            }

            if (regla.min !== undefined && numero < regla.min) {
                throw solicitudInvalida(`${etiqueta} no puede ser menor que ${regla.min}.`, nombre);
            }

            if (regla.max !== undefined && numero > regla.max) {
                throw solicitudInvalida(`${etiqueta} no puede ser mayor que ${regla.max}.`, nombre);
            }

            return regla.tipo === "decimal"
                ? Math.round(numero * 100) / 100
                : numero;
        }

        case "fecha": {

            valor = String(valor).slice(0, 10);

            if (!fechaValida(valor)) {
                throw solicitudInvalida(`${etiqueta} no es una fecha válida.`, nombre);
            }

            if (regla.noFutura && valor > hoyISO()) {
                throw solicitudInvalida(`${etiqueta} no puede ser una fecha futura.`, nombre);
            }

            return valor;
        }

        case "opcion": {

            if (!regla.valores.includes(valor)) {
                throw solicitudInvalida(`${etiqueta} no es un valor permitido.`, nombre);
            }

            return valor;
        }

        default:
            throw new Error(`Tipo de validación desconocido: ${regla.tipo}`);
    }
}


// Valida "datos" según "esquema". Con parcial = true solo
// se validan los campos presentes (para actualizaciones).
function validar(datos, esquema, { parcial = false } = {}) {

    const entrada = datos && typeof datos === "object" ? datos : {};
    const limpio = {};

    for (const [nombre, regla] of Object.entries(esquema)) {

        if (parcial && !(nombre in entrada)) {
            continue;
        }

        limpio[nombre] = validarCampo(nombre, regla, entrada[nombre]);
    }

    return limpio;
}


// Valida un identificador numérico de la URL.
function validarId(valor, etiqueta = "El identificador") {

    const id = Number(valor);

    if (!Number.isInteger(id) || id < 1) {
        throw solicitudInvalida(`${etiqueta} no es válido.`);
    }

    return id;
}


module.exports = {
    validar,
    validarId,
    cedulaDominicanaValida,
    formatearCedula,
    fechaValida,
    hoyISO,
    CORREO_VALIDO,
    NOMBRE_PERSONA
};
