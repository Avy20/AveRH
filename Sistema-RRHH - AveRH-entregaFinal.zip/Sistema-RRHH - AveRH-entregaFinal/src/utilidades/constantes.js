// ==========================================
// AveRH - Valores permitidos del dominio
// ==========================================

// Etapas del proceso de selección, en orden.
const ETAPAS = [
    "Postulado",
    "Entrevista",
    "Evaluación",
    "Oferta",
    "Contratado",
    "Descartado"
];

// Etapas que cierran el proceso.
const ETAPAS_FINALES = ["Contratado", "Descartado"];

const ROLES = ["Administrador", "Recursos Humanos"];

const ESTADOS = ["Activo", "Inactivo"];

const ESTADOS_VACANTE = ["Abierta", "Cerrada"];

const NIVELES_CAPACITACION = [
    "Técnico",
    "Grado",
    "Post-grado",
    "Maestría",
    "Doctorado",
    "Gestión"
];

const NIVELES_IDIOMA = ["Básico", "Intermedio", "Avanzado", "Nativo"];

const NIVELES_RIESGO = ["Bajo", "Medio", "Alto"];

const FUENTES_RECLUTAMIENTO = [
    "AveRH",
    "Referido",
    "LinkedIn",
    "Computrabajo",
    "Aldaba",
    "Universidad",
    "Feria de empleo",
    "Redes sociales",
    "Página web corporativa",
    "Agencia de reclutamiento"
];


module.exports = {
    ETAPAS,
    ETAPAS_FINALES,
    ROLES,
    ESTADOS,
    ESTADOS_VACANTE,
    NIVELES_CAPACITACION,
    NIVELES_IDIOMA,
    NIVELES_RIESGO,
    FUENTES_RECLUTAMIENTO
};
