// ==========================================
// AveRH - Errores HTTP
// ==========================================

// Error con código HTTP y mensaje pensado para el usuario.
// "campo" indica qué campo del formulario provocó el error.
class ErrorHttp extends Error {

    constructor(estado, mensaje, campo = null) {
        super(mensaje);
        this.estado = estado;
        this.campo = campo;
    }
}

const noEncontrado = (mensaje = "El registro no existe.") =>
    new ErrorHttp(404, mensaje);

const solicitudInvalida = (mensaje, campo = null) =>
    new ErrorHttp(400, mensaje, campo);

const conflicto = (mensaje, campo = null) =>
    new ErrorHttp(409, mensaje, campo);


// Traduce errores de MySQL a mensajes comprensibles.
function traducirErrorMySQL(error) {

    switch (error.code) {

        case "ER_DUP_ENTRY":
            return conflicto("Ya existe un registro con esos datos.");

        case "ER_ROW_IS_REFERENCED":
        case "ER_ROW_IS_REFERENCED_2":
            return conflicto(
                "No se puede eliminar porque está en uso en otros registros. Puedes desactivarlo en su lugar."
            );

        case "ER_NO_REFERENCED_ROW":
        case "ER_NO_REFERENCED_ROW_2":
            return solicitudInvalida("Uno de los datos seleccionados no existe.");

        case "ER_CHECK_CONSTRAINT_VIOLATED":
            return solicitudInvalida("Uno de los valores no es válido.");

        case "ER_DATA_TOO_LONG":
            return solicitudInvalida("Uno de los campos supera la longitud permitida.");

        default:
            return null;
    }
}


// Middleware final de errores: siempre responde JSON.
function manejadorErrores(error, req, res, next) {

    if (res.headersSent) {
        return next(error);
    }

    // JSON mal formado en el cuerpo de la petición.
    if (error.type === "entity.parse.failed") {
        return res.status(400).json({
            correcto: false,
            mensaje: "La petición no tiene un formato válido."
        });
    }

    const errorConocido =
        error instanceof ErrorHttp
            ? error
            : traducirErrorMySQL(error);

    if (errorConocido) {
        return res.status(errorConocido.estado).json({
            correcto: false,
            mensaje: errorConocido.message,
            campo: errorConocido.campo || undefined
        });
    }

    console.error(`[${new Date().toISOString()}] Error en ${req.method} ${req.originalUrl}:`, error);

    res.status(500).json({
        correcto: false,
        mensaje: "Ocurrió un error inesperado en el servidor. Inténtalo de nuevo."
    });
}


module.exports = {
    ErrorHttp,
    noEncontrado,
    solicitudInvalida,
    conflicto,
    manejadorErrores
};
