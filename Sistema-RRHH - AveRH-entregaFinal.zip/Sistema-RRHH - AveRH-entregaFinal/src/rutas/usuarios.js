// ==========================================
// AveRH - Administración de usuarios
// Solo para administradores. Las contraseñas se
// guardan con bcrypt y nunca se devuelven.
// ==========================================

const express = require("express");
const bcrypt = require("bcryptjs");

const { consultar } = require("../db");
const { validar, validarId } = require("../utilidades/validacion");
const { noEncontrado, solicitudInvalida, conflicto } = require("../utilidades/errores");
const { ROLES, ESTADOS } = require("../utilidades/constantes");
const { soloAdministrador } = require("../middleware/seguridad");
const { COSTE_BCRYPT } = require("./auth");

const router = express.Router();

router.use(soloAdministrador);


const ESQUEMA = {
    nombre: { tipo: "texto", requerido: true, min: 3, max: 150, etiqueta: "El nombre" },
    correo: { tipo: "correo", requerido: true, etiqueta: "El correo" },
    rol: { tipo: "opcion", requerido: true, valores: ROLES, etiqueta: "El rol" }
};

const ESQUEMA_CONTRASENA = {
    contrasena: { tipo: "secreto", min: 8, max: 72, etiqueta: "La contraseña" }
};


async function obtenerUsuario(id) {

    const [usuario] = await consultar(
        "SELECT id_usuario, rol, estado FROM usuarios WHERE id_usuario = ?",
        [id]
    );

    if (!usuario) {
        throw noEncontrado("El usuario no existe.");
    }

    return usuario;
}


// Cuántos administradores activos hay sin contar al indicado.
async function otrosAdministradoresActivos(id) {

    const [{ cantidad }] = await consultar(
        `SELECT COUNT(*) AS cantidad FROM usuarios
         WHERE rol = 'Administrador' AND estado = 'Activo' AND id_usuario <> ?`,
        [id]
    );

    return Number(cantidad);
}


async function correoEnUso(correo, idExcluido = 0) {

    const filas = await consultar(
        "SELECT 1 FROM usuarios WHERE correo = ? AND id_usuario <> ?",
        [correo, idExcluido]
    );

    return filas.length > 0;
}


router.get("/", async (req, res) => {

    const usuarios = await consultar(`
        SELECT id_usuario AS id, nombre, correo, rol, estado, fecha_creacion
        FROM usuarios
        ORDER BY estado ASC, nombre ASC
    `);

    res.json({ correcto: true, datos: usuarios });
});


router.post("/", async (req, res) => {

    const datos = validar(req.body, ESQUEMA);
    const { contrasena } = validar(req.body, {
        contrasena: { ...ESQUEMA_CONTRASENA.contrasena, requerido: true }
    });

    if (await correoEnUso(datos.correo)) {
        throw conflicto("Ese correo electrónico ya está registrado.", "correo");
    }

    const hash = await bcrypt.hash(contrasena, COSTE_BCRYPT);

    const resultado = await consultar(
        `INSERT INTO usuarios (nombre, correo, contrasena, rol, estado)
         VALUES (?, ?, ?, ?, 'Activo')`,
        [datos.nombre, datos.correo, hash, datos.rol]
    );

    console.log(`Usuario creado por ${req.usuario.correo}: ${datos.correo} (${datos.rol})`);

    res.status(201).json({
        correcto: true,
        mensaje: "Usuario registrado correctamente.",
        datos: { id: resultado.insertId }
    });
});


router.put("/:id", async (req, res) => {

    const id = validarId(req.params.id, "El usuario");
    const datos = validar(req.body, ESQUEMA);
    const { contrasena } = validar(req.body, ESQUEMA_CONTRASENA);

    const actual = await obtenerUsuario(id);

    const pierdeAdministrador =
        actual.rol === "Administrador" && datos.rol !== "Administrador";

    if (pierdeAdministrador && id === req.usuario.id) {
        throw solicitudInvalida("No puedes quitarte a ti mismo el rol de Administrador.", "rol");
    }

    if (
        pierdeAdministrador &&
        actual.estado === "Activo" &&
        (await otrosAdministradoresActivos(id)) === 0
    ) {
        throw solicitudInvalida("Debe quedar al menos un administrador activo.", "rol");
    }

    if (await correoEnUso(datos.correo, id)) {
        throw conflicto("Ese correo electrónico ya está en uso.", "correo");
    }

    if (contrasena) {

        const hash = await bcrypt.hash(contrasena, COSTE_BCRYPT);

        await consultar(
            "UPDATE usuarios SET nombre = ?, correo = ?, rol = ?, contrasena = ? WHERE id_usuario = ?",
            [datos.nombre, datos.correo, datos.rol, hash, id]
        );

    } else {

        await consultar(
            "UPDATE usuarios SET nombre = ?, correo = ?, rol = ? WHERE id_usuario = ?",
            [datos.nombre, datos.correo, datos.rol, id]
        );
    }

    console.log(`Usuario ${id} actualizado por ${req.usuario.correo}`);

    res.json({ correcto: true, mensaje: "Usuario actualizado correctamente." });
});


router.patch("/:id/estado", async (req, res) => {

    const id = validarId(req.params.id, "El usuario");
    const { estado } = validar(req.body, {
        estado: { tipo: "opcion", requerido: true, valores: ESTADOS, etiqueta: "El estado" }
    });

    if (estado === "Inactivo" && id === req.usuario.id) {
        throw solicitudInvalida("No puedes desactivar tu propia cuenta.");
    }

    const actual = await obtenerUsuario(id);

    if (
        estado === "Inactivo" &&
        actual.rol === "Administrador" &&
        (await otrosAdministradoresActivos(id)) === 0
    ) {
        throw solicitudInvalida("Debe quedar al menos un administrador activo.");
    }

    await consultar("UPDATE usuarios SET estado = ? WHERE id_usuario = ?", [estado, id]);

    console.log(`Usuario ${id}: ${estado} (por ${req.usuario.correo})`);

    res.json({
        correcto: true,
        mensaje: estado === "Activo"
            ? "Usuario activado correctamente."
            : "Usuario desactivado. Ya no podrá iniciar sesión."
    });
});


module.exports = router;
