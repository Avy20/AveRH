// ==========================================
// AveRH - Inicio y cierre de sesión
// ==========================================

const express = require("express");
const bcrypt = require("bcryptjs");

const { consultar } = require("../db");
const { ErrorHttp } = require("../utilidades/errores");
const {
    NOMBRE_COOKIE_SESION,
    requiereSesion,
    crearLimitador
} = require("../middleware/seguridad");

const COSTE_BCRYPT = 12;

// Se compara contra este hash cuando el correo no existe, para que
// el tiempo de respuesta no revele qué correos están registrados.
const HASH_FICTICIO = bcrypt.hashSync("averh-usuario-inexistente", COSTE_BCRYPT);

// 5 intentos fallidos por IP y correo cada 15 minutos.
const limitador = crearLimitador({ maximo: 5, ventanaMs: 15 * 60 * 1000 });

const router = express.Router();


const regenerarSesion = req =>
    new Promise((resolve, reject) =>
        req.session.regenerate(error => (error ? reject(error) : resolve())));

const guardarSesion = req =>
    new Promise((resolve, reject) =>
        req.session.save(error => (error ? reject(error) : resolve())));


router.post("/login", async (req, res) => {

    const correo = String(req.body?.correo || "").trim().toLowerCase();
    const contrasena = String(req.body?.contrasena || "");

    if (!correo || !contrasena) {
        throw new ErrorHttp(400, "Introduce tu correo y tu contraseña.");
    }

    const claveIntentos = `${req.ip}|${correo}`;

    if (limitador.bloqueado(claveIntentos)) {
        throw new ErrorHttp(429, "Demasiados intentos fallidos. Espera 15 minutos e inténtalo de nuevo.");
    }

    const [usuario] = await consultar(
        `SELECT id_usuario, nombre, correo, contrasena, rol, estado
         FROM usuarios
         WHERE correo = ?
         LIMIT 1`,
        [correo]
    );

    const contrasenaValida = await bcrypt.compare(
        contrasena,
        usuario ? usuario.contrasena : HASH_FICTICIO
    );

    if (!usuario || !contrasenaValida) {
        limitador.fallo(claveIntentos);
        throw new ErrorHttp(401, "Correo o contraseña incorrectos.");
    }

    if (usuario.estado !== "Activo") {
        throw new ErrorHttp(403, "Tu cuenta está desactivada. Contacta con un administrador.");
    }

    limitador.limpiar(claveIntentos);

    // Sesión nueva para evitar la fijación de sesión.
    await regenerarSesion(req);
    req.session.idUsuario = usuario.id_usuario;
    await guardarSesion(req);

    console.log(`Inicio de sesión: ${usuario.correo} (${usuario.rol})`);

    res.json({
        correcto: true,
        datos: {
            id: usuario.id_usuario,
            nombre: usuario.nombre,
            correo: usuario.correo,
            rol: usuario.rol
        }
    });
});


router.post("/logout", (req, res) => {

    req.session.destroy(() => {

        res.clearCookie(NOMBRE_COOKIE_SESION);

        res.json({ correcto: true, mensaje: "Sesión cerrada." });
    });
});


router.get("/me", requiereSesion, (req, res) => {

    res.json({ correcto: true, datos: req.usuario });
});


module.exports = { router, COSTE_BCRYPT };
