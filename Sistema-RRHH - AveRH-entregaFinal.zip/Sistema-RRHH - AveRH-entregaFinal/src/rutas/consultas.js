// ==========================================
// AveRH - Consulta de candidatos por criterios
// Todos los filtros se resuelven en MySQL.
// ==========================================

const express = require("express");

const { consultar } = require("../db");
const { solicitudInvalida } = require("../utilidades/errores");
const { ETAPAS, NIVELES_IDIOMA, NIVELES_CAPACITACION, FUENTES_RECLUTAMIENTO } = require("../utilidades/constantes");
const { SQL_CANDIDATOS } = require("../servicios/candidatos");
const { adjuntarCompatibilidad } = require("../servicios/idiomas");

const router = express.Router();


const entero = valor => {
    const n = Number(valor);
    return Number.isInteger(n) && n > 0 ? n : null;
};

const numero = valor => {
    if (valor === undefined || valor === null || valor === "") return null;
    const n = Number(valor);
    return Number.isFinite(n) && n >= 0 ? n : NaN;
};

const listaDeEnteros = valor =>
    String(valor || "")
        .split(",")
        .map(entero)
        .filter(Boolean);


// Construye la consulta a partir de los filtros recibidos.
function construirFiltros(q) {

    const condiciones = [];
    const parametros = [];

    const texto = String(q.texto || "").trim();

    if (texto) {
        condiciones.push("(x.nombre LIKE ? OR x.cedula LIKE ? OR x.correo LIKE ?)");
        const patron = `%${texto.replace(/[%_\\]/g, "\\$&")}%`;
        parametros.push(patron, patron, patron);
    }

    const filtrosExactos = {
        id_puesto: entero(q.id_puesto),
        id_departamento: entero(q.id_departamento),
        etapa: ETAPAS.includes(q.etapa) ? q.etapa : null,
        fuente_reclutamiento: FUENTES_RECLUTAMIENTO.includes(q.fuente) ? q.fuente : null
    };

    for (const [columna, valor] of Object.entries(filtrosExactos)) {
        if (valor !== null) {
            condiciones.push(`x.${columna} = ?`);
            parametros.push(valor);
        }
    }

    const salarioMinimo = numero(q.salario_min);
    const salarioMaximo = numero(q.salario_max);
    const experienciaMinima = numero(q.experiencia_min);

    if ([salarioMinimo, salarioMaximo, experienciaMinima].some(Number.isNaN)) {
        throw solicitudInvalida("Los valores numéricos de los filtros no son válidos.");
    }

    if (salarioMinimo !== null && salarioMaximo !== null && salarioMinimo > salarioMaximo) {
        throw solicitudInvalida("El salario mínimo no puede ser mayor que el máximo.", "salario_min");
    }

    if (salarioMinimo !== null) {
        condiciones.push("x.salario_aspira >= ?");
        parametros.push(salarioMinimo);
    }

    if (salarioMaximo !== null) {
        condiciones.push("x.salario_aspira <= ?");
        parametros.push(salarioMaximo);
    }

    if (experienciaMinima !== null) {
        condiciones.push("x.anios_experiencia >= ?");
        parametros.push(experienciaMinima);
    }

    // Debe tener TODAS las competencias seleccionadas.
    const competencias = listaDeEnteros(q.competencias);

    if (competencias.length > 0) {
        condiciones.push(`
            (SELECT COUNT(DISTINCT cc.id_competencia) FROM candidato_competencias cc
             WHERE cc.id_candidato = x.id AND cc.id_competencia IN (?)) = ?
        `);
        parametros.push(competencias, competencias.length);
    }

    const idCapacitacion = entero(q.id_capacitacion);

    if (idCapacitacion) {
        condiciones.push(`
            EXISTS (SELECT 1 FROM candidato_capacitaciones cca
                    WHERE cca.id_candidato = x.id AND cca.id_capacitacion = ?)
        `);
        parametros.push(idCapacitacion);
    }

    if (NIVELES_CAPACITACION.includes(q.nivel_capacitacion)) {
        condiciones.push(`
            EXISTS (SELECT 1 FROM candidato_capacitaciones cca
                    INNER JOIN capacitaciones ca ON ca.id_capacitacion = cca.id_capacitacion
                    WHERE cca.id_candidato = x.id AND BINARY ca.nivel = ?)
        `);
        parametros.push(q.nivel_capacitacion);
    }

    // Idioma con un nivel mínimo (Básico < Intermedio < Avanzado < Nativo).
    const idIdioma = entero(q.id_idioma);

    if (idIdioma) {

        const nivelMinimo = NIVELES_IDIOMA.includes(q.nivel_idioma) ? q.nivel_idioma : NIVELES_IDIOMA[0];

        condiciones.push(`
            EXISTS (SELECT 1 FROM candidato_idiomas ci
                    WHERE ci.id_candidato = x.id AND ci.id_idioma = ?
                    AND FIELD(ci.nivel, 'Básico', 'Intermedio', 'Avanzado', 'Nativo')
                        >= FIELD(?, 'Básico', 'Intermedio', 'Avanzado', 'Nativo'))
        `);
        parametros.push(idIdioma, nivelMinimo);
    }

    return {
        where: condiciones.length ? `WHERE ${condiciones.join(" AND ")}` : "",
        parametros
    };
}


router.get("/candidatos", async (req, res) => {

    const { where, parametros } = construirFiltros(req.query);

    const candidatos = await consultar(
        `SELECT x.*,
            (SELECT GROUP_CONCAT(co.descripcion ORDER BY co.descripcion SEPARATOR ', ')
             FROM candidato_competencias cc
             INNER JOIN competencias co ON co.id_competencia = cc.id_competencia
             WHERE cc.id_candidato = x.id) AS competencias,
            (SELECT GROUP_CONCAT(CONCAT(i.nombre, ' (', ci.nivel, ')') ORDER BY i.nombre SEPARATOR ', ')
             FROM candidato_idiomas ci
             INNER JOIN idiomas i ON i.id_idioma = ci.id_idioma
             WHERE ci.id_candidato = x.id) AS idiomas,
            (SELECT COUNT(*) FROM candidato_capacitaciones cca WHERE cca.id_candidato = x.id) AS capacitaciones
         FROM (${SQL_CANDIDATOS}) x
         ${where}
         ORDER BY x.nombre ASC`,
        parametros
    );

    res.json({ correcto: true, datos: await adjuntarCompatibilidad(candidatos) });
});


module.exports = router;
