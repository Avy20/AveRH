// ==========================================
// AveRH - Experiencia laboral de los candidatos
// ==========================================

const express = require("express");

const { consultar, transaccion } = require("../db");
const { validar, validarId, hoyISO } = require("../utilidades/validacion");
const { noEncontrado, solicitudInvalida } = require("../utilidades/errores");
const { obtenerCandidato, marcarActualizado } = require("../servicios/candidatos");

const router = express.Router();


const ESQUEMA = {
    id_candidato: { tipo: "entero", requerido: true, min: 1, etiqueta: "El candidato" },
    empresa: { tipo: "texto", requerido: true, min: 2, max: 150, etiqueta: "La empresa" },
    puesto_ocupado: { tipo: "texto", requerido: true, min: 2, max: 100, etiqueta: "El puesto ocupado" },
    fecha_desde: { tipo: "fecha", requerido: true, noFutura: true, etiqueta: "La fecha de inicio" },
    fecha_hasta: { tipo: "fecha", noFutura: true, etiqueta: "La fecha de finalización" },
    salario: { tipo: "decimal", min: 0, max: 99999999, etiqueta: "El salario" }
};

const SQL_EXPERIENCIAS = `
    SELECT el.id_experiencia, el.id_candidato, c.nombre AS candidato, c.cedula,
           el.empresa, el.puesto_ocupado, el.fecha_desde, el.fecha_hasta, el.salario,
           ROUND(DATEDIFF(COALESCE(el.fecha_hasta, CURDATE()), el.fecha_desde) / 30.44) AS meses
    FROM experiencia_laboral el
    INNER JOIN candidatos c ON c.id_candidato = el.id_candidato
`;


async function obtenerExperiencia(id) {

    const [experiencia] = await consultar(
        `${SQL_EXPERIENCIAS} WHERE el.id_experiencia = ?`,
        [id]
    );

    if (!experiencia) {
        throw noEncontrado("La experiencia laboral no existe.");
    }

    return experiencia;
}


async function validarExperiencia(body) {

    const datos = validar(body, ESQUEMA);

    if (datos.fecha_hasta && datos.fecha_hasta < datos.fecha_desde) {
        throw solicitudInvalida(
            "La fecha de finalización no puede ser anterior a la de inicio.",
            "fecha_hasta"
        );
    }

    if (datos.fecha_desde > hoyISO()) {
        throw solicitudInvalida("La fecha de inicio no puede ser futura.", "fecha_desde");
    }

    // Comprueba que el candidato existe (lanza 404 si no).
    await obtenerCandidato(datos.id_candidato);

    return datos;
}


router.get("/", async (req, res) => {

    const idCandidato = Number(req.query.id_candidato) || null;

    const experiencias = await consultar(
        `${SQL_EXPERIENCIAS}
         WHERE (? IS NULL OR el.id_candidato = ?)
         ORDER BY c.nombre, COALESCE(el.fecha_hasta, '9999-12-31') DESC`,
        [idCandidato, idCandidato]
    );

    res.json({ correcto: true, datos: experiencias });
});


router.post("/", async (req, res) => {

    const datos = await validarExperiencia(req.body);

    const id = await transaccion(async q => {

        const resultado = await q(
            `INSERT INTO experiencia_laboral
                (id_candidato, empresa, puesto_ocupado, fecha_desde, fecha_hasta, salario)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [datos.id_candidato, datos.empresa, datos.puesto_ocupado, datos.fecha_desde, datos.fecha_hasta, datos.salario]
        );

        await marcarActualizado(q, datos.id_candidato);

        return resultado.insertId;
    });

    res.status(201).json({
        correcto: true,
        mensaje: "Experiencia laboral registrada correctamente.",
        datos: await obtenerExperiencia(id)
    });
});


router.put("/:id", async (req, res) => {

    const id = validarId(req.params.id, "La experiencia");
    const actual = await obtenerExperiencia(id);
    const datos = await validarExperiencia(req.body);

    await transaccion(async q => {

        await q(
            `UPDATE experiencia_laboral
             SET id_candidato = ?, empresa = ?, puesto_ocupado = ?,
                 fecha_desde = ?, fecha_hasta = ?, salario = ?
             WHERE id_experiencia = ?`,
            [datos.id_candidato, datos.empresa, datos.puesto_ocupado, datos.fecha_desde, datos.fecha_hasta, datos.salario, id]
        );

        await marcarActualizado(q, datos.id_candidato);

        if (actual.id_candidato !== datos.id_candidato) {
            await marcarActualizado(q, actual.id_candidato);
        }
    });

    res.json({
        correcto: true,
        mensaje: "Experiencia laboral actualizada correctamente.",
        datos: await obtenerExperiencia(id)
    });
});


router.delete("/:id", async (req, res) => {

    const id = validarId(req.params.id, "La experiencia");
    const actual = await obtenerExperiencia(id);

    await transaccion(async q => {
        await q("DELETE FROM experiencia_laboral WHERE id_experiencia = ?", [id]);
        await marcarActualizado(q, actual.id_candidato);
    });

    res.json({ correcto: true, mensaje: "Experiencia laboral eliminada correctamente." });
});


module.exports = router;
