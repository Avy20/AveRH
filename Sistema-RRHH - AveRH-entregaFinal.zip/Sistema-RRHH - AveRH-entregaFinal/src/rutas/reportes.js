// ==========================================
// AveRH - Reportes
// ==========================================

const express = require("express");

const { consultar } = require("../db");
const { validar } = require("../utilidades/validacion");
const { solicitudInvalida } = require("../utilidades/errores");
const { ETAPAS } = require("../utilidades/constantes");
const { SQL_CANDIDATOS } = require("../servicios/candidatos");

const router = express.Router();


function leerPeriodo(query) {

    const { desde, hasta } = validar(query, {
        desde: { tipo: "fecha", etiqueta: "La fecha desde" },
        hasta: { tipo: "fecha", etiqueta: "La fecha hasta" }
    });

    if (desde && hasta && desde > hasta) {
        throw solicitudInvalida("La fecha desde no puede ser posterior a la fecha hasta.", "desde");
    }

    return { desde, hasta };
}


function agrupar(lista, clave) {

    const grupos = new Map();

    for (const elemento of lista) {
        const nombre = elemento[clave] || "Sin indicar";
        grupos.set(nombre, (grupos.get(nombre) || 0) + 1);
    }

    return [...grupos.entries()]
        .map(([nombre, cantidad]) => ({
            nombre,
            cantidad,
            porcentaje: lista.length ? Math.round((cantidad / lista.length) * 1000) / 10 : 0
        }))
        .sort((a, b) => b.cantidad - a.cantidad || a.nombre.localeCompare(b.nombre));
}


// --------------------------------------
// REPORTE DE INGRESOS DE EMPLEADOS
// --------------------------------------

router.get("/ingresos", async (req, res) => {

    const { desde, hasta } = leerPeriodo(req.query);
    const idDepartamento = Number(req.query.id_departamento) || null;

    const empleados = await consultar(
        `SELECT e.id_empleado AS id, e.cedula, e.nombre, e.fecha_ingreso, e.salario_mensual, e.estado,
                p.nombre AS puesto, COALESCE(d.nombre, e.departamento) AS departamento
         FROM empleados e
         LEFT JOIN puestos p ON p.id_puesto = e.id_puesto
         LEFT JOIN departamentos d ON d.id_departamento = p.id_departamento
         WHERE (? IS NULL OR e.fecha_ingreso >= ?)
           AND (? IS NULL OR e.fecha_ingreso <= ?)
           AND (? IS NULL OR p.id_departamento = ?)
         ORDER BY e.fecha_ingreso ASC, e.nombre ASC`,
        [desde, desde, hasta, hasta, idDepartamento, idDepartamento]
    );

    const activos = empleados.filter(e => e.estado === "Activo");
    const salarios = empleados.map(e => Number(e.salario_mensual));
    const nomina = activos.reduce((total, e) => total + Number(e.salario_mensual), 0);

    res.json({
        correcto: true,
        datos: {
            periodo: { desde, hasta },
            empleados,
            resumen: {
                total: empleados.length,
                activos: activos.length,
                inactivos: empleados.length - activos.length,
                nomina_mensual: nomina,
                salario_promedio: activos.length ? Math.round(nomina / activos.length) : 0,
                salario_maximo: salarios.length ? Math.max(...salarios) : 0,
                salario_minimo: salarios.length ? Math.min(...salarios) : 0
            },
            por_departamento: agrupar(empleados, "departamento"),
            por_puesto: agrupar(empleados, "puesto")
        }
    });
});


// --------------------------------------
// REPORTE DEL PROCESO DE SELECCIÓN
// --------------------------------------

router.get("/seleccion", async (req, res) => {

    const { desde, hasta } = leerPeriodo(req.query);

    const candidatos = await consultar(
        `SELECT x.*, e.fecha_ingreso,
                DATEDIFF(e.fecha_ingreso, x.fecha_postulacion) AS dias_hasta_contratacion
         FROM (${SQL_CANDIDATOS}) x
         LEFT JOIN empleados e ON e.id_empleado = x.id_empleado
         WHERE (? IS NULL OR x.fecha_postulacion >= ?)
           AND (? IS NULL OR x.fecha_postulacion <= ?)
         ORDER BY x.fecha_postulacion DESC, x.nombre`,
        [desde, desde, hasta, hasta]
    );

    const contratados = candidatos.filter(c => c.etapa === "Contratado");
    const finalizados = candidatos.filter(c => ["Contratado", "Descartado"].includes(c.etapa));
    const tiempos = contratados
        .map(c => c.dias_hasta_contratacion)
        .filter(dias => dias !== null && dias >= 0);

    const porEtapa = agrupar(candidatos, "etapa");

    // Candidatos antiguos sin fecha de postulación: no pueden
    // entrar en un filtro por fechas. Se informa cuántos son.
    const [{ sinFecha }] = desde || hasta
        ? await consultar("SELECT COUNT(*) AS sinFecha FROM candidatos WHERE fecha_postulacion IS NULL")
        : [{ sinFecha: 0 }];

    res.json({
        correcto: true,
        datos: {
            periodo: { desde, hasta },
            candidatos,
            resumen: {
                total: candidatos.length,
                en_proceso: candidatos.length - finalizados.length,
                contratados: contratados.length,
                descartados: finalizados.length - contratados.length,
                tasa_contratacion: finalizados.length
                    ? Math.round((contratados.length / finalizados.length) * 1000) / 10
                    : 0,
                sin_fecha_postulacion: Number(sinFecha),
                dias_promedio_contratacion: tiempos.length
                    ? Math.round(tiempos.reduce((a, b) => a + b, 0) / tiempos.length)
                    : null
            },
            por_etapa: ETAPAS.map(etapa =>
                porEtapa.find(g => g.nombre === etapa) || { nombre: etapa, cantidad: 0, porcentaje: 0 }),
            por_fuente: agrupar(candidatos, "fuente_reclutamiento"),
            por_puesto: agrupar(candidatos, "puesto")
        }
    });
});


module.exports = router;
