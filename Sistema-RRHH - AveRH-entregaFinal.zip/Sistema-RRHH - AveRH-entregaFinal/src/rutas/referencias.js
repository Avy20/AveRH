// ==========================================
// AveRH - Datos de referencia para formularios
// Catálogos activos y valores permitidos, en una sola petición.
// ==========================================

const express = require("express");

const { consultar } = require("../db");
const constantes = require("../utilidades/constantes");

const router = express.Router();


router.get("/", async (req, res) => {

    const [departamentos, puestos, vacantes, competencias, idiomas, capacitaciones] = await Promise.all([

        consultar("SELECT id_departamento, nombre, estado FROM departamentos ORDER BY nombre"),

        consultar(`
            SELECT p.id_puesto, p.nombre, p.id_departamento, d.nombre AS departamento,
                   p.salario_minimo, p.salario_maximo, p.estado
            FROM puestos p
            LEFT JOIN departamentos d ON d.id_departamento = p.id_departamento
            ORDER BY p.nombre
        `),

        consultar(`
            SELECT v.id_vacante, v.titulo, v.id_puesto, p.nombre AS puesto, d.nombre AS departamento,
                   p.salario_minimo, p.salario_maximo, v.estado, v.fecha_cierre,
                   (SELECT JSON_ARRAYAGG(JSON_OBJECT('id_idioma', vi.id_idioma, 'idioma', i.nombre, 'nivel', vi.nivel_minimo))
                    FROM vacante_idiomas vi INNER JOIN idiomas i ON i.id_idioma = vi.id_idioma
                    WHERE vi.id_vacante = v.id_vacante) AS requisitos_idiomas
            FROM vacantes v
            INNER JOIN puestos p ON p.id_puesto = v.id_puesto
            LEFT JOIN departamentos d ON d.id_departamento = p.id_departamento
            ORDER BY v.titulo
        `),

        consultar("SELECT id_competencia, descripcion, estado FROM competencias ORDER BY descripcion"),

        consultar("SELECT id_idioma, nombre, estado FROM idiomas ORDER BY nombre"),

        consultar(`
            SELECT id_capacitacion, descripcion, nivel, institucion, fecha_desde, fecha_hasta, estado
            FROM capacitaciones ORDER BY descripcion
        `)
    ]);

    res.json({
        correcto: true,
        datos: {
            departamentos,
            puestos,
            vacantes,
            competencias,
            idiomas,
            capacitaciones,
            etapas: constantes.ETAPAS,
            roles: constantes.ROLES,
            niveles_capacitacion: constantes.NIVELES_CAPACITACION,
            niveles_idioma: constantes.NIVELES_IDIOMA,
            niveles_requisito: ["No requerido", ...constantes.NIVELES_IDIOMA],
            niveles_riesgo: constantes.NIVELES_RIESGO,
            fuentes: constantes.FUENTES_RECLUTAMIENTO
        }
    });
});


module.exports = router;
