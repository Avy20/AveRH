// ==========================================
// AveRH - Exportación a Excel
// POST /api/exportaciones/excel
// Recibe exactamente las filas que el usuario está viendo
// (con sus filtros aplicados) y devuelve un .xlsx.
// ==========================================

const express = require("express");

const { solicitudInvalida } = require("../utilidades/errores");
const { crearLibroExcel, TIPOS } = require("../servicios/excel");

const router = express.Router();

const LIMITES = { hojas: 6, columnas: 30, filas: 10000, texto: 500 };


const textoCorto = (valor, maximo = 150) =>
    typeof valor === "string" && valor.trim().length > 0 && valor.length <= maximo;


function validarHoja(hoja, indice) {

    if (!hoja || !textoCorto(hoja.nombre, 31) || /[\\/?*[\]:]/.test(hoja.nombre)) {
        throw solicitudInvalida(`El nombre de la hoja ${indice + 1} no es válido.`);
    }

    if (!Array.isArray(hoja.columnas) || hoja.columnas.length === 0 || hoja.columnas.length > LIMITES.columnas) {
        throw solicitudInvalida(`La hoja «${hoja.nombre}» no tiene columnas válidas.`);
    }

    for (const columna of hoja.columnas) {

        if (!textoCorto(columna?.titulo, 80) || (columna.tipo && !TIPOS.includes(columna.tipo))) {
            throw solicitudInvalida(`Hay una columna no válida en «${hoja.nombre}».`);
        }

        if (columna.ancho !== undefined && !(Number(columna.ancho) >= 4 && Number(columna.ancho) <= 80)) {
            throw solicitudInvalida("El ancho de una columna no es válido.");
        }

        if (columna.total !== undefined && !["suma", "promedio", "cuenta"].includes(columna.total)) {
            throw solicitudInvalida("El tipo de total de una columna no es válido.");
        }
    }

    if (!Array.isArray(hoja.filas) || hoja.filas.length > LIMITES.filas) {
        throw solicitudInvalida(`La hoja «${hoja.nombre}» supera el máximo de ${LIMITES.filas} filas.`);
    }

    for (const fila of hoja.filas) {

        if (!Array.isArray(fila) || fila.length > hoja.columnas.length) {
            throw solicitudInvalida(`Hay una fila no válida en «${hoja.nombre}».`);
        }

        for (const valor of fila) {

            const valido =
                valor === null ||
                typeof valor === "number" ||
                (typeof valor === "string" && valor.length <= LIMITES.texto);

            if (!valido) {
                throw solicitudInvalida(`Hay un valor no válido en «${hoja.nombre}».`);
            }
        }
    }
}


// Nombre de archivo seguro: letras, números, guiones y puntos.
function nombreArchivo(texto) {

    const base = String(texto || "averh")
        .normalize("NFD")
        .replace(/[̀-ͯ]/g, "")
        .replace(/[^A-Za-z0-9_-]+/g, "_")
        .replace(/^_+|_+$/g, "")
        .slice(0, 80) || "averh";

    return `${base}.xlsx`;
}


router.post("/excel", async (req, res) => {

    const { titulo, subtitulo, archivo, hojas } = req.body || {};

    if (!textoCorto(titulo)) {
        throw solicitudInvalida("El título del archivo es obligatorio.");
    }

    if (subtitulo !== undefined && subtitulo !== null && (typeof subtitulo !== "string" || subtitulo.length > 300)) {
        throw solicitudInvalida("El subtítulo no es válido.");
    }

    if (!Array.isArray(hojas) || hojas.length === 0 || hojas.length > LIMITES.hojas) {
        throw solicitudInvalida("El archivo debe tener entre 1 y 6 hojas.");
    }

    hojas.forEach(validarHoja);

    if (new Set(hojas.map(h => h.nombre.toLowerCase())).size !== hojas.length) {
        throw solicitudInvalida("Los nombres de las hojas no pueden repetirse.");
    }

    const contenido = await crearLibroExcel({
        titulo,
        subtitulo: subtitulo || "",
        usuario: req.usuario.nombre,
        hojas
    });

    res.set({
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${nombreArchivo(archivo || titulo)}"`,
        "Cache-Control": "no-store"
    });

    res.send(Buffer.from(contenido));
});


module.exports = router;
