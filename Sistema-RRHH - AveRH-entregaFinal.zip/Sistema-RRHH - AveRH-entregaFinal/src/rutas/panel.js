// ==========================================
// AveRH - Panel principal
// Todas las cifras se calculan en MySQL en el momento.
// ==========================================

const express = require("express");

const { consultar } = require("../db");
const { ETAPAS } = require("../utilidades/constantes");
const { SQL_CANDIDATOS } = require("../servicios/candidatos");

const router = express.Router();


router.get("/", async (req, res) => {

    const [
        [indicadores],
        embudo,
        contrataciones,
        recientes,
        vacantesPorCerrar,
        actividad
    ] = await Promise.all([

        consultar(`
            SELECT
                (SELECT COUNT(*) FROM candidatos) AS candidatos,
                (SELECT COUNT(*) FROM (${SQL_CANDIDATOS}) x
                    WHERE x.etapa NOT IN ('Contratado', 'Descartado')) AS en_proceso,
                (SELECT COUNT(*) FROM candidatos
                    WHERE fecha_postulacion >= DATE_FORMAT(CURDATE(), '%Y-%m-01')) AS postulaciones_mes,
                (SELECT COUNT(*) FROM empleados WHERE estado = 'Activo') AS empleados_activos,
                (SELECT COALESCE(SUM(salario_mensual), 0) FROM empleados WHERE estado = 'Activo') AS nomina_mensual,
                (SELECT COUNT(*) FROM empleados
                    WHERE fecha_ingreso >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
                      AND fecha_ingreso <= CURDATE()) AS contrataciones_mes,
                (SELECT COUNT(*) FROM vacantes WHERE estado = 'Abierta') AS vacantes_abiertas,
                (SELECT COALESCE(SUM(cantidad_vacantes), 0) FROM vacantes WHERE estado = 'Abierta') AS plazas_abiertas
        `),

        consultar(`
            SELECT x.etapa, COUNT(*) AS cantidad
            FROM (${SQL_CANDIDATOS}) x
            GROUP BY x.etapa
        `),

        // Contrataciones de los últimos 6 meses (incluido el actual).
        consultar(`
            SELECT DATE_FORMAT(fecha_ingreso, '%Y-%m') AS mes, COUNT(*) AS cantidad
            FROM empleados
            WHERE fecha_ingreso >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 5 MONTH)
              AND fecha_ingreso <= CURDATE()
            GROUP BY mes
        `),

        consultar(`
            SELECT x.*, COALESCE(x.fecha_actualizacion, x.fecha_postulacion) AS fecha_referencia
            FROM (${SQL_CANDIDATOS}) x
            ORDER BY COALESCE(x.fecha_actualizacion, x.fecha_postulacion) DESC, x.id DESC
            LIMIT 6
        `),

        consultar(`
            SELECT v.id_vacante, v.titulo, v.cantidad_vacantes, v.fecha_cierre, p.nombre AS puesto,
                   DATEDIFF(v.fecha_cierre, CURDATE()) AS dias_restantes,
                   (SELECT COUNT(*) FROM proceso_seleccion ps WHERE ps.id_vacante = v.id_vacante) AS postulantes
            FROM vacantes v
            INNER JOIN puestos p ON p.id_puesto = v.id_puesto
            WHERE v.estado = 'Abierta'
            ORDER BY v.fecha_cierre IS NULL, v.fecha_cierre ASC
            LIMIT 5
        `),

        consultar(`
            SELECT h.fecha, h.etapa_anterior, h.etapa_nueva, h.observacion,
                   c.id_candidato, c.nombre AS candidato, u.nombre AS usuario
            FROM proceso_historial h
            INNER JOIN proceso_seleccion ps ON ps.id_proceso = h.id_proceso
            INNER JOIN candidatos c ON c.id_candidato = ps.id_candidato
            LEFT JOIN usuarios u ON u.id_usuario = h.id_usuario
            WHERE h.id_usuario IS NOT NULL
            ORDER BY h.fecha DESC, h.id_historial DESC
            LIMIT 6
        `)
    ]);


    // Embudo con todas las etapas, aunque alguna tenga 0.
    const porEtapa = Object.fromEntries(embudo.map(f => [f.etapa, Number(f.cantidad)]));

    // Serie mensual completa de 6 meses.
    const porMes = Object.fromEntries(contrataciones.map(f => [f.mes, Number(f.cantidad)]));
    const meses = [];
    const hoy = new Date();

    for (let i = 5; i >= 0; i--) {
        const fecha = new Date(hoy.getFullYear(), hoy.getMonth() - i, 1);
        const clave = `${fecha.getFullYear()}-${String(fecha.getMonth() + 1).padStart(2, "0")}`;
        meses.push({ mes: clave, cantidad: porMes[clave] || 0 });
    }

    res.json({
        correcto: true,
        datos: {
            indicadores: Object.fromEntries(
                Object.entries(indicadores).map(([clave, valor]) => [clave, Number(valor)])
            ),
            embudo: ETAPAS.map(etapa => ({ etapa, cantidad: porEtapa[etapa] || 0 })),
            contrataciones: meses,
            recientes,
            vacantes_por_cerrar: vacantesPorCerrar,
            actividad
        }
    });
});


module.exports = router;
