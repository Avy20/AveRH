// ==========================================
// AveRH - Proceso de selección
// Cambios de etapa con historial y contratación.
// ==========================================

const express = require("express");

const { consultar, transaccion } = require("../db");
const { validar, validarId } = require("../utilidades/validacion");
const { solicitudInvalida, conflicto } = require("../utilidades/errores");
const { ETAPAS } = require("../utilidades/constantes");
const {
    SQL_CANDIDATOS,
    obtenerCandidato,
    marcarActualizado,
    obtenerPuesto,
    comprobarRangoSalarial,
    registrarHistorial
} = require("../servicios/candidatos");
const { adjuntarCompatibilidad } = require("../servicios/idiomas");

const router = express.Router();


// Tablero: todos los candidatos activos con su etapa y
// los días que llevan en ella.
router.get("/", async (req, res) => {

    const candidatos = await consultar(`
        SELECT x.*,
            DATEDIFF(CURDATE(), COALESCE(x.fecha_proceso, x.fecha_postulacion)) AS dias_en_etapa
        FROM (${SQL_CANDIDATOS}) AS x
        WHERE x.estado = 'Activo'
        ORDER BY COALESCE(x.fecha_actualizacion, x.fecha_proceso, x.fecha_postulacion) DESC, x.id DESC
    `);

    res.json({ correcto: true, datos: { etapas: ETAPAS, candidatos: await adjuntarCompatibilidad(candidatos) } });
});


// Busca la vacante más reciente del puesto (para candidatos
// antiguos que todavía no tienen proceso).
async function vacanteParaPuesto(q, idPuesto) {

    const [vacante] = await q(
        `SELECT id_vacante FROM vacantes
         WHERE id_puesto = ?
         ORDER BY (estado = 'Abierta') DESC, id_vacante DESC
         LIMIT 1`,
        [idPuesto]
    );

    if (!vacante) {
        throw solicitudInvalida(
            "No existe ninguna vacante para el puesto de este candidato. Crea una vacante primero."
        );
    }

    return vacante.id_vacante;
}


router.put("/:idCandidato/etapa", async (req, res) => {

    const idCandidato = validarId(req.params.idCandidato, "El candidato");

    const { etapa, observacion } = validar(req.body, {
        etapa: { tipo: "opcion", requerido: true, valores: ETAPAS, etiqueta: "La etapa" },
        observacion: { tipo: "texto", max: 255, etiqueta: "La observación" }
    });

    const candidato = await obtenerCandidato(idCandidato);

    if (candidato.etapa === etapa && candidato.id_proceso) {
        return res.json({
            correcto: true,
            mensaje: `${candidato.nombre} ya está en la etapa ${etapa}.`,
            datos: candidato
        });
    }

    // Un candidato contratado ya es empleado: moverlo de etapa
    // dejaría los datos incoherentes.
    if (candidato.id_empleado) {
        throw conflicto(
            `${candidato.nombre} ya es empleado. Para cambiar su situación, gestiónalo desde el módulo Empleados.`
        );
    }

    let contratacion = null;

    if (etapa === "Contratado") {

        contratacion = validar(req.body?.contratacion, {
            fecha_ingreso: { tipo: "fecha", requerido: true, etiqueta: "La fecha de ingreso" },
            salario_mensual: { tipo: "decimal", requerido: true, min: 1, max: 99999999, etiqueta: "El salario mensual" }
        });

        const puesto = await obtenerPuesto(candidato.id_puesto);

        if (puesto.estado !== "Activo") {
            throw solicitudInvalida("El puesto del candidato está inactivo: no se puede contratar.");
        }

        comprobarRangoSalarial(contratacion.salario_mensual, puesto, "salario_mensual");

        const [empleadoExistente] = await consultar(
            "SELECT id_empleado, id_candidato FROM empleados WHERE REPLACE(cedula, '-', '') = REPLACE(?, '-', '')",
            [candidato.cedula]
        );

        if (empleadoExistente) {
            throw conflicto("Ya existe un empleado registrado con la cédula de este candidato.");
        }

        contratacion.puesto = puesto;
    }

    await transaccion(async q => {

        let idProceso = candidato.id_proceso;

        if (idProceso) {

            await q(
                `UPDATE proceso_seleccion
                 SET resultado = ?, fecha_proceso = CURDATE(),
                     observaciones = COALESCE(?, observaciones)
                 WHERE id_proceso = ?`,
                [etapa, observacion, idProceso]
            );

        } else {

            const idVacante = await vacanteParaPuesto(q, candidato.id_puesto);

            const proceso = await q(
                `INSERT INTO proceso_seleccion (id_candidato, id_vacante, fecha_proceso, resultado, observaciones)
                 VALUES (?, ?, CURDATE(), ?, ?)`,
                [idCandidato, idVacante, etapa, observacion || "Proceso creado desde el tablero."]
            );

            idProceso = proceso.insertId;
        }

        await registrarHistorial(q, {
            idProceso,
            anterior: candidato.id_proceso ? candidato.etapa : null,
            nueva: etapa,
            observacion,
            idUsuario: req.usuario.id
        });

        if (contratacion) {

            await q(
                `INSERT INTO empleados (
                    id_candidato, cedula, nombre, fecha_ingreso, departamento,
                    id_puesto, salario_mensual, estado
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Activo')`,
                [
                    idCandidato, candidato.cedula, candidato.nombre,
                    contratacion.fecha_ingreso, contratacion.puesto.departamento,
                    contratacion.puesto.id_puesto, contratacion.salario_mensual
                ]
            );
        }

        await marcarActualizado(q, idCandidato);
    });

    console.log(`Proceso: ${candidato.nombre} ${candidato.etapa} → ${etapa} (por ${req.usuario.correo})`);

    res.json({
        correcto: true,
        mensaje: contratacion
            ? `${candidato.nombre} fue contratado y registrado como empleado.`
            : `${candidato.nombre} pasó a la etapa ${etapa}.`,
        datos: await obtenerCandidato(idCandidato)
    });
});


module.exports = router;
