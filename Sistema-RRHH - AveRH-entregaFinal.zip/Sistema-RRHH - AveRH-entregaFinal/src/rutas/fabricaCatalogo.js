// ==========================================
// AveRH - Rutas genéricas para catálogos
//
// Genera GET, POST, PUT, PATCH /estado y DELETE para una tabla
// a partir de su descripción (esquema de validación, campo
// único, consulta de lectura, etc.).
// ==========================================

const express = require("express");

const { consultar, transaccion } = require("../db");
const { validar, validarId } = require("../utilidades/validacion");
const { noEncontrado, conflicto } = require("../utilidades/errores");
const { ESTADOS } = require("../utilidades/constantes");
const { soloAdministrador } = require("../middleware/seguridad");


const mayuscula = texto => texto.charAt(0).toUpperCase() + texto.slice(1);


function crearRutasCatalogo(config) {

    const {
        tabla,
        id,
        singular,
        femenino = false,
        esquema,
        campoUnico,
        consulta = `SELECT * FROM ${tabla}`,
        orden,
        estados = ESTADOS,
        validarExtra = async () => {},
        // Datos relacionados (p. ej. idiomas de una vacante): se validan
        // antes y se guardan en la misma transacción que el registro.
        leerRelacionados = () => null,
        guardarRelacionados = async () => {}
    } = config;

    const o = femenino ? "a" : "o";
    const Nombre = mayuscula(singular);
    const articulo = femenino ? "La" : "El";

    const router = express.Router();


    // Lectura sobre una tabla derivada: permite que la consulta
    // incluya JOIN y columnas calculadas.
    async function buscarPorId(idRegistro) {

        const [registro] = await consultar(
            `SELECT * FROM (${consulta}) AS x WHERE x.${id} = ?`,
            [idRegistro]
        );

        if (!registro) {
            throw noEncontrado(`${articulo} ${singular} no existe.`);
        }

        return registro;
    }


    async function comprobarUnico(datos, idExcluido = 0) {

        if (!campoUnico || !datos[campoUnico]) {
            return;
        }

        // La intercalación utf8mb4_0900_ai_ci compara sin distinguir
        // mayúsculas ni acentos: "Inglés" = "ingles".
        const filas = await consultar(
            `SELECT 1 FROM ${tabla} WHERE ${campoUnico} = ? AND ${id} <> ? LIMIT 1`,
            [datos[campoUnico], idExcluido]
        );

        if (filas.length > 0) {
            throw conflicto(`Ya existe ${femenino ? "una" : "un"} ${singular} con ese nombre.`, campoUnico);
        }
    }


    router.get("/", async (req, res) => {

        const estado = estados.includes(req.query.estado) ? req.query.estado : null;

        const registros = await consultar(
            `SELECT * FROM (${consulta}) AS x
             WHERE (? IS NULL OR x.estado = ?)
             ORDER BY ${orden}`,
            [estado, estado]
        );

        res.json({ correcto: true, datos: registros });
    });


    router.get("/:id", async (req, res) => {

        const registro = await buscarPorId(validarId(req.params.id));

        res.json({ correcto: true, datos: registro });
    });


    router.post("/", async (req, res) => {

        const datos = validar(req.body, esquema);
        const relacionados = leerRelacionados(req.body);

        await comprobarUnico(datos);
        await validarExtra(datos, null);

        const columnas = Object.keys(datos);

        const resultado = await transaccion(async q => {

            const insercion = await q(
                `INSERT INTO ${tabla} (${[...columnas, "estado"].join(", ")})
                 VALUES (${columnas.map(() => "?").join(", ")}, ?)`,
                [...columnas.map(c => datos[c]), estados[0]]
            );

            await guardarRelacionados(q, insercion.insertId, relacionados);

            return insercion;
        });

        res.status(201).json({
            correcto: true,
            mensaje: `${Nombre} registrad${o} correctamente.`,
            datos: await buscarPorId(resultado.insertId)
        });
    });


    router.put("/:id", async (req, res) => {

        const idRegistro = validarId(req.params.id);
        const actual = await buscarPorId(idRegistro);
        const datos = validar(req.body, esquema);
        const relacionados = leerRelacionados(req.body);

        await comprobarUnico(datos, idRegistro);
        await validarExtra(datos, actual);

        const columnas = Object.keys(datos);

        await transaccion(async q => {

            await q(
                `UPDATE ${tabla}
                 SET ${columnas.map(c => `${c} = ?`).join(", ")}
                 WHERE ${id} = ?`,
                [...columnas.map(c => datos[c]), idRegistro]
            );

            await guardarRelacionados(q, idRegistro, relacionados);
        });

        res.json({
            correcto: true,
            mensaje: `${Nombre} actualizad${o} correctamente.`,
            datos: await buscarPorId(idRegistro)
        });
    });


    router.patch("/:id/estado", async (req, res) => {

        const idRegistro = validarId(req.params.id);

        await buscarPorId(idRegistro);

        const { estado } = validar(req.body, {
            estado: { tipo: "opcion", requerido: true, valores: estados, etiqueta: "El estado" }
        });

        await consultar(
            `UPDATE ${tabla} SET estado = ? WHERE ${id} = ?`,
            [estado, idRegistro]
        );

        res.json({
            correcto: true,
            mensaje: `${Nombre} marcad${o} como ${estado.toLowerCase()}.`,
            datos: await buscarPorId(idRegistro)
        });
    });


    // Eliminar es exclusivo del administrador. Si el registro
    // está en uso, MySQL lo impide (clave foránea) y se responde
    // 409 sugiriendo desactivarlo.
    router.delete("/:id", soloAdministrador, async (req, res) => {

        const idRegistro = validarId(req.params.id);

        await buscarPorId(idRegistro);

        await consultar(`DELETE FROM ${tabla} WHERE ${id} = ?`, [idRegistro]);

        res.json({
            correcto: true,
            mensaje: `${Nombre} eliminad${o} correctamente.`
        });
    });


    return router;
}


module.exports = { crearRutasCatalogo };
