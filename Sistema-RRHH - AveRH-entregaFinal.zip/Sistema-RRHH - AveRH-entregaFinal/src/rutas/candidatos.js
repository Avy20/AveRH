// ==========================================
// AveRH - Candidatos
// ==========================================

const express = require("express");

const { consultar, transaccion } = require("../db");
const { validar, validarId, NOMBRE_PERSONA } = require("../utilidades/validacion");
const { solicitudInvalida, conflicto } = require("../utilidades/errores");
const { FUENTES_RECLUTAMIENTO, NIVELES_IDIOMA } = require("../utilidades/constantes");
const { soloAdministrador } = require("../middleware/seguridad");
const {
    SQL_CANDIDATOS,
    obtenerCandidato,
    marcarActualizado,
    obtenerPuesto,
    comprobarRangoSalarial,
    registrarHistorial
} = require("../servicios/candidatos");
const { adjuntarCompatibilidad, requisitosDeVacantes, evaluarIdiomas } = require("../servicios/idiomas");

const router = express.Router();


const CAMPOS_COMUNES = {
    nombre: {
        tipo: "texto", requerido: true, min: 3, max: 150,
        patron: NOMBRE_PERSONA, mensajePatron: "solo puede contener letras y espacios.",
        etiqueta: "El nombre"
    },
    telefono: { tipo: "telefono", etiqueta: "El teléfono" },
    salario_aspira: { tipo: "decimal", requerido: true, min: 1, max: 99999999, etiqueta: "El salario aspirado" },
    recomendado_por: { tipo: "texto", max: 150, etiqueta: "Recomendado por" },
    fuente_reclutamiento: {
        tipo: "opcion", valores: FUENTES_RECLUTAMIENTO, porDefecto: "AveRH",
        etiqueta: "La fuente de reclutamiento"
    }
};

const ESQUEMA_NUEVO = {
    cedula: { tipo: "cedula", requerido: true, etiqueta: "La cédula" },
    ...CAMPOS_COMUNES,
    correo: { tipo: "correo", requerido: true, etiqueta: "El correo" },
    id_vacante: { tipo: "entero", requerido: true, min: 1, etiqueta: "La vacante" },
    fecha_postulacion: { tipo: "fecha", requerido: true, noFutura: true, etiqueta: "La fecha de postulación" }
};

// Al editar, algunos registros antiguos no tienen correo ni fecha:
// se permite guardarlos sin obligar a completarlos.
const ESQUEMA_EDICION = {
    ...CAMPOS_COMUNES,
    correo: { tipo: "correo", etiqueta: "El correo" },
    id_vacante: { tipo: "entero", min: 1, etiqueta: "La vacante" },
    fecha_postulacion: { tipo: "fecha", noFutura: true, etiqueta: "La fecha de postulación" }
};


const soloDigitos = texto => String(texto || "").replace(/\D/g, "");


async function cedulaRegistrada(cedula, idExcluido = 0) {

    const filas = await consultar(
        "SELECT 1 FROM candidatos WHERE REPLACE(cedula, '-', '') = ? AND id_candidato <> ? LIMIT 1",
        [soloDigitos(cedula), idExcluido]
    );

    return filas.length > 0;
}


async function obtenerVacanteAbierta(idVacante) {

    const [vacante] = await consultar(
        `SELECT v.id_vacante, v.estado, v.id_puesto, p.estado AS estado_puesto
         FROM vacantes v
         INNER JOIN puestos p ON p.id_puesto = v.id_puesto
         WHERE v.id_vacante = ?`,
        [idVacante]
    );

    if (!vacante) {
        throw solicitudInvalida("La vacante seleccionada no existe.", "id_vacante");
    }

    if (vacante.estado !== "Abierta") {
        throw solicitudInvalida("La vacante seleccionada está cerrada.", "id_vacante");
    }

    if (vacante.estado_puesto !== "Activo") {
        throw solicitudInvalida("El puesto de esta vacante está inactivo.", "id_vacante");
    }

    return vacante;
}


// --------------------------------------
// LISTADO
// --------------------------------------

router.get("/", async (req, res) => {

    const candidatos = await consultar(
        `${SQL_CANDIDATOS}
         ORDER BY COALESCE(c.fecha_actualizacion, c.fecha_postulacion) DESC, c.id_candidato DESC`
    );

    res.json({ correcto: true, datos: await adjuntarCompatibilidad(candidatos) });
});


// --------------------------------------
// FICHA COMPLETA
// --------------------------------------

router.get("/:id", async (req, res) => {

    const id = validarId(req.params.id, "El candidato");
    const candidato = await obtenerCandidato(id);

    const [competencias, idiomas, capacitaciones, experiencia, historial] = await Promise.all([

        consultar(
            `SELECT co.id_competencia, co.descripcion
             FROM candidato_competencias cc
             INNER JOIN competencias co ON co.id_competencia = cc.id_competencia
             WHERE cc.id_candidato = ?
             ORDER BY co.descripcion`,
            [id]
        ),

        consultar(
            `SELECT i.id_idioma, i.nombre, ci.nivel
             FROM candidato_idiomas ci
             INNER JOIN idiomas i ON i.id_idioma = ci.id_idioma
             WHERE ci.id_candidato = ?
             ORDER BY FIELD(ci.nivel, 'Nativo', 'Avanzado', 'Intermedio', 'Básico'), i.nombre`,
            [id]
        ),

        consultar(
            `SELECT ca.id_capacitacion, ca.descripcion, ca.nivel, ca.fecha_desde, ca.fecha_hasta, ca.institucion
             FROM candidato_capacitaciones cca
             INNER JOIN capacitaciones ca ON ca.id_capacitacion = cca.id_capacitacion
             WHERE cca.id_candidato = ?
             ORDER BY ca.fecha_desde DESC`,
            [id]
        ),

        consultar(
            `SELECT id_experiencia, empresa, puesto_ocupado, fecha_desde, fecha_hasta, salario
             FROM experiencia_laboral
             WHERE id_candidato = ?
             ORDER BY COALESCE(fecha_hasta, '9999-12-31') DESC, fecha_desde DESC`,
            [id]
        ),

        consultar(
            `SELECT h.id_historial, h.etapa_anterior, h.etapa_nueva, h.observacion, h.fecha,
                    u.nombre AS usuario
             FROM proceso_historial h
             INNER JOIN proceso_seleccion ps ON ps.id_proceso = h.id_proceso
             LEFT JOIN usuarios u ON u.id_usuario = h.id_usuario
             WHERE ps.id_candidato = ?
             ORDER BY h.fecha DESC, h.id_historial DESC`,
            [id]
        )
    ]);

    // Requisitos de idiomas de su vacante y evaluación (solo informativa).
    const requisitos = (await requisitosDeVacantes([candidato.id_vacante])).get(candidato.id_vacante) || [];

    res.json({
        correcto: true,
        datos: {
            ...candidato, competencias, idiomas, capacitaciones, experiencia, historial,
            compatibilidad_idiomas: evaluarIdiomas(requisitos, idiomas)
        }
    });
});


// --------------------------------------
// REGISTRAR
// Crea el candidato y su proceso de selección
// en la misma transacción.
// --------------------------------------

router.post("/", async (req, res) => {

    const datos = validar(req.body, ESQUEMA_NUEVO);

    if (await cedulaRegistrada(datos.cedula)) {
        throw conflicto("Ya existe un candidato registrado con esta cédula.", "cedula");
    }

    const vacante = await obtenerVacanteAbierta(datos.id_vacante);
    const puesto = await obtenerPuesto(vacante.id_puesto);

    comprobarRangoSalarial(datos.salario_aspira, puesto);

    const idCandidato = await transaccion(async q => {

        const resultado = await q(
            `INSERT INTO candidatos (
                cedula, nombre, correo, telefono, id_puesto, departamento,
                salario_aspira, recomendado_por, fuente_reclutamiento,
                fecha_postulacion, estado, fecha_actualizacion
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Activo', NOW())`,
            [
                datos.cedula, datos.nombre, datos.correo, datos.telefono,
                puesto.id_puesto, puesto.departamento, datos.salario_aspira,
                datos.recomendado_por, datos.fuente_reclutamiento, datos.fecha_postulacion
            ]
        );

        const proceso = await q(
            `INSERT INTO proceso_seleccion (id_candidato, id_vacante, fecha_proceso, resultado, observaciones)
             VALUES (?, ?, CURDATE(), 'Postulado', 'Candidato registrado en AveRH.')`,
            [resultado.insertId, vacante.id_vacante]
        );

        await registrarHistorial(q, {
            idProceso: proceso.insertId,
            anterior: null,
            nueva: "Postulado",
            observacion: "Registro del candidato",
            idUsuario: req.usuario.id
        });

        return resultado.insertId;
    });

    console.log(`Candidato registrado por ${req.usuario.correo}: ${datos.nombre} (ID ${idCandidato})`);

    res.status(201).json({
        correcto: true,
        mensaje: "Candidato registrado correctamente.",
        datos: await obtenerCandidato(idCandidato)
    });
});


// --------------------------------------
// EDITAR DATOS PERSONALES Y POSTULACIÓN
// --------------------------------------

router.put("/:id", async (req, res) => {

    const id = validarId(req.params.id, "El candidato");
    const actual = await obtenerCandidato(id);
    const datos = validar(req.body, ESQUEMA_EDICION);

    // Cédula: solo se valida si cambia (hay registros antiguos
    // con cédulas de prueba que no superan la verificación).
    let cedula = actual.cedula;

    if (req.body?.cedula !== undefined && soloDigitos(req.body.cedula) !== soloDigitos(actual.cedula)) {

        ({ cedula } = validar(req.body, {
            cedula: { tipo: "cedula", requerido: true, etiqueta: "La cédula" }
        }));

        if (await cedulaRegistrada(cedula, id)) {
            throw conflicto("Ya existe otro candidato con esta cédula.", "cedula");
        }

        if (actual.id_empleado) {
            throw solicitudInvalida("No se puede cambiar la cédula de un candidato contratado.", "cedula");
        }
    }

    // Cambio de vacante (y, con ella, de puesto).
    let idPuesto = actual.id_puesto;
    let cambiaVacante = false;

    if (datos.id_vacante && datos.id_vacante !== actual.id_vacante) {

        if (["Contratado", "Descartado"].includes(actual.etapa)) {
            throw solicitudInvalida(
                "No se puede cambiar la vacante de un proceso que ya terminó.",
                "id_vacante"
            );
        }

        const vacante = await obtenerVacanteAbierta(datos.id_vacante);

        idPuesto = vacante.id_puesto;
        cambiaVacante = true;
    }

    const puesto = await obtenerPuesto(idPuesto);

    // El rango solo se exige si cambia el salario o el puesto.
    if (datos.salario_aspira !== Number(actual.salario_aspira) || idPuesto !== actual.id_puesto) {
        comprobarRangoSalarial(datos.salario_aspira, puesto);
    }

    await transaccion(async q => {

        await q(
            `UPDATE candidatos SET
                cedula = ?, nombre = ?, correo = ?, telefono = ?,
                id_puesto = ?, departamento = ?, salario_aspira = ?,
                recomendado_por = ?, fuente_reclutamiento = ?,
                fecha_postulacion = COALESCE(?, fecha_postulacion),
                fecha_actualizacion = NOW()
             WHERE id_candidato = ?`,
            [
                cedula, datos.nombre, datos.correo, datos.telefono,
                puesto.id_puesto, puesto.departamento, datos.salario_aspira,
                datos.recomendado_por, datos.fuente_reclutamiento,
                datos.fecha_postulacion, id
            ]
        );

        if (cambiaVacante && actual.id_proceso) {

            await q(
                "UPDATE proceso_seleccion SET id_vacante = ? WHERE id_proceso = ?",
                [datos.id_vacante, actual.id_proceso]
            );

            await registrarHistorial(q, {
                idProceso: actual.id_proceso,
                anterior: actual.etapa,
                nueva: actual.etapa,
                observacion: `Cambio de vacante a ${puesto.nombre}`,
                idUsuario: req.usuario.id
            });
        }
    });

    res.json({
        correcto: true,
        mensaje: "Candidato actualizado correctamente.",
        datos: await obtenerCandidato(id)
    });
});


// --------------------------------------
// PERFIL PROFESIONAL
// Reemplaza competencias, idiomas y capacitaciones
// en una transacción.
// --------------------------------------

router.put("/:id/perfil", async (req, res) => {

    const id = validarId(req.params.id, "El candidato");
    await obtenerCandidato(id);

    const { competencias, capacitaciones, idiomas } = req.body || {};

    const listaDeIds = valor =>
        Array.isArray(valor) && valor.every(x => Number.isInteger(x) && x > 0);

    if (
        !listaDeIds(competencias) ||
        !listaDeIds(capacitaciones) ||
        !Array.isArray(idiomas) ||
        !idiomas.every(x => Number.isInteger(x?.id) && x.id > 0 && NIVELES_IDIOMA.includes(x.nivel))
    ) {
        throw solicitudInvalida("Los datos del perfil profesional no son válidos.");
    }

    if (new Set(idiomas.map(x => x.id)).size !== idiomas.length) {
        throw solicitudInvalida("Un idioma no puede aparecer dos veces.");
    }

    await transaccion(async q => {

        await q("DELETE FROM candidato_competencias WHERE id_candidato = ?", [id]);
        await q("DELETE FROM candidato_capacitaciones WHERE id_candidato = ?", [id]);
        await q("DELETE FROM candidato_idiomas WHERE id_candidato = ?", [id]);

        for (const idCompetencia of new Set(competencias)) {
            await q("INSERT INTO candidato_competencias (id_candidato, id_competencia) VALUES (?, ?)", [id, idCompetencia]);
        }

        for (const idCapacitacion of new Set(capacitaciones)) {
            await q("INSERT INTO candidato_capacitaciones (id_candidato, id_capacitacion) VALUES (?, ?)", [id, idCapacitacion]);
        }

        for (const idioma of idiomas) {
            await q("INSERT INTO candidato_idiomas (id_candidato, id_idioma, nivel) VALUES (?, ?, ?)", [id, idioma.id, idioma.nivel]);
        }

        await marcarActualizado(q, id);
    });

    res.json({ correcto: true, mensaje: "Perfil profesional actualizado correctamente." });
});


// --------------------------------------
// ELIMINAR (solo administrador)
// No se elimina a quien ya fue contratado.
// --------------------------------------

router.delete("/:id", soloAdministrador, async (req, res) => {

    const id = validarId(req.params.id, "El candidato");
    const candidato = await obtenerCandidato(id);

    if (candidato.id_empleado) {
        throw conflicto("Este candidato ya fue contratado: no se puede eliminar porque está vinculado a un empleado.");
    }

    await transaccion(async q => {
        await q("DELETE FROM candidato_competencias WHERE id_candidato = ?", [id]);
        await q("DELETE FROM candidato_capacitaciones WHERE id_candidato = ?", [id]);
        await q("DELETE FROM candidato_idiomas WHERE id_candidato = ?", [id]);
        await q("DELETE FROM experiencia_laboral WHERE id_candidato = ?", [id]);
        await q("DELETE FROM proceso_seleccion WHERE id_candidato = ?", [id]);
        await q("DELETE FROM candidatos WHERE id_candidato = ?", [id]);
    });

    console.log(`Candidato ${id} (${candidato.nombre}) eliminado por ${req.usuario.correo}`);

    res.json({ correcto: true, mensaje: "Candidato eliminado correctamente." });
});


module.exports = router;
