// ==========================================
// AveRH - Catálogos
// Departamentos, competencias, idiomas, capacitaciones,
// puestos y vacantes.
// ==========================================

const { consultar } = require("../db");
const { crearRutasCatalogo } = require("./fabricaCatalogo");
const { leerRequisitos, guardarRequisitos } = require("../servicios/idiomas");
const { solicitudInvalida } = require("../utilidades/errores");
const {
    NIVELES_CAPACITACION,
    NIVELES_RIESGO,
    ESTADOS_VACANTE
} = require("../utilidades/constantes");


const departamentos = crearRutasCatalogo({
    tabla: "departamentos",
    id: "id_departamento",
    singular: "departamento",
    campoUnico: "nombre",
    esquema: {
        nombre: { tipo: "texto", requerido: true, min: 2, max: 100, etiqueta: "El nombre" }
    },
    consulta: `
        SELECT d.*,
            (SELECT COUNT(*) FROM puestos p WHERE p.id_departamento = d.id_departamento) AS puestos
        FROM departamentos d
    `,
    orden: "x.nombre"
});


const competencias = crearRutasCatalogo({
    tabla: "competencias",
    id: "id_competencia",
    singular: "competencia",
    femenino: true,
    campoUnico: "descripcion",
    esquema: {
        descripcion: { tipo: "texto", requerido: true, min: 2, max: 255, etiqueta: "La descripción" }
    },
    consulta: `
        SELECT c.*,
            (SELECT COUNT(*) FROM candidato_competencias cc WHERE cc.id_competencia = c.id_competencia) AS candidatos
        FROM competencias c
    `,
    orden: "x.descripcion"
});


const idiomas = crearRutasCatalogo({
    tabla: "idiomas",
    id: "id_idioma",
    singular: "idioma",
    campoUnico: "nombre",
    esquema: {
        nombre: { tipo: "texto", requerido: true, min: 2, max: 100, etiqueta: "El nombre" }
    },
    consulta: `
        SELECT i.*,
            (SELECT COUNT(*) FROM candidato_idiomas ci WHERE ci.id_idioma = i.id_idioma) AS candidatos
        FROM idiomas i
    `,
    orden: "x.nombre"
});


const capacitaciones = crearRutasCatalogo({
    tabla: "capacitaciones",
    id: "id_capacitacion",
    singular: "capacitación",
    femenino: true,
    campoUnico: "descripcion",
    esquema: {
        descripcion: { tipo: "texto", requerido: true, min: 3, max: 255, etiqueta: "La descripción" },
        nivel: { tipo: "opcion", requerido: true, valores: NIVELES_CAPACITACION, etiqueta: "El nivel" },
        fecha_desde: { tipo: "fecha", requerido: true, noFutura: true, etiqueta: "La fecha de inicio" },
        fecha_hasta: { tipo: "fecha", requerido: true, etiqueta: "La fecha de finalización" },
        institucion: { tipo: "texto", requerido: true, min: 2, max: 150, etiqueta: "La institución" }
    },
    consulta: `
        SELECT c.*,
            (SELECT COUNT(*) FROM candidato_capacitaciones cc WHERE cc.id_capacitacion = c.id_capacitacion) AS candidatos
        FROM capacitaciones c
    `,
    orden: "x.descripcion",
    async validarExtra(datos) {
        if (datos.fecha_hasta < datos.fecha_desde) {
            throw solicitudInvalida(
                "La fecha de finalización no puede ser anterior a la de inicio.",
                "fecha_hasta"
            );
        }
    }
});


async function comprobarDepartamento(idDepartamento) {

    const [departamento] = await consultar(
        "SELECT estado FROM departamentos WHERE id_departamento = ?",
        [idDepartamento]
    );

    if (!departamento) {
        throw solicitudInvalida("El departamento seleccionado no existe.", "id_departamento");
    }
}

const puestos = crearRutasCatalogo({
    tabla: "puestos",
    id: "id_puesto",
    singular: "puesto",
    campoUnico: "nombre",
    esquema: {
        nombre: { tipo: "texto", requerido: true, min: 3, max: 100, etiqueta: "El nombre" },
        id_departamento: { tipo: "entero", requerido: true, min: 1, etiqueta: "El departamento" },
        descripcion: { tipo: "texto", max: 255, etiqueta: "La descripción" },
        nivel_riesgo: { tipo: "opcion", requerido: true, valores: NIVELES_RIESGO, etiqueta: "El nivel de riesgo" },
        salario_minimo: { tipo: "decimal", requerido: true, min: 1, max: 99999999, etiqueta: "El salario mínimo" },
        salario_maximo: { tipo: "decimal", requerido: true, min: 1, max: 99999999, etiqueta: "El salario máximo" }
    },
    consulta: `
        SELECT p.*,
            d.nombre AS departamento,
            (SELECT COUNT(*) FROM candidatos c WHERE c.id_puesto = p.id_puesto) AS candidatos,
            (SELECT COUNT(*) FROM empleados e WHERE e.id_puesto = p.id_puesto AND e.estado = 'Activo') AS empleados,
            (SELECT COUNT(*) FROM vacantes v WHERE v.id_puesto = p.id_puesto AND v.estado = 'Abierta') AS vacantes_abiertas
        FROM puestos p
        LEFT JOIN departamentos d ON d.id_departamento = p.id_departamento
    `,
    orden: "x.nombre",
    async validarExtra(datos) {

        if (datos.salario_minimo > datos.salario_maximo) {
            throw solicitudInvalida(
                "El salario mínimo no puede ser mayor que el máximo.",
                "salario_minimo"
            );
        }

        await comprobarDepartamento(datos.id_departamento);
    }
});


const vacantes = crearRutasCatalogo({
    tabla: "vacantes",
    id: "id_vacante",
    singular: "vacante",
    femenino: true,
    estados: ESTADOS_VACANTE,
    esquema: {
        id_puesto: { tipo: "entero", requerido: true, min: 1, etiqueta: "El puesto" },
        titulo: { tipo: "texto", requerido: true, min: 3, max: 100, etiqueta: "El título" },
        descripcion: { tipo: "texto", max: 255, etiqueta: "La descripción" },
        salario_minimo: { tipo: "decimal", min: 1, max: 99999999, etiqueta: "El salario mínimo" },
        salario_maximo: { tipo: "decimal", min: 1, max: 99999999, etiqueta: "El salario máximo" },
        experiencia_minima: { tipo: "decimal", min: 0, max: 50, porDefecto: 0, etiqueta: "La experiencia mínima" },
        cantidad_vacantes: { tipo: "entero", requerido: true, min: 1, max: 999, etiqueta: "La cantidad de plazas" },
        fecha_publicacion: { tipo: "fecha", requerido: true, etiqueta: "La fecha de publicación" },
        fecha_cierre: { tipo: "fecha", etiqueta: "La fecha de cierre" }
    },
    consulta: `
        SELECT v.*,
            p.nombre AS puesto,
            p.salario_minimo AS puesto_salario_minimo,
            p.salario_maximo AS puesto_salario_maximo,
            p.estado AS puesto_estado,
            d.nombre AS departamento,
            (SELECT COUNT(*) FROM proceso_seleccion ps WHERE ps.id_vacante = v.id_vacante) AS postulantes,
            (SELECT COUNT(*) FROM proceso_seleccion ps
                WHERE ps.id_vacante = v.id_vacante AND ps.resultado = 'Contratado') AS contratados,
            (SELECT JSON_ARRAYAGG(JSON_OBJECT('id_idioma', vi.id_idioma, 'idioma', i.nombre, 'nivel', vi.nivel_minimo))
             FROM vacante_idiomas vi
             INNER JOIN idiomas i ON i.id_idioma = vi.id_idioma
             WHERE vi.id_vacante = v.id_vacante) AS requisitos_idiomas
        FROM vacantes v
        INNER JOIN puestos p ON p.id_puesto = v.id_puesto
        LEFT JOIN departamentos d ON d.id_departamento = p.id_departamento
    `,
    orden: "x.estado ASC, x.fecha_publicacion DESC",
    // Requisitos de idiomas: se guardan con la vacante en una transacción.
    leerRelacionados: leerRequisitos,
    guardarRelacionados: guardarRequisitos,
    async validarExtra(datos) {

        const [puesto] = await consultar(
            "SELECT salario_minimo, salario_maximo FROM puestos WHERE id_puesto = ?",
            [datos.id_puesto]
        );

        if (!puesto) {
            throw solicitudInvalida("El puesto seleccionado no existe.", "id_puesto");
        }

        if (
            datos.salario_minimo !== null &&
            datos.salario_maximo !== null &&
            datos.salario_minimo > datos.salario_maximo
        ) {
            throw solicitudInvalida("El salario mínimo no puede ser mayor que el máximo.", "salario_minimo");
        }

        // La oferta salarial debe respetar el rango del puesto.
        for (const campo of ["salario_minimo", "salario_maximo"]) {

            const valor = datos[campo];

            if (
                valor !== null &&
                (valor < Number(puesto.salario_minimo) || valor > Number(puesto.salario_maximo))
            ) {
                throw solicitudInvalida(
                    `El salario debe estar dentro del rango del puesto (RD$ ${Number(puesto.salario_minimo).toLocaleString("en-US")} – RD$ ${Number(puesto.salario_maximo).toLocaleString("en-US")}).`,
                    campo
                );
            }
        }

        if (datos.fecha_cierre && datos.fecha_cierre < datos.fecha_publicacion) {
            throw solicitudInvalida("La fecha de cierre no puede ser anterior a la de publicación.", "fecha_cierre");
        }
    }
});


module.exports = {
    departamentos,
    competencias,
    idiomas,
    capacitaciones,
    puestos,
    vacantes
};
