// ==========================================
// AveRH - Empleados
// Normalmente se crean al contratar a un candidato
// (ver rutas/proceso.js); también se pueden registrar
// directamente.
// ==========================================

const express = require("express");

const { consultar } = require("../db");
const { validar, validarId, NOMBRE_PERSONA } = require("../utilidades/validacion");
const { noEncontrado, conflicto, solicitudInvalida } = require("../utilidades/errores");
const { ESTADOS } = require("../utilidades/constantes");
const { soloAdministrador } = require("../middleware/seguridad");
const { obtenerPuesto, comprobarRangoSalarial } = require("../servicios/candidatos");

const router = express.Router();


const SQL_EMPLEADOS = `
    SELECT e.id_empleado AS id, e.id_candidato, e.cedula, e.nombre, e.fecha_ingreso,
           e.id_puesto, p.nombre AS puesto, p.id_departamento,
           COALESCE(d.nombre, e.departamento) AS departamento,
           p.salario_minimo AS puesto_salario_minimo, p.salario_maximo AS puesto_salario_maximo,
           e.salario_mensual, e.estado,
           TIMESTAMPDIFF(MONTH, e.fecha_ingreso, CURDATE()) AS meses_antiguedad
    FROM empleados e
    LEFT JOIN puestos p ON p.id_puesto = e.id_puesto
    LEFT JOIN departamentos d ON d.id_departamento = p.id_departamento
`;

const CAMPOS = {
    nombre: {
        tipo: "texto", requerido: true, min: 3, max: 150,
        patron: NOMBRE_PERSONA, mensajePatron: "solo puede contener letras y espacios.",
        etiqueta: "El nombre"
    },
    fecha_ingreso: { tipo: "fecha", requerido: true, etiqueta: "La fecha de ingreso" },
    id_puesto: { tipo: "entero", requerido: true, min: 1, etiqueta: "El puesto" },
    salario_mensual: { tipo: "decimal", requerido: true, min: 1, max: 99999999, etiqueta: "El salario mensual" }
};


async function obtenerEmpleado(id) {

    const [empleado] = await consultar(`${SQL_EMPLEADOS} WHERE e.id_empleado = ?`, [id]);

    if (!empleado) {
        throw noEncontrado("El empleado no existe.");
    }

    return empleado;
}


async function cedulaDeEmpleado(cedula, idExcluido = 0) {

    const filas = await consultar(
        "SELECT 1 FROM empleados WHERE REPLACE(cedula, '-', '') = REPLACE(?, '-', '') AND id_empleado <> ?",
        [cedula, idExcluido]
    );

    return filas.length > 0;
}


router.get("/", async (req, res) => {

    const empleados = await consultar(
        `${SQL_EMPLEADOS} ORDER BY e.estado ASC, e.fecha_ingreso DESC, e.nombre ASC`
    );

    res.json({ correcto: true, datos: empleados });
});


router.get("/:id", async (req, res) => {

    res.json({
        correcto: true,
        datos: await obtenerEmpleado(validarId(req.params.id, "El empleado"))
    });
});


router.post("/", async (req, res) => {

    const datos = validar(req.body, {
        cedula: { tipo: "cedula", requerido: true, etiqueta: "La cédula" },
        ...CAMPOS
    });

    if (await cedulaDeEmpleado(datos.cedula)) {
        throw conflicto("Ya existe un empleado con esta cédula.", "cedula");
    }

    const puesto = await obtenerPuesto(datos.id_puesto);

    if (puesto.estado !== "Activo") {
        throw solicitudInvalida("El puesto seleccionado está inactivo.", "id_puesto");
    }

    comprobarRangoSalarial(datos.salario_mensual, puesto, "salario_mensual");

    // Si la persona ya está registrada como candidato, se enlaza.
    const [candidato] = await consultar(
        `SELECT c.id_candidato FROM candidatos c
         LEFT JOIN empleados e ON e.id_candidato = c.id_candidato
         WHERE REPLACE(c.cedula, '-', '') = REPLACE(?, '-', '') AND e.id_empleado IS NULL`,
        [datos.cedula]
    );

    const resultado = await consultar(
        `INSERT INTO empleados (id_candidato, cedula, nombre, fecha_ingreso, departamento, id_puesto, salario_mensual, estado)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'Activo')`,
        [
            candidato?.id_candidato || null, datos.cedula, datos.nombre, datos.fecha_ingreso,
            puesto.departamento, puesto.id_puesto, datos.salario_mensual
        ]
    );

    res.status(201).json({
        correcto: true,
        mensaje: "Empleado registrado correctamente.",
        datos: await obtenerEmpleado(resultado.insertId)
    });
});


router.put("/:id", async (req, res) => {

    const id = validarId(req.params.id, "El empleado");
    const actual = await obtenerEmpleado(id);
    const datos = validar(req.body, CAMPOS);

    const puesto = await obtenerPuesto(datos.id_puesto);

    if (datos.id_puesto !== actual.id_puesto && puesto.estado !== "Activo") {
        throw solicitudInvalida("El puesto seleccionado está inactivo.", "id_puesto");
    }

    // El rango solo se exige si cambian el salario o el puesto.
    if (datos.salario_mensual !== Number(actual.salario_mensual) || datos.id_puesto !== actual.id_puesto) {
        comprobarRangoSalarial(datos.salario_mensual, puesto, "salario_mensual");
    }

    await consultar(
        `UPDATE empleados
         SET nombre = ?, fecha_ingreso = ?, id_puesto = ?, departamento = ?, salario_mensual = ?
         WHERE id_empleado = ?`,
        [datos.nombre, datos.fecha_ingreso, puesto.id_puesto, puesto.departamento, datos.salario_mensual, id]
    );

    res.json({
        correcto: true,
        mensaje: "Empleado actualizado correctamente.",
        datos: await obtenerEmpleado(id)
    });
});


router.patch("/:id/estado", async (req, res) => {

    const id = validarId(req.params.id, "El empleado");
    await obtenerEmpleado(id);

    const { estado } = validar(req.body, {
        estado: { tipo: "opcion", requerido: true, valores: ESTADOS, etiqueta: "El estado" }
    });

    await consultar("UPDATE empleados SET estado = ? WHERE id_empleado = ?", [estado, id]);

    res.json({
        correcto: true,
        mensaje: estado === "Activo" ? "Empleado activado." : "Empleado desactivado.",
        datos: await obtenerEmpleado(id)
    });
});


router.delete("/:id", soloAdministrador, async (req, res) => {

    const id = validarId(req.params.id, "El empleado");
    const empleado = await obtenerEmpleado(id);

    await consultar("DELETE FROM empleados WHERE id_empleado = ?", [id]);

    console.log(`Empleado ${id} (${empleado.nombre}) eliminado por ${req.usuario.correo}`);

    res.json({ correcto: true, mensaje: "Empleado eliminado del registro." });
});


module.exports = router;
