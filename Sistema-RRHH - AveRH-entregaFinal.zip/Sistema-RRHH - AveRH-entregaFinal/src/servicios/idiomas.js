// ==========================================
// AveRH - Requisitos de idiomas y compatibilidad
//
// Cada vacante exige un nivel MÍNIMO por idioma.
// Jerarquía: No requerido < Básico < Intermedio < Avanzado < Nativo.
//
// La evaluación es informativa: ayuda al reclutador, pero
// nunca descarta automáticamente a un candidato.
// ==========================================

const { consultar } = require("../db");
const { solicitudInvalida } = require("../utilidades/errores");

const ORDEN_NIVEL = { "Básico": 1, "Intermedio": 2, "Avanzado": 3, "Nativo": 4 };


// Lee y valida body.idiomas: [{ id_idioma, nivel }].
// "No requerido" (o vacío) equivale a no incluir el idioma.
// Devuelve null si el cuerpo no trae idiomas (no se modifican).
function leerRequisitos(body) {

    const lista = body?.idiomas;

    if (lista === undefined) {
        return null;
    }

    if (!Array.isArray(lista) || lista.length > 50) {
        throw solicitudInvalida("Los requisitos de idiomas no son válidos.", "idiomas");
    }

    const requisitos = [];
    const vistos = new Set();

    for (const item of lista) {

        const idIdioma = Number(item?.id_idioma);
        const nivel = item?.nivel;

        if (!Number.isInteger(idIdioma) || idIdioma < 1) {
            throw solicitudInvalida("Uno de los idiomas no es válido.", "idiomas");
        }

        if (nivel === "No requerido" || nivel === "" || nivel === null || nivel === undefined) {
            continue;
        }

        if (!ORDEN_NIVEL[nivel]) {
            throw solicitudInvalida("Uno de los niveles de idioma no es válido.", "idiomas");
        }

        if (vistos.has(idIdioma)) {
            throw solicitudInvalida("Un idioma no puede aparecer dos veces en los requisitos.", "idiomas");
        }

        vistos.add(idIdioma);
        requisitos.push({ id_idioma: idIdioma, nivel });
    }

    return requisitos;
}


// Reemplaza los requisitos de la vacante (dentro de una transacción)
// y mantiene vacantes.nivel_ingles sincronizado por compatibilidad.
async function guardarRequisitos(q, idVacante, requisitos) {

    if (requisitos === null) {
        return;
    }

    await q("DELETE FROM vacante_idiomas WHERE id_vacante = ?", [idVacante]);

    for (const r of requisitos) {
        await q(
            "INSERT INTO vacante_idiomas (id_vacante, id_idioma, nivel_minimo) VALUES (?, ?, ?)",
            [idVacante, r.id_idioma, r.nivel]
        );
    }

    await q(
        `UPDATE vacantes SET nivel_ingles = COALESCE((
            SELECT vi.nivel_minimo FROM vacante_idiomas vi
            INNER JOIN idiomas i ON i.id_idioma = vi.id_idioma
            WHERE vi.id_vacante = ? AND i.nombre = 'Inglés'
        ), 'No requerido')
        WHERE id_vacante = ?`,
        [idVacante, idVacante]
    );
}


// Compara los idiomas del candidato con los requisitos de su vacante.
//   cumple            → tiene el idioma con nivel ≥ al exigido
//   no_cumple         → tiene el idioma, pero con nivel inferior
//   sin_informacion   → el idioma no consta en su perfil
function evaluarIdiomas(requisitos, idiomasCandidato) {

    const detalle = requisitos.map(requisito => {

        const propio = idiomasCandidato.find(i => i.id_idioma === requisito.id_idioma);

        let resultado = "sin_informacion";

        if (propio) {
            resultado = ORDEN_NIVEL[propio.nivel] >= ORDEN_NIVEL[requisito.nivel] ? "cumple" : "no_cumple";
        }

        return {
            id_idioma: requisito.id_idioma,
            idioma: requisito.idioma,
            nivel_requerido: requisito.nivel,
            nivel_candidato: propio?.nivel || null,
            resultado
        };
    });

    const cuenta = tipo => detalle.filter(d => d.resultado === tipo).length;

    const resumen = {
        total: detalle.length,
        cumple: cuenta("cumple"),
        no_cumple: cuenta("no_cumple"),
        sin_informacion: cuenta("sin_informacion")
    };

    resumen.estado =
        resumen.total === 0 ? "sin_requisitos"
            : resumen.no_cumple > 0 ? "no_cumple"
                : resumen.sin_informacion > 0 ? "incompleto"
                    : "cumple";

    return { ...resumen, detalle };
}


async function requisitosDeVacantes(idsVacantes) {

    const ids = [...new Set(idsVacantes.filter(Boolean))];

    if (ids.length === 0) {
        return new Map();
    }

    const filas = await consultar(
        `SELECT vi.id_vacante, vi.id_idioma, i.nombre AS idioma, vi.nivel_minimo AS nivel
         FROM vacante_idiomas vi
         INNER JOIN idiomas i ON i.id_idioma = vi.id_idioma
         WHERE vi.id_vacante IN (?)
         ORDER BY FIELD(vi.nivel_minimo, 'Nativo', 'Avanzado', 'Intermedio', 'Básico'), i.nombre`,
        [ids]
    );

    const mapa = new Map();

    for (const fila of filas) {
        if (!mapa.has(fila.id_vacante)) mapa.set(fila.id_vacante, []);
        mapa.get(fila.id_vacante).push(fila);
    }

    return mapa;
}


// Añade compatibilidad_idiomas a una lista de candidatos
// (con dos consultas en total, no una por candidato).
async function adjuntarCompatibilidad(candidatos) {

    if (candidatos.length === 0) {
        return candidatos;
    }

    const requisitos = await requisitosDeVacantes(candidatos.map(c => c.id_vacante));

    const filas = await consultar(
        "SELECT id_candidato, id_idioma, nivel FROM candidato_idiomas WHERE id_candidato IN (?)",
        [candidatos.map(c => c.id)]
    );

    const idiomasPorCandidato = new Map();

    for (const fila of filas) {
        if (!idiomasPorCandidato.has(fila.id_candidato)) idiomasPorCandidato.set(fila.id_candidato, []);
        idiomasPorCandidato.get(fila.id_candidato).push(fila);
    }

    for (const candidato of candidatos) {
        candidato.compatibilidad_idiomas = evaluarIdiomas(
            requisitos.get(candidato.id_vacante) || [],
            idiomasPorCandidato.get(candidato.id) || []
        );
    }

    return candidatos;
}


module.exports = {
    ORDEN_NIVEL,
    leerRequisitos,
    guardarRequisitos,
    evaluarIdiomas,
    requisitosDeVacantes,
    adjuntarCompatibilidad
};
