// ==========================================
// AveRH - Libros de Excel (.xlsx)
//
// Genera archivos .xlsx nativos: columnas reales, encabezados con
// la identidad de AveRH, anchos ajustados, fechas y salarios con
// formato, autofiltro, paneles inmovilizados y totales que se
// recalculan al filtrar en Excel.
// ==========================================

const ExcelJS = require("exceljs");

const COLOR = {
    petroleo: "FF0F2C3D",
    pizarra: "FF2D4F56",
    salvia: "FF547A6E",
    marfil: "FFF7F2E8",
    arena: "FFD4C8B5",
    texto: "FF1F2A30",
    suave: "FF6B7570"
};

const FORMATOS = {
    texto: "@",
    fecha: "dd/mm/yyyy",
    dinero: '"RD$" #,##0.00',
    entero: "#,##0",
    decimal: "#,##0.0",
    porcentaje: "0.0%"
};

const TIPOS = Object.keys(FORMATOS);


// "AAAA-MM-DD" → fecha de Excel (sin desfase de zona horaria).
function convertirValor(valor, tipo) {

    if (valor === null || valor === undefined || valor === "") {
        return null;
    }

    switch (tipo) {

        case "fecha": {
            const texto = String(valor).slice(0, 10);
            if (!/^\d{4}-\d{2}-\d{2}$/.test(texto)) return String(valor);
            const [a, m, d] = texto.split("-").map(Number);
            return new Date(Date.UTC(a, m - 1, d));
        }

        case "dinero":
        case "entero":
        case "decimal": {
            const numero = Number(valor);
            return Number.isFinite(numero) ? numero : String(valor);
        }

        case "porcentaje": {
            // AveRH envía porcentajes de 0 a 100.
            const numero = Number(valor);
            return Number.isFinite(numero) ? numero / 100 : String(valor);
        }

        default:
            return String(valor);
    }
}


function anchoSugerido(columna, filas, indice) {

    if (columna.ancho) {
        return columna.ancho;
    }

    const minimo = { fecha: 12, dinero: 15, entero: 10, decimal: 10, porcentaje: 11 }[columna.tipo] || 10;
    const largo = Math.max(
        String(columna.titulo).length,
        ...filas.slice(0, 500).map(f => String(f[indice] ?? "").length)
    );

    return Math.min(Math.max(minimo, largo + 3), 55);
}


const borde = { style: "thin", color: { argb: COLOR.arena } };
const bordes = { top: borde, left: borde, bottom: borde, right: borde };


// Escribe una tabla con encabezado, datos y totales a partir de la fila indicada.
function escribirTabla(hoja, filaInicio, columnas, filas) {

    const encabezado = hoja.getRow(filaInicio);

    columnas.forEach((columna, i) => {
        const celda = encabezado.getCell(i + 1);
        celda.value = columna.titulo;
        celda.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 11 };
        celda.fill = { type: "pattern", pattern: "solid", fgColor: { argb: COLOR.petroleo } };
        celda.alignment = { vertical: "middle", horizontal: columna.tipo && columna.tipo !== "texto" ? "center" : "left", wrapText: true };
        celda.border = bordes;
    });

    encabezado.height = 24;

    filas.forEach((fila, f) => {

        const filaExcel = hoja.getRow(filaInicio + 1 + f);

        columnas.forEach((columna, i) => {

            const celda = filaExcel.getCell(i + 1);
            const tipo = columna.tipo || "texto";

            celda.value = convertirValor(fila[i], tipo);
            celda.numFmt = FORMATOS[tipo];
            celda.border = bordes;
            celda.font = { color: { argb: COLOR.texto }, size: 10.5 };
            celda.alignment = { vertical: "middle", horizontal: ["dinero", "entero", "decimal", "porcentaje"].includes(tipo) ? "right" : (tipo === "fecha" ? "center" : "left") };

            if (f % 2 === 1) {
                celda.fill = { type: "pattern", pattern: "solid", fgColor: { argb: COLOR.marfil } };
            }
        });
    });

    const ultimaFila = filaInicio + filas.length;

    // Totales con SUBTOTAL: se recalculan al usar los filtros de Excel.
    if (filas.length && columnas.some(c => c.total)) {

        const filaTotal = hoja.getRow(ultimaFila + 1);

        filaTotal.getCell(1).value = "Total";

        columnas.forEach((columna, i) => {

            const celda = filaTotal.getCell(i + 1);

            if (columna.total) {
                const letra = hoja.getColumn(i + 1).letter;
                const funcion = columna.total === "promedio" ? 101 : (columna.total === "cuenta" ? 103 : 109);
                celda.value = { formula: `SUBTOTAL(${funcion},${letra}${filaInicio + 1}:${letra}${ultimaFila})` };
                celda.numFmt = FORMATOS[columna.tipo || "entero"];
                celda.alignment = { horizontal: "right" };
            }

            celda.font = { bold: true, color: { argb: COLOR.petroleo } };
            celda.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE8DFCD" } };
            celda.border = { top: { style: "medium", color: { argb: COLOR.petroleo } } };
        });
    }

    return ultimaFila;
}


function escribirCabecera(hoja, { titulo, subtitulo, generado }, columnasOcupadas) {

    hoja.getCell("A1").value = "AveRH · Reclutamiento y Selección";
    hoja.getCell("A1").font = { bold: true, size: 10, color: { argb: COLOR.salvia } };

    hoja.getCell("A2").value = titulo;
    hoja.getCell("A2").font = { bold: true, size: 16, color: { argb: COLOR.petroleo } };

    hoja.getCell("A3").value = [subtitulo, generado].filter(Boolean).join(" · ");
    hoja.getCell("A3").font = { italic: true, size: 10, color: { argb: COLOR.suave } };

    const ultima = hoja.getColumn(Math.max(columnasOcupadas, 1)).letter;

    hoja.mergeCells(`A2:${ultima}2`);
    hoja.mergeCells(`A3:${ultima}3`);
    hoja.getRow(2).height = 24;
}


// hojas: [{ nombre, columnas: [{ titulo, tipo, ancho, total }], filas: [[...]] }]
async function crearLibroExcel({ titulo, subtitulo = "", usuario = "", hojas }) {

    const libro = new ExcelJS.Workbook();

    libro.creator = "AveRH";
    libro.company = "AveRH";
    libro.title = titulo;
    libro.created = new Date();

    const ahora = new Date();
    const generado = `Generado el ${ahora.toLocaleDateString("es-DO")} a las ${ahora.toLocaleTimeString("es-DO", { hour: "2-digit", minute: "2-digit" })}${usuario ? ` por ${usuario}` : ""}`;

    const FILA_ENCABEZADO = 5;

    for (const definicion of hojas) {

        const hoja = libro.addWorksheet(definicion.nombre, {
            views: [{ state: "frozen", ySplit: FILA_ENCABEZADO, showGridLines: false }],
            pageSetup: {
                orientation: definicion.columnas.length > 5 ? "landscape" : "portrait",
                paperSize: 9,
                fitToPage: true,
                fitToWidth: 1,
                fitToHeight: 0,
                margins: { left: 0.4, right: 0.4, top: 0.5, bottom: 0.5, header: 0.2, footer: 0.2 }
            },
            headerFooter: { oddFooter: `&L${titulo}&RPágina &P de &N` }
        });

        escribirCabecera(hoja, { titulo: definicion.titulo || titulo, subtitulo, generado }, definicion.columnas.length);

        const ultimaFila = escribirTabla(hoja, FILA_ENCABEZADO, definicion.columnas, definicion.filas);

        definicion.columnas.forEach((columna, i) => {
            hoja.getColumn(i + 1).width = anchoSugerido(columna, definicion.filas, i);
        });

        if (definicion.filas.length) {
            hoja.autoFilter = {
                from: { row: FILA_ENCABEZADO, column: 1 },
                to: { row: ultimaFila, column: definicion.columnas.length }
            };
        } else {
            hoja.getCell(`A${FILA_ENCABEZADO + 1}`).value = "No hay registros para los filtros aplicados.";
            hoja.getCell(`A${FILA_ENCABEZADO + 1}`).font = { italic: true, color: { argb: COLOR.suave } };
        }

        hoja.pageSetup.printTitlesRow = `${FILA_ENCABEZADO}:${FILA_ENCABEZADO}`;
    }

    return libro.xlsx.writeBuffer();
}


module.exports = { crearLibroExcel, TIPOS };
