// ==========================================
// AveRH - Lógica compartida de candidatos
// La usan las rutas de candidatos, proceso,
// consultas y panel.
// ==========================================

const { consultar } = require("../db");
const { noEncontrado, solicitudInvalida } = require("../utilidades/errores");


// Años de experiencia: suma de los períodos laborales
// (un empleo sin fecha de fin cuenta hasta hoy).
const SQL_ANIOS_EXPERIENCIA = `
    (SELECT ROUND(COALESCE(SUM(
        DATEDIFF(COALESCE(el.fecha_hasta, CURDATE()), el.fecha_desde)
    ), 0) / 365.25, 1)
     FROM experiencia_laboral el
     WHERE el.id_candidato = c.id_candidato)
`;

// Consulta base: cada candidato con su puesto, departamento,
// proceso más reciente, vacante y (si existe) empleado.
const SQL_CANDIDATOS = `
    SELECT
        c.id_candidato AS id,
        c.cedula,
        c.nombre,
        c.correo,
        c.telefono,
        c.id_puesto,
        p.nombre AS puesto,
        p.id_departamento,
        COALESCE(d.nombre, c.departamento) AS departamento,
        p.salario_minimo AS puesto_salario_minimo,
        p.salario_maximo AS puesto_salario_maximo,
        c.salario_aspira,
        c.recomendado_por,
        c.fuente_reclutamiento,
        c.fecha_postulacion,
        c.estado,
        c.fecha_actualizacion,
        ps.id_proceso,
        ps.id_vacante,
        v.titulo AS vacante,
        COALESCE(ps.resultado, 'Postulado') AS etapa,
        ps.fecha_proceso,
        ps.observaciones,
        e.id_empleado,
        ${SQL_ANIOS_EXPERIENCIA} AS anios_experiencia
    FROM candidatos c
    LEFT JOIN puestos p ON p.id_puesto = c.id_puesto
    LEFT JOIN departamentos d ON d.id_departamento = p.id_departamento
    LEFT JOIN proceso_seleccion ps ON ps.id_proceso = (
        SELECT MAX(ps2.id_proceso)
        FROM proceso_seleccion ps2
        WHERE ps2.id_candidato = c.id_candidato
    )
    LEFT JOIN vacantes v ON v.id_vacante = ps.id_vacante
    LEFT JOIN empleados e ON e.id_candidato = c.id_candidato
`;


async function obtenerCandidato(id, consultarCon = consultar) {

    const [candidato] = await consultarCon(
        `${SQL_CANDIDATOS} WHERE c.id_candidato = ?`,
        [id]
    );

    if (!candidato) {
        throw noEncontrado("El candidato no existe.");
    }

    return candidato;
}


// Registra que el candidato se modificó (panel: "recientes").
async function marcarActualizado(consultarCon, idCandidato) {

    await consultarCon(
        "UPDATE candidatos SET fecha_actualizacion = NOW() WHERE id_candidato = ?",
        [idCandidato]
    );
}


async function obtenerPuesto(idPuesto, consultarCon = consultar) {

    const [puesto] = await consultarCon(
        `SELECT p.id_puesto, p.nombre, p.estado, p.salario_minimo, p.salario_maximo,
                d.nombre AS departamento
         FROM puestos p
         LEFT JOIN departamentos d ON d.id_departamento = p.id_departamento
         WHERE p.id_puesto = ?`,
        [idPuesto]
    );

    if (!puesto) {
        throw solicitudInvalida("El puesto seleccionado no existe.", "id_puesto");
    }

    return puesto;
}


const formatoDinero = valor =>
    `RD$ ${Number(valor).toLocaleString("en-US")}`;


// El salario debe estar dentro del rango del puesto.
function comprobarRangoSalarial(salario, puesto, campo = "salario_aspira") {

    const minimo = Number(puesto.salario_minimo);
    const maximo = Number(puesto.salario_maximo);

    if (salario < minimo || salario > maximo) {
        throw solicitudInvalida(
            `El salario debe estar entre ${formatoDinero(minimo)} y ${formatoDinero(maximo)} para el puesto ${puesto.nombre}.`,
            campo
        );
    }
}


async function registrarHistorial(consultarCon, { idProceso, anterior, nueva, observacion, idUsuario }) {

    await consultarCon(
        `INSERT INTO proceso_historial (id_proceso, etapa_anterior, etapa_nueva, observacion, id_usuario)
         VALUES (?, ?, ?, ?, ?)`,
        [idProceso, anterior, nueva, observacion || null, idUsuario || null]
    );
}


module.exports = {
    SQL_CANDIDATOS,
    obtenerCandidato,
    marcarActualizado,
    obtenerPuesto,
    comprobarRangoSalarial,
    registrarHistorial,
    formatoDinero
};
