// ==========================================
// AveRH - Conexión con MySQL
// Pool de conexiones: si una conexión se cae,
// el pool crea otra automáticamente.
// ==========================================

const mysql = require("mysql2/promise");

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    // Las fechas DATE se devuelven como texto "AAAA-MM-DD"
    // para evitar desfases por zona horaria.
    dateStrings: ["DATE"],
    decimalNumbers: true,
    charset: "utf8mb4"
});


// Ejecuta una consulta y devuelve las filas (o el resultado).
async function consultar(sql, parametros = []) {

    const [resultado] = await pool.query(sql, parametros);

    return resultado;
}


// Ejecuta una función dentro de una transacción.
// Si la función lanza un error, se revierte todo.
async function transaccion(funcion) {

    const conexion = await pool.getConnection();

    try {

        await conexion.beginTransaction();

        const consultarEnTransaccion = async (sql, parametros = []) => {
            const [resultado] = await conexion.query(sql, parametros);
            return resultado;
        };

        const resultado = await funcion(consultarEnTransaccion);

        await conexion.commit();

        return resultado;

    } catch (error) {

        await conexion.rollback().catch(() => {});

        throw error;

    } finally {

        conexion.release();
    }
}


async function comprobarConexion() {

    const filas = await consultar("SELECT DATABASE() AS base_datos");

    return filas[0].base_datos;
}


module.exports = {
    pool,
    consultar,
    transaccion,
    comprobarConexion
};
