// ==========================================
// AveRH - Sesión, roles y cabeceras de seguridad
// ==========================================

const { consultar } = require("../db");
const { ErrorHttp } = require("../utilidades/errores");

const NOMBRE_COOKIE_SESION = "averh.sid";


// --------------------------------------
// SESIÓN OBLIGATORIA
// El usuario se lee de MySQL en cada petición:
// si un administrador lo desactiva, pierde el
// acceso en su siguiente acción.
// --------------------------------------

async function requiereSesion(req, res, next) {

    const idUsuario = req.session?.idUsuario;

    if (!idUsuario) {
        throw new ErrorHttp(401, "Debes iniciar sesión.");
    }

    const filas = await consultar(
        `SELECT id_usuario, nombre, correo, rol, estado
         FROM usuarios
         WHERE id_usuario = ?
         LIMIT 1`,
        [idUsuario]
    );

    if (filas.length === 0 || filas[0].estado !== "Activo") {

        await new Promise(resolve => req.session.destroy(resolve));

        res.clearCookie(NOMBRE_COOKIE_SESION);

        throw new ErrorHttp(401, "Tu sesión ya no es válida. Vuelve a iniciar sesión.");
    }

    req.usuario = {
        id: filas[0].id_usuario,
        nombre: filas[0].nombre,
        correo: filas[0].correo,
        rol: filas[0].rol
    };

    next();
}


// --------------------------------------
// ROL OBLIGATORIO
// --------------------------------------

function requiereRol(...roles) {

    return (req, res, next) => {

        if (!req.usuario || !roles.includes(req.usuario.rol)) {
            throw new ErrorHttp(403, "No tienes permiso para realizar esta acción.");
        }

        next();
    };
}

const soloAdministrador = requiereRol("Administrador");


// --------------------------------------
// PROTECCIÓN CSRF
// Las peticiones que modifican datos deben enviarse
// como JSON: un formulario de otro sitio no puede
// hacerlo sin pasar por CORS.
// --------------------------------------

function exigeJson(req, res, next) {

    const modifica = !["GET", "HEAD", "OPTIONS"].includes(req.method);

    if (modifica && !req.is("application/json")) {
        throw new ErrorHttp(415, "Las peticiones deben enviarse en formato JSON.");
    }

    next();
}


// --------------------------------------
// CABECERAS DE SEGURIDAD
// --------------------------------------

function cabecerasSeguridad(req, res, next) {

    res.set({
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "same-origin",
        "Content-Security-Policy": [
            "default-src 'self'",
            "script-src 'self'",
            "style-src 'self' 'unsafe-inline'",
            "img-src 'self' data:",
            "connect-src 'self'",
            "frame-ancestors 'none'",
            "form-action 'self'",
            "base-uri 'self'"
        ].join("; ")
    });

    next();
}


// --------------------------------------
// LÍMITE DE INTENTOS DE INICIO DE SESIÓN
// --------------------------------------

function crearLimitador({ maximo, ventanaMs }) {

    const intentos = new Map();

    const vigente = clave => {

        const registro = intentos.get(clave);

        if (registro && Date.now() - registro.desde > ventanaMs) {
            intentos.delete(clave);
            return null;
        }

        return registro;
    };

    return {

        bloqueado(clave) {
            const registro = vigente(clave);
            return Boolean(registro && registro.cantidad >= maximo);
        },

        fallo(clave) {

            const registro = vigente(clave);

            if (registro) {
                registro.cantidad++;
            } else {
                intentos.set(clave, { cantidad: 1, desde: Date.now() });
            }
        },

        limpiar(clave) {
            intentos.delete(clave);
        }
    };
}


module.exports = {
    NOMBRE_COOKIE_SESION,
    requiereSesion,
    requiereRol,
    soloAdministrador,
    exigeJson,
    cabecerasSeguridad,
    crearLimitador
};
