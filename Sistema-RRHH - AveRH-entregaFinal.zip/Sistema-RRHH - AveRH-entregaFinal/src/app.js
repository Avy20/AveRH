// ==========================================
// AveRH - Aplicación Express
// ==========================================

const path = require("path");
const crypto = require("crypto");
const express = require("express");
const session = require("express-session");

const { manejadorErrores, ErrorHttp } = require("./utilidades/errores");
const {
    NOMBRE_COOKIE_SESION,
    requiereSesion,
    exigeJson,
    cabecerasSeguridad
} = require("./middleware/seguridad");

const catalogos = require("./rutas/catalogos");


function crearApp() {

    const app = express();

    app.disable("x-powered-by");

    app.use(cabecerasSeguridad);
    // Las exportaciones a Excel pueden enviar miles de filas.
    const jsonNormal = express.json({ limit: "100kb" });
    const jsonExportacion = express.json({ limit: "8mb" });

    app.use((req, res, next) =>
        (req.path.startsWith("/api/exportaciones/") ? jsonExportacion : jsonNormal)(req, res, next));

    // Si no hay SESSION_SECRET se genera uno al arrancar:
    // al reiniciar el servidor hay que volver a iniciar sesión.
    app.use(session({
        name: NOMBRE_COOKIE_SESION,
        secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex"),
        resave: false,
        saveUninitialized: false,
        rolling: true,
        cookie: {
            httpOnly: true,
            sameSite: "lax",
            maxAge: 8 * 60 * 60 * 1000
        }
    }));


    // --------------------------------------
    // FRONTEND: solo la carpeta public/
    // --------------------------------------

    app.use(express.static(path.join(__dirname, "..", "public"), {
        setHeaders(res) {
            // Siempre se valida con el servidor: tras una
            // actualización nadie ve archivos antiguos.
            res.set("Cache-Control", "no-cache");
        }
    }));


    // --------------------------------------
    // API
    // --------------------------------------

    const api = express.Router();

    api.use(exigeJson);
    api.use("/auth", require("./rutas/auth").router);

    // Todo lo siguiente requiere una sesión válida.
    api.use(requiereSesion);

    api.use("/usuarios", require("./rutas/usuarios"));
    api.use("/panel", require("./rutas/panel"));
    api.use("/referencias", require("./rutas/referencias"));
    api.use("/candidatos", require("./rutas/candidatos"));
    api.use("/experiencias", require("./rutas/experiencias"));
    api.use("/proceso", require("./rutas/proceso"));
    api.use("/empleados", require("./rutas/empleados"));
    api.use("/consultas", require("./rutas/consultas"));
    api.use("/reportes", require("./rutas/reportes"));
    api.use("/exportaciones", require("./rutas/exportaciones"));
    api.use("/departamentos", catalogos.departamentos);
    api.use("/competencias", catalogos.competencias);
    api.use("/idiomas", catalogos.idiomas);
    api.use("/capacitaciones", catalogos.capacitaciones);
    api.use("/puestos", catalogos.puestos);
    api.use("/vacantes", catalogos.vacantes);

    api.use(() => {
        throw new ErrorHttp(404, "La ruta solicitada no existe.");
    });

    app.use("/api", api);

    app.use(manejadorErrores);

    return app;
}


module.exports = { crearApp };
